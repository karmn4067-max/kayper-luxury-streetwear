/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { MarqueeBanner } from './components/common/MarqueeBanner';
import { Header } from './components/common/Header';
import { Footer } from './components/common/Footer';
import { Hero } from './components/storefront/Hero';
import { ProductGrid } from './components/storefront/ProductGrid';
import { CraftsmanshipSection } from './components/storefront/CraftsmanshipSection';
import { ProductDetailModal } from './components/storefront/ProductDetailModal';
import { SizeGuideModal } from './components/storefront/SizeGuideModal';
import { CartDrawer } from './components/storefront/CartDrawer';
import { WishlistDrawer } from './components/storefront/WishlistDrawer';
import { CheckoutModal } from './components/storefront/CheckoutModal';
import { OrderSuccessModal } from './components/storefront/OrderSuccessModal';
import { OrderTrackingModal } from './components/storefront/OrderTrackingModal';
import { PrintableReceipt } from './components/storefront/PrintableReceipt';
import { AdminLoginModal } from './components/admin/AdminLoginModal';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { MobileBottomNav } from './components/common/MobileBottomNav';
import { Search, X, Monitor, Smartphone } from 'lucide-react';

const MainStoreContent: React.FC = () => {
  const {
    language,
    activeOrderForReceipt,
    setActiveOrderForReceipt,
    searchQuery,
    setSearchQuery
  } = useStore();

  const [successOrderId, setSuccessOrderId] = useState<string | null>(null);
  const [deviceMode, setDeviceMode] = useState<'responsive' | 'mobile-preview'>('responsive');
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);

  const toggleDeviceMode = () => {
    setDeviceMode((prev) => (prev === 'responsive' ? 'mobile-preview' : 'responsive'));
  };

  const handleMobileSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsMobileSearchOpen(false);
    const catalogEl = document.getElementById('catalog-section');
    if (catalogEl) {
      catalogEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className={`min-h-screen bg-[#070707] selection:bg-[#D4C3A3] selection:text-black ${deviceMode === 'mobile-preview' ? 'py-6 px-2 sm:px-6 flex flex-col items-center justify-center' : ''}`}>
      
      {/* Floating Device Mode Switcher Floating Badge on Desktop */}
      {deviceMode === 'mobile-preview' && (
        <div className="mb-4 flex items-center gap-3 bg-[#161616] border border-[#2D2D2D] px-4 py-2 shadow-xl z-50">
          <div className="flex items-center gap-2 text-xs text-[#D4C3A3]">
            <Smartphone className="w-4 h-4" />
            <span className="font-bold">
              {language === 'ar' ? 'وضع محاكي الموبايل (iPhone Preview 393px)' : 'Mobile Phone Simulator View (393px)'}
            </span>
          </div>
          <button
            onClick={toggleDeviceMode}
            className="flex items-center gap-1.5 px-3 py-1 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-bold uppercase transition-colors"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'الرجوع لوضع الكمبيوتر' : 'Back to Desktop'}</span>
          </button>
        </div>
      )}

      {/* Main Container: Full screen on responsive, or stylized 393px phone frame in mobile preview */}
      <div
        className={`w-full bg-[#0A0A0A] text-[#EAE1D1] flex flex-col transition-all duration-300 relative ${
          deviceMode === 'mobile-preview'
            ? 'max-w-[410px] h-[870px] overflow-y-auto border-4 border-[#2E2E2E] rounded-[44px] shadow-[0_0_60px_rgba(0,0,0,0.9)] pb-20 no-scrollbar'
            : 'min-h-screen pb-16 md:pb-0'
        }`}
      >
        {/* Dynamic Island Notch in Mobile Simulator Preview */}
        {deviceMode === 'mobile-preview' && (
          <div className="sticky top-0 z-50 flex justify-center py-2 bg-[#0A0A0A]/90 backdrop-blur-sm pointer-events-none">
            <div className="w-28 h-5 bg-black border border-[#222] rounded-full flex items-center justify-center">
              <div className="w-2.5 h-2.5 rounded-full bg-[#111] mr-3" />
              <div className="w-2 h-2 rounded-full bg-[#181818]" />
            </div>
          </div>
        )}

        {/* 1. Egyptian Fast Shipping Announcement Marquee */}
        <MarqueeBanner />

        {/* 2. Top Bar Navigation adhering to 3-zone contract */}
        <Header
          deviceMode={deviceMode}
          onToggleDeviceMode={toggleDeviceMode}
          onOpenMobileSearch={() => setIsMobileSearchOpen(true)}
        />

        {/* 3. Lookbook Hero Section */}
        <main className="flex-1">
          <Hero />
          <ProductGrid />
          <CraftsmanshipSection />
        </main>

        {/* 4. Luxury Streetwear Footer with Egyptian Trust Badges */}
        <Footer />

        {/* 5. Mobile Fixed Bottom Navigation Bar (Active on Mobile / Simulator) */}
        <MobileBottomNav onOpenMobileSearch={() => setIsMobileSearchOpen(true)} />

        {/* 6. Modals & Slide-Over Drawers */}
        <ProductDetailModal />
        <SizeGuideModal />
        <CartDrawer />
        <WishlistDrawer />
        
        <CheckoutModal
          onOrderSuccess={(orderId) => {
            setSuccessOrderId(orderId);
          }}
        />
        
        <OrderSuccessModal
          orderId={successOrderId}
          onClose={() => setSuccessOrderId(null)}
        />

        <OrderTrackingModal />

        {/* Printable Receipt Modal (Thermal 80mm & A4) */}
        {activeOrderForReceipt && (
          <PrintableReceipt
            order={activeOrderForReceipt}
            onClose={() => setActiveOrderForReceipt(null)}
          />
        )}

        {/* Hidden & Secure Admin Control Panel */}
        <AdminLoginModal />
        <AdminDashboard />

        {/* Quick Mobile Search Overlay */}
        {isMobileSearchOpen && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-start justify-center p-4 pt-16 animate-fadeIn">
            <div className="relative w-full max-w-md bg-[#141414] border border-[#2B2B2B] p-4 text-[#EAE1D1]">
              <div className="flex items-center justify-between pb-3 border-b border-[#242424] mb-3">
                <span className="text-xs font-bold uppercase text-[#D4C3A3] tracking-wider">
                  {language === 'ar' ? 'بحث سريع عن المنتجات' : 'Quick Streetwear Search'}
                </span>
                <button
                  onClick={() => setIsMobileSearchOpen(false)}
                  className="p-1 text-neutral-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleMobileSearchSubmit} className="space-y-3">
                <div className="relative">
                  <Search className="w-4 h-4 text-neutral-400 absolute left-3 rtl:left-auto rtl:right-3 top-3.5" />
                  <input
                    type="text"
                    autoFocus
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={language === 'ar' ? 'هودي، تيشيرت، كارجو، أو كود...' : 'Hoodie, tee, cargo, or SKU...'}
                    className="w-full bg-[#181818] border border-[#2C2C2C] focus:border-[#D4C3A3] px-9 py-2.5 text-xs text-white focus:outline-none font-mono"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  {language === 'ar' ? 'عرض النتائج' : 'Search Pieces'}
                </button>
              </form>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <MainStoreContent />
    </StoreProvider>
  );
}
