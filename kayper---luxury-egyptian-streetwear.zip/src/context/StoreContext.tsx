import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Language,
  Product,
  CartItem,
  Order,
  Coupon,
  StoreSettings,
  Governorate,
  Category,
  ProductSize,
  ProductColor,
  OrderStatus
} from '../types';
import { INITIAL_PRODUCTS } from '../data/initialProducts';
import { INITIAL_GOVERNORATES } from '../data/governorates';
import { INITIAL_COUPONS, INITIAL_ORDERS, INITIAL_SETTINGS } from '../data/initialCoupons';
import { translations } from '../data/translations';

interface StoreContextType {
  language: Language;
  t: typeof translations.ar;
  setLanguage: (lang: Language) => void;
  products: Product[];
  cart: CartItem[];
  wishlist: string[];
  orders: Order[];
  coupons: Coupon[];
  settings: StoreSettings;
  governorates: Governorate[];
  appliedCoupon: Coupon | null;
  activeCategory: Category | 'all';
  setActiveCategory: (cat: Category | 'all') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  sortBy: 'newest' | 'price-asc' | 'price-desc' | 'popular';
  setSortBy: (sort: 'newest' | 'price-asc' | 'price-desc' | 'popular') => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isWishlistOpen: boolean;
  setIsWishlistOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  isTrackingOpen: boolean;
  setIsTrackingOpen: (open: boolean) => void;
  isAdminOpen: boolean;
  setIsAdminOpen: (open: boolean) => void;
  isAdminAuthenticated: boolean;
  adminEditingProduct: Product | null;
  setAdminEditingProduct: (p: Product | null) => void;
  adminActiveTab: 'products' | 'orders' | 'inventory' | 'shipping' | 'coupons' | 'theme' | 'backup';
  setAdminActiveTab: (tab: 'products' | 'orders' | 'inventory' | 'shipping' | 'coupons' | 'theme' | 'backup') => void;
  selectedProduct: Product | null;
  setSelectedProduct: (p: Product | null) => void;
  isSizeGuideOpen: boolean;
  setIsSizeGuideOpen: (open: boolean) => void;
  activeOrderForReceipt: Order | null;
  setActiveOrderForReceipt: (o: Order | null) => void;
  
  // Cart Actions
  addToCart: (product: Product, size: ProductSize, color: ProductColor, quantity?: number) => void;
  updateCartQuantity: (itemId: string, delta: number) => void;
  removeFromCart: (itemId: string) => void;
  clearCart: () => void;
  cartSubtotal: number;
  cartDiscount: number;
  cartCount: number;
  
  // Wishlist Actions
  toggleWishlist: (productId: string) => void;
  isInWishlist: (productId: string) => boolean;

  // Coupon Actions
  applyCouponCode: (code: string) => { success: boolean; message: string };
  removeCouponCode: () => void;

  // Orders
  createOrder: (orderData: {
    customerName: string;
    customerPhone: string;
    customerEmail?: string;
    governorateId: string;
    city: string;
    address: string;
    notes?: string;
    paymentMethod: 'cod' | 'instapay' | 'vodafone_cash';
    paymentRef?: string;
    shippingFee: number;
  }) => Order;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;

  // Admin Product Actions
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => Product;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  updateInventoryStock: (productId: string, size: ProductSize, count: number) => void;

  // Admin Shipping & Coupons & Settings
  updateGovernorateRate: (id: string, fee: number, days: string) => void;
  addCoupon: (coupon: Coupon) => void;
  toggleCoupon: (code: string) => void;
  deleteCoupon: (code: string) => void;
  updateSettings: (newSettings: Partial<StoreSettings>) => void;
  verifyAdminPassword: (password: string) => boolean;
  changeAdminPassword: (newPass: string) => void;
  adminLogout: () => void;

  // Backup & Restore
  getFullBackupData: () => any;
  restoreBackupData: (jsonString: string) => boolean;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

const LOCAL_STORAGE_KEYS = {
  LANGUAGE: 'kayper_lang_v1',
  PRODUCTS: 'kayper_products_v1',
  CART: 'kayper_cart_v1',
  WISHLIST: 'kayper_wishlist_v1',
  ORDERS: 'kayper_orders_v1',
  COUPONS: 'kayper_coupons_v1',
  SETTINGS: 'kayper_settings_v1',
  GOVERNORATES: 'kayper_govs_v1',
  ADMIN_AUTH: 'kayper_admin_auth_v1'
};

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Language & RTL
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.LANGUAGE);
    return saved === 'en' ? 'en' : 'ar';
  });

  const t = translations[language];

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem(LOCAL_STORAGE_KEYS.LANGUAGE, lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  };

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  // 2. Products
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.PRODUCTS);
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    } catch (err) {
      console.warn('Storage save notice for products:', err);
    }
  }, [products]);

  // 3. Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.CART);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.CART, JSON.stringify(cart));
    } catch (err) {
      console.warn('Storage save notice for cart:', err);
    }
  }, [cart]);

  // 4. Wishlist
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.WISHLIST);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.WISHLIST, JSON.stringify(wishlist));
    } catch (err) {
      console.warn('Storage save notice for wishlist:', err);
    }
  }, [wishlist]);

  // 5. Orders
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.ORDERS);
      return saved ? JSON.parse(saved) : INITIAL_ORDERS;
    } catch {
      return INITIAL_ORDERS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    } catch (err) {
      console.warn('Storage save notice for orders:', err);
    }
  }, [orders]);

  // 6. Coupons
  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.COUPONS);
      return saved ? JSON.parse(saved) : INITIAL_COUPONS;
    } catch {
      return INITIAL_COUPONS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.COUPONS, JSON.stringify(coupons));
    } catch (err) {
      console.warn('Storage save notice for coupons:', err);
    }
  }, [coupons]);

  // 7. Store Settings
  const [settings, setSettings] = useState<StoreSettings>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.SETTINGS);
      return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
    } catch {
      return INITIAL_SETTINGS;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch (err) {
      console.warn('Storage save notice for settings:', err);
    }
  }, [settings]);

  // 8. Governorates
  const [governorates, setGovernorates] = useState<Governorate[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEYS.GOVERNORATES);
      return saved ? JSON.parse(saved) : INITIAL_GOVERNORATES;
    } catch {
      return INITIAL_GOVERNORATES;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEYS.GOVERNORATES, JSON.stringify(governorates));
    } catch (err) {
      console.warn('Storage save notice for governorates:', err);
    }
  }, [governorates]);

  // UI state
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [activeCategory, setActiveCategory] = useState<Category | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'newest' | 'price-asc' | 'price-desc' | 'popular'>('newest');
  
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isTrackingOpen, setIsTrackingOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem(LOCAL_STORAGE_KEYS.ADMIN_AUTH) === 'true';
  });
  const [adminEditingProduct, setAdminEditingProduct] = useState<Product | null>(null);
  const [adminActiveTab, setAdminActiveTab] = useState<'products' | 'orders' | 'inventory' | 'shipping' | 'coupons' | 'theme' | 'backup'>('orders');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [activeOrderForReceipt, setActiveOrderForReceipt] = useState<Order | null>(null);

  // Cart calculations
  const cartSubtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  
  let cartDiscount = 0;
  if (appliedCoupon && appliedCoupon.isActive) {
    if (cartSubtotal >= appliedCoupon.minOrderValue) {
      if (appliedCoupon.type === 'percentage') {
        cartDiscount = Math.round((cartSubtotal * appliedCoupon.value) / 100);
      } else {
        cartDiscount = Math.min(appliedCoupon.value, cartSubtotal);
      }
    }
  }

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Cart methods
  const addToCart = (product: Product, size: ProductSize, color: ProductColor, quantity = 1) => {
    const itemId = `${product.id}-${size}-${color.hex}`;
    setCart((prev) => {
      const existing = prev.find((item) => item.id === itemId);
      if (existing) {
        return prev.map((item) =>
          item.id === itemId
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      } else {
        return [
          ...prev,
          {
            id: itemId,
            productId: product.id,
            product,
            size,
            color,
            quantity,
            price: product.price
          }
        ];
      }
    });
    setIsCartOpen(true);
  };

  const updateCartQuantity = (itemId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.id === itemId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null);
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== itemId));
  };

  const clearCart = () => {
    setCart([]);
    setAppliedCoupon(null);
  };

  // Wishlist methods
  const toggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  const isInWishlist = (productId: string) => wishlist.includes(productId);

  // Coupon methods
  const applyCouponCode = (code: string) => {
    const cleanCode = code.trim().toUpperCase();
    const found = coupons.find((c) => c.code.toUpperCase() === cleanCode && c.isActive);
    if (!found) {
      return { success: false, message: t.promoInvalid };
    }
    if (cartSubtotal < found.minOrderValue) {
      return {
        success: false,
        message:
          language === 'ar'
            ? `الحد الأدنى لتطبيق هذا الكوبون هو ${found.minOrderValue} ج.م`
            : `Minimum order value for this code is ${found.minOrderValue} EGP`
      };
    }
    setAppliedCoupon(found);
    return { success: true, message: t.promoApplied };
  };

  const removeCouponCode = () => {
    setAppliedCoupon(null);
  };

  // Order creation
  const createOrder = (orderData: {
    customerName: string;
    customerPhone: string;
    customerEmail?: string;
    governorateId: string;
    city: string;
    address: string;
    notes?: string;
    paymentMethod: 'cod' | 'instapay' | 'vodafone_cash';
    paymentRef?: string;
    shippingFee: number;
  }) => {
    const gov = governorates.find((g) => g.id === orderData.governorateId);
    const orderId = `KYP-${Math.floor(1000 + Math.random() * 9000)}`;

    const orderItems = cart.map((item) => ({
      productId: item.productId,
      nameEn: item.product.nameEn,
      nameAr: item.product.nameAr,
      size: item.size,
      colorNameEn: item.color.nameEn,
      colorNameAr: item.color.nameAr,
      price: item.price,
      quantity: item.quantity,
      image: item.product.images[0] || ''
    }));

    const finalShipping = cartSubtotal >= settings.freeShippingThreshold ? 0 : orderData.shippingFee;
    const finalTotal = Math.max(0, cartSubtotal - cartDiscount) + finalShipping;

    const newOrder: Order = {
      id: orderId,
      customerName: orderData.customerName,
      customerPhone: orderData.customerPhone,
      customerEmail: orderData.customerEmail,
      governorateId: orderData.governorateId,
      governorateNameEn: gov ? gov.nameEn : orderData.governorateId,
      governorateNameAr: gov ? gov.nameAr : orderData.governorateId,
      city: orderData.city,
      address: orderData.address,
      notes: orderData.notes,
      items: orderItems,
      subtotal: cartSubtotal,
      discount: cartDiscount,
      couponCode: appliedCoupon ? appliedCoupon.code : undefined,
      shippingFee: finalShipping,
      total: finalTotal,
      paymentMethod: orderData.paymentMethod,
      paymentRef: orderData.paymentRef,
      status: 'pending',
      createdAt: new Date().toISOString()
    };

    // Decrement inventory stock
    setProducts((prev) =>
      prev.map((prod) => {
        const boughtItems = cart.filter((c) => c.productId === prod.id);
        if (boughtItems.length === 0) return prod;
        const updatedInventory = { ...prod.inventory };
        boughtItems.forEach((b) => {
          updatedInventory[b.size] = Math.max(0, (updatedInventory[b.size] || 0) - b.quantity);
        });
        return { ...prod, inventory: updatedInventory };
      })
    );

    // Save order
    setOrders((prev) => [newOrder, ...prev]);

    // If coupon used, increment count
    if (appliedCoupon) {
      setCoupons((prev) =>
        prev.map((c) => (c.code === appliedCoupon.code ? { ...c, usageCount: c.usageCount + 1 } : c))
      );
    }

    clearCart();
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status } : ord))
    );
  };

  // Product actions
  const addProduct = (prodData: Omit<Product, 'id' | 'createdAt'>): Product => {
    const newProd: Product = {
      ...prodData,
      id: `kyp-${Date.now().toString().slice(-4)}`,
      createdAt: new Date().toISOString()
    };
    setProducts((prev) => [newProd, ...prev]);
    return newProd;
  };

  const updateProduct = (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    if (selectedProduct && selectedProduct.id === updated.id) {
      setSelectedProduct(updated);
    }
  };

  const deleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    if (selectedProduct && selectedProduct.id === productId) {
      setSelectedProduct(null);
    }
  };

  const updateInventoryStock = (productId: string, size: ProductSize, count: number) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          return {
            ...p,
            inventory: {
              ...p.inventory,
              [size]: Math.max(0, count)
            }
          };
        }
        return p;
      })
    );
  };

  // Admin rates & coupons & settings
  const updateGovernorateRate = (id: string, fee: number, days: string) => {
    setGovernorates((prev) =>
      prev.map((g) => (g.id === id ? { ...g, shippingFee: fee, deliveryDays: days } : g))
    );
  };

  const addCoupon = (coupon: Coupon) => {
    setCoupons((prev) => [coupon, ...prev.filter((c) => c.code !== coupon.code)]);
  };

  const toggleCoupon = (code: string) => {
    setCoupons((prev) =>
      prev.map((c) => (c.code === code ? { ...c, isActive: !c.isActive } : c))
    );
  };

  const deleteCoupon = (code: string) => {
    setCoupons((prev) => prev.filter((c) => c.code !== code));
  };

  const updateSettings = (newSettings: Partial<StoreSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  const verifyAdminPassword = (password: string) => {
    if (password === settings.adminPasswordHash) {
      setIsAdminAuthenticated(true);
      localStorage.setItem(LOCAL_STORAGE_KEYS.ADMIN_AUTH, 'true');
      return true;
    }
    return false;
  };

  const changeAdminPassword = (newPass: string) => {
    updateSettings({ adminPasswordHash: newPass });
  };

  const adminLogout = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem(LOCAL_STORAGE_KEYS.ADMIN_AUTH);
  };

  // Backup & Restore
  const getFullBackupData = () => {
    return {
      version: '1.0.0',
      exportedAt: new Date().toISOString(),
      products,
      orders,
      coupons,
      settings,
      governorates
    };
  };

  const restoreBackupData = (jsonString: string): boolean => {
    try {
      const data = JSON.parse(jsonString);
      if (data.products && Array.isArray(data.products)) setProducts(data.products);
      if (data.orders && Array.isArray(data.orders)) setOrders(data.orders);
      if (data.coupons && Array.isArray(data.coupons)) setCoupons(data.coupons);
      if (data.settings) setSettings(data.settings);
      if (data.governorates && Array.isArray(data.governorates)) setGovernorates(data.governorates);
      return true;
    } catch {
      return false;
    }
  };

  return (
    <StoreContext.Provider
      value={{
        language,
        t,
        setLanguage,
        products,
        cart,
        wishlist,
        orders,
        coupons,
        settings,
        governorates,
        appliedCoupon,
        activeCategory,
        setActiveCategory,
        searchQuery,
        setSearchQuery,
        sortBy,
        setSortBy,
        isCartOpen,
        setIsCartOpen,
        isWishlistOpen,
        setIsWishlistOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        isTrackingOpen,
        setIsTrackingOpen,
        isAdminOpen,
        setIsAdminOpen,
        isAdminAuthenticated,
        adminEditingProduct,
        setAdminEditingProduct,
        adminActiveTab,
        setAdminActiveTab,
        selectedProduct,
        setSelectedProduct,
        isSizeGuideOpen,
        setIsSizeGuideOpen,
        activeOrderForReceipt,
        setActiveOrderForReceipt,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        cartSubtotal,
        cartDiscount,
        cartCount,
        toggleWishlist,
        isInWishlist,
        applyCouponCode,
        removeCouponCode,
        createOrder,
        updateOrderStatus,
        addProduct,
        updateProduct,
        deleteProduct,
        updateInventoryStock,
        updateGovernorateRate,
        addCoupon,
        toggleCoupon,
        deleteCoupon,
        updateSettings,
        verifyAdminPassword,
        changeAdminPassword,
        adminLogout,
        getFullBackupData,
        restoreBackupData
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
