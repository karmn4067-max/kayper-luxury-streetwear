import React from 'react';
import { useStore } from '../../context/StoreContext';
import { X, Ruler, Info } from 'lucide-react';

export const SizeGuideModal: React.FC = () => {
  const { language, t, isSizeGuideOpen, setIsSizeGuideOpen } = useStore();

  if (!isSizeGuideOpen) return null;

  const sizeChart = [
    {
      size: 'S',
      chest: '58 cm',
      length: '70 cm',
      shoulder: '23 cm',
      weightEn: '55 - 68 KG',
      weightAr: '٥٥ - ٦٨ كجم'
    },
    {
      size: 'M',
      chest: '62 cm',
      length: '73 cm',
      shoulder: '25 cm',
      weightEn: '69 - 80 KG',
      weightAr: '٦٩ - ٨٠ كجم'
    },
    {
      size: 'L',
      chest: '66 cm',
      length: '76 cm',
      shoulder: '27 cm',
      weightEn: '81 - 92 KG',
      weightAr: '٨١ - ٩٢ كجم'
    },
    {
      size: 'XL',
      chest: '70 cm',
      length: '79 cm',
      shoulder: '29 cm',
      weightEn: '93 - 105 KG',
      weightAr: '٩٣ - ١٠٥ كجم'
    },
    {
      size: 'XXL',
      chest: '74 cm',
      length: '82 cm',
      shoulder: '31 cm',
      weightEn: '106 - 120 KG',
      weightAr: '١٠٦ - ١٢٠ كجم'
    }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-[#111111] border border-[#262626] shadow-2xl p-6 sm:p-8 text-[#EAE1D1]">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-[#222222]">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#1A1A1A] text-[#D4C3A3]">
              <Ruler className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-['Syne',sans-serif] text-xl font-bold uppercase tracking-wider text-white">
                {t.sizeGuideTitle}
              </h3>
              <p className="text-xs text-neutral-400 mt-1">
                {t.sizeGuideSubtitle}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsSizeGuideOpen(false)}
            className="p-1.5 text-neutral-400 hover:text-white transition-colors bg-[#1A1A1A] hover:bg-[#252525]"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Egyptian Streetwear Fitting Tip */}
        <div className="my-5 p-3.5 bg-[#171717] border border-[#2B2B2B] flex items-start gap-3 text-xs text-neutral-300">
          <Info className="w-4 h-4 text-[#D4C3A3] shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            {language === 'ar'
              ? 'ملاحظة المقاس: جميع قطع كايبر مصممة بقصّة الأوفرسايز الفضفاضة المميزة لأزياء الشارع القاهرية. للحصول على الإطلالة المنسدلة المقترحة، اطلب مقاسك المعتاد. إذا كنت تفضل مقاساً معتاداً مضبوطاً على الجسم تماماً، اختر مقاساً أصغر بدرجة واحدة.'
              : 'Fit Guidance: All KAYPER garments feature an authentic oversized drop-shoulder cut. Order your true size for the intended relaxed architectural drape, or size down if you prefer a slim standard fit.'}
          </p>
        </div>

        {/* Tabular Size Data */}
        <div className="overflow-x-auto">
          <table className="w-full text-left rtl:text-right border-collapse text-xs">
            <thead>
              <tr className="border-b border-[#262626] text-neutral-400 uppercase tracking-wider">
                <th className="py-3 px-4 bg-[#141414] font-bold text-[#D4C3A3]">{t.sizeLabel}</th>
                <th className="py-3 px-4 bg-[#141414] font-semibold">{t.chestCm}</th>
                <th className="py-3 px-4 bg-[#141414] font-semibold">{t.lengthCm}</th>
                <th className="py-3 px-4 bg-[#141414] font-semibold">{language === 'ar' ? 'عرض الكتف' : 'Shoulder Drop'}</th>
                <th className="py-3 px-4 bg-[#141414] font-semibold">{t.recommendedWeight}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1F1F1F]">
              {sizeChart.map((row) => (
                <tr key={row.size} className="hover:bg-[#161616] transition-colors">
                  <td className="py-3.5 px-4 font-mono font-extrabold text-white text-sm">
                    {row.size}
                  </td>
                  <td className="py-3.5 px-4 font-mono tabular-nums text-neutral-300">
                    {row.chest}
                  </td>
                  <td className="py-3.5 px-4 font-mono tabular-nums text-neutral-300">
                    {row.length}
                  </td>
                  <td className="py-3.5 px-4 font-mono tabular-nums text-neutral-300">
                    {row.shoulder}
                  </td>
                  <td className="py-3.5 px-4 font-medium text-[#D4C3A3]">
                    {language === 'ar' ? row.weightAr : row.weightEn}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footnote */}
        <div className="mt-5 pt-4 border-t border-[#222222] flex items-center justify-between text-[11px] text-neutral-500">
          <span>{t.fitNotice}</span>
          <button
            onClick={() => setIsSizeGuideOpen(false)}
            className="px-4 py-2 bg-[#D4C3A3] text-black font-bold uppercase tracking-wider text-xs hover:bg-[#EAE1D1] transition-colors"
          >
            {language === 'ar' ? 'فهمت المقاس' : 'Got It'}
          </button>
        </div>

      </div>
    </div>
  );
};
