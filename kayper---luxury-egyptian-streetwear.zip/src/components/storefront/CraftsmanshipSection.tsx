import React from 'react';
import { useStore } from '../../context/StoreContext';
import { ShieldCheck, Award, Scissors, Compass } from 'lucide-react';

export const CraftsmanshipSection: React.FC = () => {
  const { language } = useStore();

  const pillars = [
    {
      icon: Award,
      titleEn: '480 GSM Giza Cotton',
      titleAr: 'قطن جيزة عيار ٤٨٠ جم',
      descEn: 'Woven on vintage high-density looms in Egypt for unmatched sculptural drape and durability.',
      descAr: 'منسوج على أنوال كلاسيكية عالية الكثافة في مصر لمنح القطعة قواماً نحتياً لا يترهل.'
    },
    {
      icon: Scissors,
      titleEn: 'Drop-Shoulder Architecture',
      titleAr: 'هندسة الأكتاف المنسدلة',
      descEn: 'Sculpted streetwear ergonomics tailored specifically for relaxed, effortless movement.',
      descAr: 'قصات بوكسي دقيقة ومدروسة هندسياً لتوفير راحة تامة وانسيابية شوارع عصرية.'
    },
    {
      icon: ShieldCheck,
      titleEn: 'Enzyme-Washed Patina',
      titleAr: 'معالجة الغسيل الإنزيمي',
      descEn: 'Pre-shrunk organic wash that softens fibers while locking in deep matte obsidian pigments.',
      descAr: 'غسيل عضوي مقاوم للانكماش بنسبة ١٠٠٪ يحافظ على ثبات درجات الأسود البركاني للأبد.'
    },
    {
      icon: Compass,
      titleEn: 'Cairo Nocturnal Heritage',
      titleAr: 'إلهام شوارع القاهرة',
      descEn: 'Every stitch resonates with the monumental concrete architecture and vibrant Cairo underground.',
      descAr: 'كل غرزة وتطريز مستلهم من شموخ المعمار القاهري وعراقة أقدم عواصم الحضارة.'
    }
  ];

  return (
    <section id="craftsmanship-section" className="bg-[#0D0D0D] border-t border-b border-[#1E1E1E] py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <span className="text-xs font-mono font-bold uppercase tracking-widest text-[#D4C3A3]">
            {language === 'ar' ? 'فلسفة الصنعة والحياكة' : 'CRAFTSMANSHIP & ATELIER'}
          </span>
          <h2 className="font-['Syne',sans-serif] text-3xl sm:text-4xl font-extrabold uppercase text-white tracking-tight">
            {language === 'ar' ? 'معايير الفخامة المعمارية' : 'THE ARCHITECTURAL STANDARD'}
          </h2>
          <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
            {language === 'ar'
              ? 'لا نكتفي بصناعة الملابس، بل نصمم قطعا استثنائية تعيش معك طويلاً. أقمشة مصرية أصيلة تمت حياكتها بمعايير دور الأزياء العالمية المستقلة.'
              : 'We don’t create fast fashion. We construct enduring monuments. Authentic Egyptian heavy textiles engineered with meticulous independent atelier precision.'}
          </p>
        </div>

        {/* 4 Pillars Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {pillars.map((p, idx) => {
            const Icon = p.icon;
            return (
              <div
                key={idx}
                className="p-6 bg-[#121212] border border-[#212121] hover:border-[#D4C3A3]/50 transition-colors space-y-3 group"
              >
                <div className="p-3 bg-[#1A1A1A] border border-[#292929] w-fit text-[#D4C3A3] group-hover:bg-[#D4C3A3] group-hover:text-black transition-colors">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-sm text-white uppercase tracking-wider">
                  {language === 'ar' ? p.titleAr : p.titleEn}
                </h3>
                <p className="text-xs text-neutral-400 leading-relaxed">
                  {language === 'ar' ? p.descAr : p.descEn}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
