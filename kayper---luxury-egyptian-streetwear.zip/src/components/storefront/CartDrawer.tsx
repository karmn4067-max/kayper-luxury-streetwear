import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { X, Trash2, ShoppingBag, ArrowRight, Tag, Check, Truck } from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    language,
    t,
    isCartOpen,
    setIsCartOpen,
    cart,
    updateCartQuantity,
    removeFromCart,
    cartSubtotal,
    cartDiscount,
    appliedCoupon,
    applyCouponCode,
    removeCouponCode,
    settings,
    setIsCheckoutOpen
  } = useStore();

  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState('');

  if (!isCartOpen) return null;

  // Free shipping math
  const freeThreshold = settings.freeShippingThreshold;
  const amountNeededForFreeShipping = Math.max(0, freeThreshold - cartSubtotal);
  const freeShippingProgress = Math.min(100, Math.round((cartSubtotal / freeThreshold) * 100));

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    const res = applyCouponCode(couponInput);
    if (!res.success) {
      setCouponError(res.message);
    } else {
      setCouponError('');
      setCouponInput('');
    }
  };

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const finalCartTotal = Math.max(0, cartSubtotal - cartDiscount);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div className="absolute inset-0" onClick={() => setIsCartOpen(false)} />
      
      <div className="fixed inset-y-0 right-0 rtl:right-auto rtl:left-0 max-w-full flex pl-10 rtl:pl-0 rtl:pr-10">
        <div className="w-screen max-w-md bg-[#111111] border-l rtl:border-l-0 rtl:border-r border-[#262626] text-[#EAE1D1] flex flex-col shadow-2xl">
          
          {/* Header */}
          <div className="p-5 border-b border-[#212121] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-5 h-5 text-[#D4C3A3]" />
              <h3 className="font-['Syne',sans-serif] text-base font-bold uppercase tracking-wider text-white">
                {t.cartTitle}
              </h3>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-1.5 text-neutral-400 hover:text-white bg-[#1A1A1A] hover:bg-[#262626] transition-colors"
              aria-label="Close cart"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Progress Indicator */}
          {cart.length > 0 && (
            <div className="px-5 py-3.5 bg-[#161616] border-b border-[#222222]">
              <div className="flex items-center gap-2 text-xs font-medium mb-1.5">
                <Truck className="w-4 h-4 text-[#D4C3A3] shrink-0" />
                {amountNeededForFreeShipping === 0 ? (
                  <span className="text-emerald-400 font-bold">{t.freeShippingEarned}</span>
                ) : (
                  <span className="text-neutral-300">
                    {language === 'ar'
                      ? `أضف بـ ${amountNeededForFreeShipping.toLocaleString()} ج.م للحصول على شحن مجاني`
                      : `Add ${amountNeededForFreeShipping.toLocaleString()} EGP more for FREE shipping`}
                  </span>
                )}
              </div>
              <div className="w-full bg-[#262626] h-1.5 overflow-hidden">
                <div
                  className="bg-[#D4C3A3] h-full transition-all duration-500"
                  style={{ width: `${freeShippingProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {cart.length === 0 ? (
              <div className="py-20 flex flex-col items-center justify-center text-center space-y-4 text-neutral-400">
                <div className="p-4 bg-[#161616] border border-[#262626] rounded-full text-neutral-500">
                  <ShoppingBag className="w-8 h-8 text-[#D4C3A3]" />
                </div>
                <p className="text-sm font-medium text-white">{t.cartEmpty}</p>
                <p className="text-xs text-neutral-500 max-w-xs">
                  {language === 'ar'
                    ? 'لم تقم بإضافة أي قطع بعد. استكشف أحدث تصاميم الشارع القاهري الآن.'
                    : 'Your bag is empty. Explore our latest heavyweight drops.'}
                </p>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="px-6 py-2.5 bg-[#D4C3A3] text-black text-xs font-bold uppercase tracking-wider hover:bg-[#EAE1D1] transition-colors"
                >
                  {t.startShopping}
                </button>
              </div>
            ) : (
              cart.map((item) => {
                const name = language === 'ar' ? item.product.nameAr : item.product.nameEn;
                const colorName = language === 'ar' ? item.color.nameAr : item.color.nameEn;

                return (
                  <div
                    key={item.id}
                    className="flex gap-4 p-3 bg-[#161616] border border-[#242424] items-start"
                  >
                    {/* Item Thumbnail */}
                    <div className="w-20 h-24 bg-[#1c1c1c] overflow-hidden shrink-0 border border-[#2b2b2b]">
                      <img
                        src={item.product.images[0]}
                        alt={name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center"
                      />
                    </div>

                    {/* Item Details */}
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-xs font-bold text-white line-clamp-1">
                          {name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="text-neutral-500 hover:text-red-400 transition-colors p-0.5"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-neutral-400 font-mono">
                        <span>{item.size}</span>
                        <span>·</span>
                        <div className="flex items-center gap-1">
                          <span
                            className="w-2.5 h-2.5 rounded-full border border-black/50"
                            style={{ backgroundColor: item.color.hex }}
                          />
                          <span>{colorName}</span>
                        </div>
                      </div>

                      <div className="pt-2 flex items-center justify-between">
                        {/* Stepper */}
                        <div className="flex items-center border border-[#2E2E2E] bg-[#121212]">
                          <button
                            onClick={() => updateCartQuantity(item.id, -1)}
                            className="px-2 py-0.5 text-xs text-neutral-400 hover:text-white"
                          >
                            -
                          </button>
                          <span className="px-2.5 py-0.5 text-xs font-mono font-bold text-white tabular-nums">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateCartQuantity(item.id, 1)}
                            className="px-2 py-0.5 text-xs text-neutral-400 hover:text-white"
                          >
                            +
                          </button>
                        </div>

                        {/* Price */}
                        <div className="font-mono text-xs font-extrabold text-[#EAE1D1] tabular-nums">
                          {(item.price * item.quantity).toLocaleString()} {t.currency}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer Controls: Promo, Subtotal & Checkout */}
          {cart.length > 0 && (
            <div className="p-5 bg-[#141414] border-t border-[#222222] space-y-4">
              {/* Promo code form */}
              {appliedCoupon ? (
                <div className="p-2.5 bg-[#1B1B1B] border border-[#2E2E2E] flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 text-emerald-400 font-mono">
                    <Tag className="w-3.5 h-3.5" />
                    <span>{appliedCoupon.code}</span>
                    <span className="text-neutral-400 text-[11px]">
                      (-{appliedCoupon.type === 'percentage' ? `${appliedCoupon.value}%` : `${appliedCoupon.value} ${t.currency}`})
                    </span>
                  </div>
                  <button
                    onClick={removeCouponCode}
                    className="text-neutral-400 hover:text-red-400 text-[11px] underline"
                  >
                    {language === 'ar' ? 'إزالة' : 'Remove'}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyCoupon} className="space-y-1">
                  <div className="flex items-center bg-[#191919] border border-[#2B2B2B]">
                    <input
                      type="text"
                      value={couponInput}
                      onChange={(e) => {
                        setCouponInput(e.target.value);
                        setCouponError('');
                      }}
                      placeholder={t.promoCode + ' (e.g. KAYPER10)'}
                      className="w-full bg-transparent border-none text-xs text-white px-3 py-2 uppercase placeholder:text-neutral-500 focus:outline-none font-mono"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-[#252525] hover:bg-[#D4C3A3] text-neutral-300 hover:text-black text-xs font-bold uppercase transition-colors shrink-0"
                    >
                      {t.applyPromo}
                    </button>
                  </div>
                  {couponError && (
                    <p className="text-[11px] text-red-400 font-medium">{couponError}</p>
                  )}
                </form>
              )}

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-neutral-400 pt-1 border-t border-[#222222]">
                <div className="flex justify-between">
                  <span>{t.subtotal}</span>
                  <span className="font-mono tabular-nums text-white">
                    {cartSubtotal.toLocaleString()} {t.currency}
                  </span>
                </div>

                {cartDiscount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>{t.discount}</span>
                    <span className="font-mono tabular-nums">
                      -{cartDiscount.toLocaleString()} {t.currency}
                    </span>
                  </div>
                )}

                <div className="flex justify-between">
                  <span>{t.estimatedShipping}</span>
                  <span className="font-mono tabular-nums text-[#D4C3A3]">
                    {cartSubtotal >= freeThreshold
                      ? t.freeShipping
                      : language === 'ar'
                      ? 'يُحسب عند اختيار المحافظة'
                      : 'Calculated at checkout'}
                  </span>
                </div>

                <div className="flex justify-between text-sm font-extrabold text-white pt-2 border-t border-[#262626]">
                  <span>{t.total}</span>
                  <span className="font-mono tabular-nums text-base text-[#EAE1D1]">
                    {finalCartTotal.toLocaleString()} {t.currency}
                  </span>
                </div>
              </div>

              {/* Checkout CTA */}
              <button
                onClick={handleProceedToCheckout}
                className="w-full py-3.5 px-6 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-black tracking-widest uppercase flex items-center justify-center gap-2 transition-all shadow-lg shadow-black/50 cursor-pointer"
              >
                <span>{t.proceedToCheckout}</span>
                <ArrowRight className="w-4 h-4 rtl:rotate-180" />
              </button>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
