import React from 'react';
import { useStore } from '../../context/StoreContext';
import { ArrowDown, Sparkles } from 'lucide-react';

export const Hero: React.FC = () => {
  const { language, t, settings } = useStore();

  const scrollToCatalog = () => {
    const el = document.getElementById('catalog-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative overflow-hidden bg-[#0A0A0A] border-b border-[#1C1C1C]">
      {/* Background Graphic & Atmosphere */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Text Content Column */}
          <div className="lg:col-span-5 flex flex-col justify-center space-y-6 z-10">
            {/* Quiet Kicker */}
            <div className="flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-[#D4C3A3]">
              <Sparkles className="w-3.5 h-3.5 text-[#D4C3A3]" />
              <span>{language === 'ar' ? 'المجموعة الشتوية الرسمية ٢٠٢٦' : 'OFFICIAL WINTER DROP 2026'}</span>
            </div>

            {/* Display Headline */}
            <h1 className="font-['Syne',sans-serif] text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-[#EAE1D1] uppercase leading-[1.08] text-balance">
              {language === 'ar' ? settings.heroTitleAr : settings.heroTitleEn}
            </h1>

            {/* Subtitle */}
            <p className="text-sm sm:text-base text-neutral-400 max-w-lg leading-relaxed">
              {language === 'ar' ? settings.heroSubtitleAr : settings.heroSubtitleEn}
            </p>

            {/* CTAs */}
            <div className="pt-2 flex flex-wrap items-center gap-4">
              <button
                onClick={scrollToCatalog}
                className="bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black px-7 py-3.5 text-xs font-black tracking-widest uppercase transition-all flex items-center gap-3 shadow-lg shadow-black/50 cursor-pointer"
              >
                <span>{t.quickShop}</span>
                <ArrowDown className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  const el = document.getElementById('craftsmanship-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                className="border border-[#2F2F2F] hover:border-[#D4C3A3] text-neutral-300 hover:text-white px-6 py-3.5 text-xs font-bold tracking-wider uppercase transition-colors bg-[#111111] cursor-pointer"
              >
                {t.exploreLookbook}
              </button>
            </div>

            {/* Subtle Metadata Pill-Free Strip */}
            <div className="pt-6 border-t border-[#1C1C1C] flex flex-wrap items-center gap-y-2 gap-x-4 text-xs text-neutral-500">
              <span className="text-[#D4C3A3] font-semibold">{t.egyptianCotton}</span>
              <span aria-hidden="true" className="text-neutral-700">·</span>
              <span>{t.cashOnDeliveryAvail}</span>
              <span aria-hidden="true" className="text-neutral-700">·</span>
              <span>
                {language === 'ar'
                  ? `شحن مجاني فوق ${settings.freeShippingThreshold} ج.م`
                  : `Free shipping over ${settings.freeShippingThreshold} EGP`}
              </span>
            </div>
          </div>

          {/* High-Impact Imagery Column */}
          <div className="lg:col-span-7 relative">
            <div className="relative aspect-[16/10] sm:aspect-[16/10] overflow-hidden border border-[#262626] shadow-2xl bg-[#141414] group">
              <img
                src={settings.heroImage}
                alt="KAYPER Cairo Streetwear Lookbook"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover object-center filter contrast-[1.05] brightness-95 group-hover:scale-105 transition-transform duration-700 ease-out"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent pointer-events-none" />
              
              {/* Overlay Location Stamp */}
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-neutral-300">
                <div className="bg-black/80 backdrop-blur-sm border border-[#2B2B2B] px-3 py-1.5 font-mono text-[11px] tracking-wider text-[#D4C3A3]">
                  ARCHIVE LOC: 30°02'42"N 31°14'45"E // CAIRO
                </div>
                <div className="hidden sm:block bg-black/80 backdrop-blur-sm border border-[#2B2B2B] px-3 py-1.5 text-[11px] text-neutral-300 font-semibold uppercase">
                  {language === 'ar' ? 'نسخة محدودة • القاهرة' : 'LIMITED RUN • CAIRO'}
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
