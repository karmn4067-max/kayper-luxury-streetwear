import React, { useState } from 'react';
import { Order } from '../../types';
import { useStore } from '../../context/StoreContext';
import { Printer, X, FileText, CheckCircle2 } from 'lucide-react';

interface PrintableReceiptProps {
  order: Order;
  onClose: () => void;
}

export const PrintableReceipt: React.FC<PrintableReceiptProps> = ({ order, onClose }) => {
  const { language, t } = useStore();
  const [printFormat, setPrintFormat] = useState<'a4' | 'thermal'>('a4');

  const handlePrint = () => {
    window.print();
  };

  const paymentMethodLabel =
    order.paymentMethod === 'cod'
      ? (language === 'ar' ? 'الدفع عند الاستلام (COD)' : 'Cash on Delivery (COD)')
      : order.paymentMethod === 'instapay'
      ? (language === 'ar' ? `إنستاباي (Ref: ${order.paymentRef || 'N/A'})` : `InstaPay (Ref: ${order.paymentRef || 'N/A'})`)
      : (language === 'ar' ? `فودافون كاش (Wallet: ${order.paymentRef || 'N/A'})` : `Vodafone Cash (Wallet: ${order.paymentRef || 'N/A'})`);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-fadeIn">
      <div className="relative w-full max-w-3xl bg-white text-black shadow-2xl p-6 sm:p-8 my-6">
        
        {/* Screen Action Bar (hidden in print) */}
        <div className="no-print flex items-center justify-between pb-6 mb-6 border-b border-neutral-200">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPrintFormat('a4')}
              className={`px-3 py-1.5 text-xs font-bold uppercase transition-colors ${
                printFormat === 'a4'
                  ? 'bg-black text-white'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              A4 Standard Format
            </button>
            <button
              onClick={() => setPrintFormat('thermal')}
              className={`px-3 py-1.5 text-xs font-bold uppercase transition-colors ${
                printFormat === 'thermal'
                  ? 'bg-black text-white'
                  : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
              }`}
            >
              POS Thermal 80mm
            </button>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-black text-white text-xs font-bold uppercase hover:bg-neutral-800 transition-colors shadow-md"
            >
              <Printer className="w-4 h-4" />
              <span>{language === 'ar' ? 'طباعة الآن' : 'Print Invoice'}</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-black transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Sheet */}
        <div
          className={`${
            printFormat === 'thermal'
              ? 'max-w-[340px] mx-auto font-mono text-[11px] p-4 border border-dashed border-neutral-300'
              : 'w-full'
          }`}
        >
          {/* Receipt Header */}
          <div className="text-center pb-6 border-b border-black">
            <h1 className="font-['Syne',sans-serif] text-2xl font-black tracking-widest uppercase">
              KAYPER
            </h1>
            <p className="text-xs font-bold tracking-wider uppercase mt-0.5">
              CAIRO UNDERGROUND LUXURY STREETWEAR
            </p>
            <p className="text-[10px] text-neutral-600 mt-1">
              سجل تجاري: ٩٤٨٢٧١ • بطاقة ضريبية: ٣٩٤-٨٢١-٠٠٢
            </p>
            <p className="text-[10px] text-neutral-600">
              Cairo, Egypt • Support: 01023456789
            </p>
          </div>

          {/* Order Details Grid */}
          <div className="py-4 border-b border-neutral-300 grid grid-cols-2 gap-4 text-xs">
            <div>
              <p className="text-neutral-500 text-[10px] uppercase font-bold">{t.orderIdLabel}</p>
              <p className="font-mono font-bold text-sm text-black">{order.id}</p>
              <p className="text-[10px] text-neutral-500 mt-1">{t.receiptDate}</p>
              <p className="font-mono text-[11px]">{new Date(order.createdAt).toLocaleDateString(language === 'ar' ? 'ar-EG' : 'en-US', { dateStyle: 'medium', timeStyle: 'short' })}</p>
            </div>

            <div className="text-right rtl:text-left">
              <p className="text-neutral-500 text-[10px] uppercase font-bold">{t.receiptCustomer}</p>
              <p className="font-bold text-black">{order.customerName}</p>
              <p className="font-mono text-neutral-700">{order.customerPhone}</p>
              <p className="text-neutral-600 text-[11px]">{order.governorateNameAr || order.governorateNameEn} - {order.city}</p>
            </div>
          </div>

          {/* Delivery Address */}
          <div className="py-2.5 border-b border-neutral-300 text-[11px]">
            <span className="text-neutral-500 font-bold">{language === 'ar' ? 'عنوان التوصيل:' : 'Delivery Address:'} </span>
            <span className="text-neutral-900">{order.address}</span>
            {order.notes && (
              <p className="text-neutral-600 mt-0.5 text-[10px] italic">
                {language === 'ar' ? 'ملاحظة:' : 'Note:'} {order.notes}
              </p>
            )}
          </div>

          {/* Itemized Table */}
          <div className="py-4 border-b border-black">
            <table className="w-full text-left rtl:text-right text-xs">
              <thead>
                <tr className="border-b border-neutral-300 text-[10px] uppercase text-neutral-500">
                  <th className="pb-1">{language === 'ar' ? 'القطعة / المواصفات' : 'Item / Specs'}</th>
                  <th className="pb-1 text-center">{language === 'ar' ? 'الكمية' : 'Qty'}</th>
                  <th className="pb-1 text-right rtl:text-left">{language === 'ar' ? 'السعر' : 'Price'}</th>
                  <th className="pb-1 text-right rtl:text-left">{language === 'ar' ? 'الإجمالي' : 'Total'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-200">
                {order.items.map((item, idx) => (
                  <tr key={idx} className="py-2">
                    <td className="py-2">
                      <div className="font-bold text-neutral-900 leading-tight">
                        {language === 'ar' ? item.nameAr : item.nameEn}
                      </div>
                      <div className="text-[10px] text-neutral-500 font-mono">
                        {item.size} · {language === 'ar' ? item.colorNameAr : item.colorNameEn}
                      </div>
                    </td>
                    <td className="py-2 text-center font-mono font-bold">
                      {item.quantity}
                    </td>
                    <td className="py-2 text-right rtl:text-left font-mono">
                      {item.price.toLocaleString()} {t.currency}
                    </td>
                    <td className="py-2 text-right rtl:text-left font-mono font-bold">
                      {(item.price * item.quantity).toLocaleString()} {t.currency}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Totals Section */}
          <div className="py-4 space-y-1.5 text-xs border-b border-black">
            <div className="flex justify-between">
              <span className="text-neutral-600">{t.subtotal}</span>
              <span className="font-mono tabular-nums">{order.subtotal.toLocaleString()} {t.currency}</span>
            </div>

            {order.discount > 0 && (
              <div className="flex justify-between text-neutral-800">
                <span>{t.discount} {order.couponCode ? `(${order.couponCode})` : ''}</span>
                <span className="font-mono tabular-nums">-{order.discount.toLocaleString()} {t.currency}</span>
              </div>
            )}

            <div className="flex justify-between">
              <span className="text-neutral-600">{t.estimatedShipping}</span>
              <span className="font-mono tabular-nums">
                {order.shippingFee === 0 ? t.freeShipping : `${order.shippingFee} ${t.currency}`}
              </span>
            </div>

            <div className="flex justify-between text-sm font-black pt-2 border-t border-neutral-300">
              <span>{t.total}</span>
              <span className="font-mono tabular-nums text-base">{order.total.toLocaleString()} {t.currency}</span>
            </div>
          </div>

          {/* Payment Method & Terms */}
          <div className="py-3 text-[11px] text-neutral-700 space-y-1">
            <p>
              <strong className="text-black">{t.receiptPaymentMethod}</strong> {paymentMethodLabel}
            </p>
            <p className="text-[10px] text-neutral-500 leading-relaxed pt-2">
              {language === 'ar'
                ? 'شكراً لثقتكم في كايبر. يحق للعميل استبدال أو استرجاع المنتج خلال 14 يوماً من تاريخ الاستلام بشرط بقاء البطاقة الأصلية والتغليف السليم وفقاً لقانون حماية المستهلك المصري.'
                : 'Thank you for choosing KAYPER. Returns and exchanges valid within 14 days with original tags intact.'}
            </p>
          </div>

          {/* Barcode Mock */}
          <div className="pt-4 text-center">
            <div className="inline-block tracking-[0.3em] font-mono text-[10px] border-t border-neutral-400 pt-1">
              *|||| ||||| |||| |||| |||||*
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
