import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductSize, ProductColor } from '../../types';
import { X, Heart, ShoppingBag, Ruler, Check, ShieldCheck, Sparkles, AlertCircle } from 'lucide-react';

export const ProductDetailModal: React.FC = () => {
  const {
    language,
    t,
    selectedProduct,
    setSelectedProduct,
    addToCart,
    isInWishlist,
    toggleWishlist,
    setIsSizeGuideOpen
  } = useStore();

  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [selectedSize, setSelectedSize] = useState<ProductSize>('L');
  const [selectedColor, setSelectedColor] = useState<ProductColor | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [addedNotice, setAddedNotice] = useState(false);
  const [isZoomed, setIsZoomed] = useState(false);

  if (!selectedProduct) return null;

  // Initialize selected color
  const activeColor = selectedColor || selectedProduct.colors[0] || { nameEn: 'Standard', nameAr: 'قياسي', hex: '#000000' };

  const name = language === 'ar' ? selectedProduct.nameAr : selectedProduct.nameEn;
  const description = language === 'ar' ? selectedProduct.descriptionAr : selectedProduct.descriptionEn;
  const fabric = language === 'ar' ? selectedProduct.fabricAr : selectedProduct.fabricEn;
  const details = language === 'ar' ? selectedProduct.detailsAr : selectedProduct.detailsEn;
  
  const currentStock = selectedProduct.inventory[selectedSize] ?? 0;
  const isScarcity = currentStock > 0 && currentStock <= 5;
  const isSoldOut = currentStock === 0;
  const isFav = isInWishlist(selectedProduct.id);

  const handleAddToCart = () => {
    if (isSoldOut) return;
    addToCart(selectedProduct, selectedSize, activeColor, quantity);
    setAddedNotice(true);
    setTimeout(() => setAddedNotice(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/85 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="relative w-full max-w-5xl bg-[#111111] border border-[#262626] shadow-2xl text-[#EAE1D1] my-8 overflow-hidden">
        
        {/* Top Dismiss Button */}
        <button
          onClick={() => setSelectedProduct(null)}
          className="absolute top-4 right-4 rtl:right-auto rtl:left-4 z-30 p-2 bg-black/80 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-[#2B2B2B] transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 max-h-[85vh] overflow-y-auto">
          
          {/* Gallery Column (Left / Right depending on RTL) */}
          <div className="md:col-span-7 p-4 sm:p-6 bg-[#0E0E0E] flex flex-col gap-4 border-b md:border-b-0 md:border-r md:rtl:border-r-0 md:rtl:border-l border-[#212121]">
            {/* Primary Main Image with optional Zoom */}
            <div
              className="relative aspect-[4/5] bg-[#161616] overflow-hidden border border-[#242424] cursor-zoom-in"
              onClick={() => setIsZoomed(!isZoomed)}
            >
              <img
                src={selectedProduct.images[activeImageIdx] || selectedProduct.images[0]}
                alt={name}
                referrerPolicy="no-referrer"
                className={`w-full h-full object-cover object-center transition-transform duration-300 ${
                  isZoomed ? 'scale-150 cursor-zoom-out' : 'scale-100 hover:scale-105'
                }`}
              />

              {/* Zoom hint badge */}
              <div className="absolute bottom-3 left-3 rtl:left-auto rtl:right-3 bg-black/75 px-2.5 py-1 text-[10px] font-mono uppercase text-neutral-400 pointer-events-none">
                {isZoomed ? (language === 'ar' ? 'انقر للتصغير' : 'Click to zoom out') : (language === 'ar' ? 'انقر لتكبير التفاصيل' : 'Click to zoom')}
              </div>
            </div>

            {/* Thumbnail Strip */}
            {selectedProduct.images.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-1">
                {selectedProduct.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setActiveImageIdx(idx);
                      setIsZoomed(false);
                    }}
                    className={`relative w-20 h-24 shrink-0 overflow-hidden border transition-all ${
                      activeImageIdx === idx
                        ? 'border-[#D4C3A3] ring-1 ring-[#D4C3A3]'
                        : 'border-[#262626] opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="thumbnail" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Purchasing & Details Column */}
          <div className="md:col-span-5 p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              
              {/* Category, SKU & Wishlist Header */}
              <div className="flex items-center justify-between text-xs text-neutral-400 font-mono">
                <span className="uppercase text-[#D4C3A3] font-bold">{selectedProduct.category}</span>
                <div className="flex items-center gap-3">
                  <span>{t.sku}: {selectedProduct.sku}</span>
                  <button
                    onClick={() => toggleWishlist(selectedProduct.id)}
                    className="text-neutral-400 hover:text-[#D4C3A3] transition-colors"
                    title={t.wishlist}
                  >
                    <Heart className={`w-4 h-4 ${isFav ? 'fill-[#D4C3A3] text-[#D4C3A3]' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Title */}
              <h2 className="font-['Syne',sans-serif] text-2xl font-bold uppercase text-white tracking-tight">
                {name}
              </h2>

              {/* Price */}
              <div className="flex items-baseline gap-3 font-mono">
                <span className="text-2xl font-extrabold text-[#EAE1D1] tabular-nums">
                  {selectedProduct.price.toLocaleString()} {t.currency}
                </span>
                {selectedProduct.compareAtPrice && (
                  <span className="text-sm text-neutral-500 line-through tabular-nums">
                    {selectedProduct.compareAtPrice.toLocaleString()} {t.currency}
                  </span>
                )}
              </div>

              {/* Description */}
              <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed border-y border-[#212121] py-3">
                {description}
              </p>

              {/* Color Selection */}
              {selectedProduct.colors && selectedProduct.colors.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-neutral-300">
                    <span className="font-bold">{t.selectColor}:</span>
                    <span className="text-neutral-400 font-mono">
                      {language === 'ar' ? activeColor.nameAr : activeColor.nameEn}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {selectedProduct.colors.map((c, i) => {
                      const isSelected = activeColor.hex === c.hex;
                      return (
                        <button
                          key={i}
                          onClick={() => setSelectedColor(c)}
                          className={`flex items-center gap-2 px-3 py-1.5 border text-xs transition-all ${
                            isSelected
                              ? 'border-[#D4C3A3] bg-[#1A1A1A] text-white'
                              : 'border-[#262626] bg-[#141414] text-neutral-400 hover:border-neutral-500'
                          }`}
                        >
                          <span
                            className="w-3.5 h-3.5 rounded-full border border-black/40 shrink-0"
                            style={{ backgroundColor: c.hex }}
                          />
                          <span>{language === 'ar' ? c.nameAr : c.nameEn}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Size Selection with Egyptian Size Guide link */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs text-neutral-300">
                  <span className="font-bold">{t.selectSize}:</span>
                  <button
                    onClick={() => setIsSizeGuideOpen(true)}
                    className="flex items-center gap-1.5 text-xs text-[#D4C3A3] hover:underline font-medium"
                  >
                    <Ruler className="w-3.5 h-3.5" />
                    <span>{t.sizeGuide}</span>
                  </button>
                </div>

                <div className="grid grid-cols-5 gap-2">
                  {selectedProduct.sizes.map((sz) => {
                    const stock = selectedProduct.inventory[sz] ?? 0;
                    const isSelected = selectedSize === sz;
                    return (
                      <button
                        key={sz}
                        disabled={stock === 0}
                        onClick={() => setSelectedSize(sz)}
                        className={`py-2 text-xs font-mono font-bold transition-all ${
                          isSelected
                            ? 'bg-[#D4C3A3] text-black shadow-md'
                            : stock === 0
                            ? 'bg-[#161616] text-neutral-600 line-through cursor-not-allowed border border-[#202020]'
                            : 'bg-[#181818] text-neutral-300 hover:border-[#D4C3A3] border border-[#292929]'
                        }`}
                      >
                        {sz}
                      </button>
                    );
                  })}
                </div>

                {/* Scarcity indicator */}
                {isScarcity && (
                  <div className="flex items-center gap-1.5 text-xs text-amber-400 font-medium pt-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>
                      {language === 'ar'
                        ? `باقي ${currentStock} قطع فقط في مقاس ${selectedSize} بمستودع القاهرة!`
                        : `Only ${currentStock} pieces left in size ${selectedSize} in Cairo warehouse!`}
                    </span>
                  </div>
                )}
                {isSoldOut && (
                  <div className="text-xs text-red-400 font-medium pt-1">
                    {t.outOfStock}
                  </div>
                )}
              </div>

              {/* Quantity Stepper */}
              <div className="flex items-center gap-4 pt-2">
                <span className="text-xs font-bold text-neutral-300">{t.quantity}:</span>
                <div className="flex items-center border border-[#2B2B2B] bg-[#141414]">
                  <button
                    disabled={quantity <= 1}
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="px-3 py-1.5 text-sm text-neutral-400 hover:text-white disabled:opacity-30"
                  >
                    -
                  </button>
                  <span className="px-4 py-1.5 text-xs font-mono font-bold text-white tabular-nums">
                    {quantity}
                  </span>
                  <button
                    disabled={quantity >= currentStock}
                    onClick={() => setQuantity((q) => Math.min(currentStock, q + 1))}
                    className="px-3 py-1.5 text-sm text-neutral-400 hover:text-white disabled:opacity-30"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Add to Bag Action Button */}
              <div className="space-y-2 pt-2">
                <button
                  disabled={isSoldOut}
                  onClick={handleAddToCart}
                  className={`w-full py-3.5 px-6 text-xs font-black tracking-widest uppercase flex items-center justify-center gap-3 transition-all ${
                    isSoldOut
                      ? 'bg-[#1C1C1C] text-neutral-500 cursor-not-allowed'
                      : 'bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black shadow-lg shadow-black/50 cursor-pointer'
                  }`}
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>{isSoldOut ? t.outOfStock : `${t.addToCart} • ${(selectedProduct.price * quantity).toLocaleString()} ${t.currency}`}</span>
                </button>

                {addedNotice && (
                  <div className="p-2.5 bg-emerald-950/60 border border-emerald-800 text-emerald-300 text-xs flex items-center justify-center gap-2 animate-fadeIn">
                    <Check className="w-4 h-4" />
                    <span>{t.addedToCartSuccess}</span>
                  </div>
                )}
              </div>

              {/* Fabric Specs & Details Accordion / Preview */}
              <div className="pt-4 border-t border-[#222222] space-y-3 text-xs">
                <div>
                  <h4 className="font-bold text-neutral-300 flex items-center gap-1.5 uppercase tracking-wider text-[11px] mb-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#D4C3A3]" />
                    <span>{t.fabricSpecs}</span>
                  </h4>
                  <p className="text-neutral-400 leading-relaxed font-mono text-[11px]">
                    {fabric}
                  </p>
                </div>

                <div>
                  <h4 className="font-bold text-neutral-300 flex items-center gap-1.5 uppercase tracking-wider text-[11px] mb-1">
                    <Sparkles className="w-3.5 h-3.5 text-[#D4C3A3]" />
                    <span>{t.productFeatures}</span>
                  </h4>
                  <ul className="space-y-1 text-neutral-400 text-[11px]">
                    {details.map((detail, dIdx) => (
                      <li key={dIdx} className="flex items-start gap-2">
                        <span className="text-[#D4C3A3] mt-0.5">•</span>
                        <span>{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
