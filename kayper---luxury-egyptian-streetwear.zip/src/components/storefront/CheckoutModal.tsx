import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { PaymentMethod } from '../../types';
import { X, ShieldCheck, MapPin, Phone, CreditCard, Banknote, Smartphone, Check, AlertCircle } from 'lucide-react';
import confetti from 'canvas-confetti';

interface CheckoutModalProps {
  onOrderSuccess: (orderId: string) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ onOrderSuccess }) => {
  const {
    language,
    t,
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    cartSubtotal,
    cartDiscount,
    settings,
    governorates,
    createOrder,
    setActiveOrderForReceipt
  } = useStore();

  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [selectedGovId, setSelectedGovId] = useState('cairo');
  const [city, setCity] = useState('');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');
  const [paymentRef, setPaymentRef] = useState('');
  
  const [phoneError, setPhoneError] = useState('');
  const [formError, setFormError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isCheckoutOpen) return null;

  const currentGov = governorates.find((g) => g.id === selectedGovId) || governorates[0];
  const isFreeShipping = cartSubtotal >= settings.freeShippingThreshold;
  const shippingFee = isFreeShipping ? 0 : (currentGov ? currentGov.shippingFee : 50);
  const finalTotal = Math.max(0, cartSubtotal - cartDiscount) + shippingFee;

  // Egyptian Phone Validation Regex: 11 digits starting with 010, 011, 012, or 015
  const validateEgyptianPhone = (num: string): boolean => {
    const clean = num.replace(/\s+/g, '').trim();
    const regex = /^01[0125][0-9]{8}$/;
    return regex.test(clean);
  };

  const handlePhoneChange = (val: string) => {
    setPhone(val);
    if (val.length >= 11) {
      if (!validateEgyptianPhone(val)) {
        setPhoneError(t.phoneError);
      } else {
        setPhoneError('');
      }
    } else {
      setPhoneError('');
    }
  };

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!fullName.trim()) {
      setFormError(language === 'ar' ? 'يرجى كتابة الاسم بالكامل' : 'Please provide your full name');
      return;
    }

    if (!validateEgyptianPhone(phone)) {
      setPhoneError(t.phoneError);
      setFormError(t.phoneError);
      return;
    }

    if (!address.trim()) {
      setFormError(language === 'ar' ? 'يرجى كتابة عنوان الشحن بالتفصيل' : 'Please provide detailed delivery address');
      return;
    }

    if ((paymentMethod === 'instapay' || paymentMethod === 'vodafone_cash') && !paymentRef.trim()) {
      setFormError(
        language === 'ar'
          ? 'يرجى كتابة رقم العملية أو رقم المحفظة المحول منها'
          : 'Please provide the transaction reference or sender wallet number'
      );
      return;
    }

    setIsSubmitting(true);

    try {
      const newOrder = createOrder({
        customerName: fullName.trim(),
        customerPhone: phone.trim(),
        customerEmail: email.trim() || undefined,
        governorateId: selectedGovId,
        city: city.trim() || currentGov.nameEn,
        address: address.trim(),
        notes: notes.trim() || undefined,
        paymentMethod,
        paymentRef: paymentRef.trim() || undefined,
        shippingFee
      });

      // Fire celebratory confetti!
      try {
        confetti({
          particleCount: 90,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#D4C3A3', '#EAE1D1', '#BFA57B', '#ffffff']
        });
      } catch (e) {
        // Safe fallback
      }

      setIsSubmitting(false);
      setIsCheckoutOpen(false);
      setActiveOrderForReceipt(newOrder);
      onOrderSuccess(newOrder.id);
    } catch (err) {
      setIsSubmitting(false);
      setFormError(language === 'ar' ? 'حدث خطأ أثناء تسجيل الطلب' : 'An error occurred while creating order');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-[#111111] border border-[#262626] shadow-2xl text-[#EAE1D1] my-8 overflow-hidden">
        
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-[#212121] flex items-center justify-between bg-[#141414]">
          <div>
            <h3 className="font-['Syne',sans-serif] text-xl font-bold uppercase tracking-wider text-white">
              {t.checkoutTitle}
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              {t.checkoutSubtitle}
            </p>
          </div>
          <button
            onClick={() => setIsCheckoutOpen(false)}
            className="p-2 text-neutral-400 hover:text-white bg-[#1C1C1C] hover:bg-[#252525] transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmitOrder} className="p-5 sm:p-8 space-y-8 max-h-[80vh] overflow-y-auto">
          
          {formError && (
            <div className="p-3 bg-red-950/70 border border-red-800 text-red-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{formError}</span>
            </div>
          )}

          {/* Section 1: Customer Details */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-[#D4C3A3] uppercase tracking-widest flex items-center gap-2 border-b border-[#222222] pb-2">
              <Phone className="w-3.5 h-3.5" />
              <span>1. {t.customerInfo}</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-neutral-300 font-medium mb-1">
                  {t.fullName} *
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder={language === 'ar' ? 'مثال: أحمد محمود إبراهيم' : 'e.g. Ahmed Mahmoud'}
                  className="w-full bg-[#161616] border border-[#2B2B2B] focus:border-[#D4C3A3] px-3.5 py-2.5 text-xs text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs text-neutral-300 font-medium mb-1">
                  {t.phoneLabel} *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => handlePhoneChange(e.target.value)}
                  placeholder={t.phonePlaceholder}
                  className={`w-full bg-[#161616] border px-3.5 py-2.5 text-xs text-white focus:outline-none font-mono ${
                    phoneError ? 'border-red-500' : 'border-[#2B2B2B] focus:border-[#D4C3A3]'
                  }`}
                />
                {phoneError ? (
                  <p className="text-[11px] text-red-400 mt-1">{phoneError}</p>
                ) : (
                  <p className="text-[10px] text-neutral-500 mt-1">
                    {language === 'ar' ? '١١ رقماً تبدأ بـ 010 أو 011 أو 012 أو 015 للتواصل مع المندوب' : '11 digits starting with 010, 011, 012, or 015'}
                  </p>
                )}
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs text-neutral-300 font-medium mb-1">
                  {t.emailOptional}
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full bg-[#161616] border border-[#2B2B2B] focus:border-[#D4C3A3] px-3.5 py-2.5 text-xs text-white focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Egyptian Shipping Address & 27 Governorates */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-[#D4C3A3] uppercase tracking-widest flex items-center gap-2 border-b border-[#222222] pb-2">
              <MapPin className="w-3.5 h-3.5" />
              <span>2. {t.shippingAddress} (27 Governorates)</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-neutral-300 font-medium mb-1">
                  {t.governorate} *
                </label>
                <select
                  value={selectedGovId}
                  onChange={(e) => setSelectedGovId(e.target.value)}
                  className="w-full bg-[#161616] border border-[#2B2B2B] focus:border-[#D4C3A3] px-3 py-2.5 text-xs text-white focus:outline-none cursor-pointer"
                >
                  {governorates.map((gov) => (
                    <option key={gov.id} value={gov.id} className="bg-[#141414] text-white">
                      {language === 'ar' ? gov.nameAr : gov.nameEn} — {isFreeShipping ? t.freeShipping : `${gov.shippingFee} ${t.currency}`} ({gov.deliveryDays} {language === 'ar' ? 'أيام' : 'days'})
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-neutral-400 mt-1">
                  {language === 'ar' ? 'مدة التوصيل المقدرة:' : 'Estimated delivery:'}{' '}
                  <span className="text-[#D4C3A3] font-bold">{currentGov.deliveryDays} {language === 'ar' ? 'أيام عمل' : 'business days'}</span>
                </p>
              </div>

              <div>
                <label className="block text-xs text-neutral-300 font-medium mb-1">
                  {t.cityDistrict} *
                </label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder={language === 'ar' ? 'مثال: التجمع الخامس / مصر الجديدة / سموحة' : 'e.g. New Cairo / Zamalek / Smouha'}
                  className="w-full bg-[#161616] border border-[#2B2B2B] focus:border-[#D4C3A3] px-3.5 py-2.5 text-xs text-white focus:outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs text-neutral-300 font-medium mb-1">
                  {t.streetAddress} *
                </label>
                <textarea
                  required
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder={language === 'ar' ? 'اسم الشارع، رقم العمارة، رقم الشقة أو اسم الفيلا وعلامة مميزة' : 'Street name, building number, apartment/villa and landmarks'}
                  className="w-full bg-[#161616] border border-[#2B2B2B] focus:border-[#D4C3A3] px-3.5 py-2 text-xs text-white focus:outline-none resize-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs text-neutral-300 font-medium mb-1">
                  {t.deliveryNotes}
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder={language === 'ar' ? 'مثال: يرجى الاتصال قبل الوصول بنصف ساعة' : 'e.g. Please call 30 mins before arrival'}
                  className="w-full bg-[#161616] border border-[#2B2B2B] focus:border-[#D4C3A3] px-3.5 py-2 text-xs text-white focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Egyptian Payment Gateways */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold text-[#D4C3A3] uppercase tracking-widest flex items-center gap-2 border-b border-[#222222] pb-2">
              <CreditCard className="w-3.5 h-3.5" />
              <span>3. {t.paymentMethod}</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {/* Option 1: COD */}
              <div
                onClick={() => setPaymentMethod('cod')}
                className={`p-4 border cursor-pointer transition-all ${
                  paymentMethod === 'cod'
                    ? 'border-[#D4C3A3] bg-[#1C1A16]'
                    : 'border-[#262626] bg-[#141414] hover:border-neutral-500'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <Banknote className="w-4 h-4 text-[#D4C3A3]" />
                  <span className="text-xs font-bold text-white uppercase">{language === 'ar' ? 'الدفع عند الاستلام' : 'Cash on Delivery'}</span>
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  {t.codDesc}
                </p>
              </div>

              {/* Option 2: InstaPay */}
              <div
                onClick={() => setPaymentMethod('instapay')}
                className={`p-4 border cursor-pointer transition-all ${
                  paymentMethod === 'instapay'
                    ? 'border-[#D4C3A3] bg-[#1C1A16]'
                    : 'border-[#262626] bg-[#141414] hover:border-neutral-500'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <Smartphone className="w-4 h-4 text-[#D4C3A3]" />
                  <span className="text-xs font-bold text-white uppercase">{t.instapayTitle}</span>
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  {t.instapayDesc}
                </p>
              </div>

              {/* Option 3: Vodafone Cash */}
              <div
                onClick={() => setPaymentMethod('vodafone_cash')}
                className={`p-4 border cursor-pointer transition-all ${
                  paymentMethod === 'vodafone_cash'
                    ? 'border-[#D4C3A3] bg-[#1C1A16]'
                    : 'border-[#262626] bg-[#141414] hover:border-neutral-500'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <CreditCard className="w-4 h-4 text-[#D4C3A3]" />
                  <span className="text-xs font-bold text-white uppercase">{t.vodafoneTitle}</span>
                </div>
                <p className="text-[11px] text-neutral-400 leading-relaxed">
                  {t.vodafoneDesc}
                </p>
              </div>
            </div>

            {/* Payment Details Drawer if InstaPay / Vodafone Cash selected */}
            {paymentMethod === 'instapay' && (
              <div className="p-4 bg-[#171717] border border-[#2E2E2E] space-y-3 animate-fadeIn">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#262626]">
                  <span className="text-xs text-neutral-400">{t.instapayHandle}</span>
                  <span className="text-xs font-mono font-bold text-[#D4C3A3] bg-black/60 px-3 py-1 border border-[#333333]">
                    {settings.instapayAccount}
                  </span>
                </div>
                <div>
                  <label className="block text-xs text-neutral-300 font-medium mb-1">
                    {t.instapayRefPrompt} *
                  </label>
                  <input
                    type="text"
                    required
                    value={paymentRef}
                    onChange={(e) => setPaymentRef(e.target.value)}
                    placeholder={t.instapayRefPlaceholder}
                    className="w-full bg-[#121212] border border-[#2B2B2B] focus:border-[#D4C3A3] px-3 py-2 text-xs text-white focus:outline-none font-mono"
                  />
                  <p className="text-[10px] text-neutral-500 mt-1">
                    {language === 'ar' ? 'حول المبلغ الإجمالي عبر تطبيق إنستاباي ثم اكتب رقم المرجع للتأكيد الفوري' : 'Transfer total via InstaPay app then enter reference number here'}
                  </p>
                </div>
              </div>
            )}

            {paymentMethod === 'vodafone_cash' && (
              <div className="p-4 bg-[#171717] border border-[#2E2E2E] space-y-3 animate-fadeIn">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#262626]">
                  <span className="text-xs text-neutral-400">{t.vodafoneWalletNumber}</span>
                  <span className="text-xs font-mono font-bold text-[#D4C3A3] bg-black/60 px-3 py-1 border border-[#333333]">
                    {settings.vodafoneCashWallet}
                  </span>
                </div>
                <div>
                  <label className="block text-xs text-neutral-300 font-medium mb-1">
                    {t.vodafoneRefPrompt} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={paymentRef}
                    onChange={(e) => setPaymentRef(e.target.value)}
                    placeholder={t.vodafoneRefPlaceholder}
                    className="w-full bg-[#121212] border border-[#2B2B2B] focus:border-[#D4C3A3] px-3 py-2 text-xs text-white focus:outline-none font-mono"
                  />
                  <p className="text-[10px] text-neutral-500 mt-1">
                    {language === 'ar' ? 'قم بتحويل الإجمالي لمحفظتنا واكتب رقم هاتفك الذي قمت بالتحويل منه' : 'Transfer to our business wallet and enter your sender phone number'}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Section 4: Final Summary & Place Order */}
          <div className="p-4 bg-[#141414] border border-[#262626] space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              {t.orderSummary} ({cart.length} {language === 'ar' ? 'قطع' : 'items'})
            </h4>

            <div className="space-y-1.5 text-xs text-neutral-400">
              <div className="flex justify-between">
                <span>{t.subtotal}</span>
                <span className="font-mono tabular-nums text-white">
                  {cartSubtotal.toLocaleString()} {t.currency}
                </span>
              </div>

              {cartDiscount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>{t.discount}</span>
                  <span className="font-mono tabular-nums">
                    -{cartDiscount.toLocaleString()} {t.currency}
                  </span>
                </div>
              )}

              <div className="flex justify-between">
                <span>
                  {t.estimatedShipping} ({language === 'ar' ? currentGov.nameAr : currentGov.nameEn})
                </span>
                <span className="font-mono tabular-nums text-[#D4C3A3]">
                  {shippingFee === 0 ? t.freeShipping : `${shippingFee} ${t.currency}`}
                </span>
              </div>

              <div className="flex justify-between text-base font-extrabold text-white pt-2 border-t border-[#262626]">
                <span>{t.total}</span>
                <span className="font-mono tabular-nums text-[#EAE1D1]">
                  {finalTotal.toLocaleString()} {t.currency}
                </span>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || cart.length === 0}
              className="w-full py-4 px-6 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-black tracking-widest uppercase flex items-center justify-center gap-2 transition-all shadow-xl shadow-black/60 cursor-pointer disabled:opacity-50 mt-4"
            >
              {isSubmitting ? (
                <span>{t.placingOrder}</span>
              ) : (
                <>
                  <Check className="w-4 h-4" />
                  <span>
                    {language === 'ar'
                      ? `تأكيد وإرسال الطلب (${finalTotal.toLocaleString()} ج.م)`
                      : `Confirm & Place Order (${finalTotal.toLocaleString()} EGP)`}
                  </span>
                </>
              )}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
