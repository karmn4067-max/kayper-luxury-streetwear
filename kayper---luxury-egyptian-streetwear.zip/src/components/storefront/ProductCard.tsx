import React, { useState } from 'react';
import { Product, ProductSize } from '../../types';
import { useStore } from '../../context/StoreContext';
import { Heart, Eye, ShoppingBag, Edit2, Trash2 } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const {
    language,
    t,
    toggleWishlist,
    isInWishlist,
    setSelectedProduct,
    addToCart,
    isAdminAuthenticated,
    setIsAdminOpen,
    setAdminEditingProduct,
    setAdminActiveTab,
    deleteProduct
  } = useStore();
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<ProductSize>(product.sizes[0] || 'M');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const isFav = isInWishlist(product.id);
  const name = language === 'ar' ? product.nameAr : product.nameEn;
  const currentStockForSize = product.inventory[selectedSize] ?? 0;
  const isLowStock = currentStockForSize > 0 && currentStockForSize <= 4;
  const isSoldOut = currentStockForSize === 0;

  // Calculate discount percentage
  const discountPercent = product.compareAtPrice
    ? Math.round(((product.compareAtPrice - product.price) / product.compareAtPrice) * 100)
    : null;

  return (
    <div className="group relative flex flex-col bg-[#111111] border border-[#212121] hover:border-[#383838] transition-all duration-300">
      
      {/* Visual Image Container */}
      <div className="relative aspect-[4/5] w-full overflow-hidden bg-[#161616]">
        <img
          src={product.images[activeImageIndex] || product.images[0]}
          alt={name}
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover object-center filter contrast-[1.03] group-hover:scale-105 transition-transform duration-500 ease-out cursor-pointer"
          onClick={() => setSelectedProduct(product)}
        />

        {/* Hover Secondary Image Thumbnail Peek if product has multiple */}
        {product.images.length > 1 && (
          <div className="absolute bottom-2 left-2 right-2 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity z-10">
            {product.images.slice(0, 3).map((img, idx) => (
              <button
                key={idx}
                onMouseEnter={() => setActiveImageIndex(idx)}
                className={`w-7 h-9 border overflow-hidden ${
                  activeImageIndex === idx ? 'border-[#D4C3A3]' : 'border-black/50'
                }`}
              >
                <img src={img} alt="thumbnail" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        )}

        {/* Floating Actions: Wishlist & Quick View */}
        <div className="absolute top-2.5 right-2.5 rtl:right-auto rtl:left-2.5 flex flex-col gap-2 z-20">
          <button
            onClick={() => toggleWishlist(product.id)}
            className={`p-2 transition-all backdrop-blur-md shadow-md ${
              isFav
                ? 'bg-[#D4C3A3] text-black'
                : 'bg-black/60 text-white hover:text-[#D4C3A3] hover:bg-black/90'
            }`}
            aria-label="Toggle Wishlist"
            title={t.wishlist}
          >
            <Heart className={`w-4 h-4 ${isFav ? 'fill-black' : ''}`} />
          </button>

          <button
            onClick={() => setSelectedProduct(product)}
            className="p-2 bg-black/60 hover:bg-black/90 text-white hover:text-[#D4C3A3] backdrop-blur-md transition-all shadow-md"
            aria-label="Quick View"
            title={t.quickView}
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>

        {/* Admin Direct Management Controls (Shown when Admin is Logged In) */}
        {isAdminAuthenticated && (
          <div className="absolute top-2.5 left-2.5 rtl:left-auto rtl:right-2.5 flex items-center gap-1.5 z-30">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setAdminEditingProduct(product);
                setAdminActiveTab('products');
                setIsAdminOpen(true);
              }}
              className="p-1.5 bg-[#D4C3A3] text-black hover:bg-white text-[11px] font-bold uppercase flex items-center gap-1 shadow-lg cursor-pointer transition-transform active:scale-95"
              title={language === 'ar' ? 'تعديل الصنف' : 'Edit Product'}
            >
              <Edit2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{language === 'ar' ? 'تعديل' : 'Edit'}</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowDeleteConfirm(true);
              }}
              className="p-1.5 bg-red-600 text-white hover:bg-red-700 text-[11px] font-bold uppercase flex items-center gap-1 shadow-lg cursor-pointer transition-transform active:scale-95"
              title={language === 'ar' ? 'حذف الصنف' : 'Delete Product'}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{language === 'ar' ? 'حذف' : 'Del'}</span>
            </button>
          </div>
        )}

        {/* Discount Badge (shifted if admin is logged in) */}
        {discountPercent && !isAdminAuthenticated && (
          <div className="absolute top-2.5 left-2.5 rtl:left-auto rtl:right-2.5 bg-[#D4C3A3] text-black text-[10px] font-black px-2 py-1 tracking-wider uppercase">
            -{discountPercent}%
          </div>
        )}

        {/* Delete Confirmation Modal for Card */}
        {showDeleteConfirm && (
          <div className="absolute inset-0 bg-black/95 z-40 p-4 flex flex-col items-center justify-center text-center space-y-2 animate-fadeIn">
            <p className="text-xs text-white font-bold">
              {language === 'ar' ? 'هل أنت متأكد من حذف هذا الصنف نهائياً؟' : 'Permanently delete this product?'}
            </p>
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowDeleteConfirm(false);
                }}
                className="px-2.5 py-1 bg-neutral-800 text-white text-[10px] font-bold uppercase"
              >
                {t.cancel}
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  deleteProduct(product.id);
                  setShowDeleteConfirm(false);
                }}
                className="px-2.5 py-1 bg-red-600 text-white text-[10px] font-bold uppercase"
              >
                {t.deleteProduct}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Content Section */}
      <div className="flex flex-col flex-1 p-3 sm:p-5 space-y-2 sm:space-y-3">
        {/* Category & Tag unboxed metadata */}
        <div className="flex items-center justify-between text-[10px] sm:text-[11px] text-neutral-400 font-mono tracking-wider">
          <span className="uppercase text-[#D4C3A3] truncate max-w-[100px]">{product.category}</span>
          <span>{product.sku}</span>
        </div>

        {/* Title */}
        <h3
          onClick={() => setSelectedProduct(product)}
          className="font-bold text-xs sm:text-base text-white hover:text-[#D4C3A3] transition-colors cursor-pointer line-clamp-1"
        >
          {name}
        </h3>

        {/* Price Row */}
        <div className="flex items-baseline gap-1.5 sm:gap-2.5 font-mono">
          <span className="text-sm sm:text-lg font-extrabold text-[#EAE1D1] tabular-nums">
            {product.price.toLocaleString()} {t.currency}
          </span>
          {product.compareAtPrice && (
            <span className="text-[10px] sm:text-xs text-neutral-500 line-through tabular-nums">
              {product.compareAtPrice.toLocaleString()} {t.currency}
            </span>
          )}
        </div>

        {/* Size Selection Chips */}
        <div className="space-y-1 pt-0.5">
          <div className="flex items-center justify-between text-[10px] sm:text-[11px] text-neutral-400">
            <span>{t.selectSize}:</span>
            {isLowStock && (
              <span className="text-amber-400 font-medium text-[9px] sm:text-[10px]">
                {language === 'ar'
                  ? `باقي ${currentStockForSize} فقط (${selectedSize})`
                  : `${currentStockForSize} left (${selectedSize})`}
              </span>
            )}
            {isSoldOut && (
              <span className="text-red-400 text-[9px] sm:text-[10px]">{t.outOfStock}</span>
            )}
          </div>
          <div className="flex items-center gap-1 sm:gap-1.5 flex-wrap">
            {product.sizes.map((sz) => {
              const stock = product.inventory[sz] ?? 0;
              const isSelected = selectedSize === sz;
              return (
                <button
                  key={sz}
                  disabled={stock === 0}
                  onClick={() => setSelectedSize(sz)}
                  className={`min-h-[28px] sm:min-h-[32px] px-2 sm:px-2.5 py-0.5 sm:py-1 text-[10px] sm:text-xs font-mono font-bold transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#D4C3A3] text-black'
                      : stock === 0
                      ? 'bg-[#181818] text-neutral-600 line-through cursor-not-allowed border border-[#222222]'
                      : 'bg-[#181818] text-neutral-300 hover:border-[#D4C3A3] border border-[#2B2B2B]'
                  }`}
                >
                  {sz}
                </button>
              );
            })}
          </div>
        </div>

        {/* Color Swatches */}
        {product.colors && product.colors.length > 0 && (
          <div className="flex items-center gap-1 sm:gap-1.5 pt-0.5">
            {product.colors.map((c, i) => (
              <span
                key={i}
                title={language === 'ar' ? c.nameAr : c.nameEn}
                style={{ backgroundColor: c.hex }}
                className="w-3 sm:w-3.5 h-3 sm:h-3.5 rounded-full border border-neutral-600 inline-block shadow-inner"
              />
            ))}
            <span className="text-[10px] sm:text-[11px] text-neutral-500 ml-1 rtl:mr-1 rtl:ml-0 truncate">
              {language === 'ar' ? product.colors[0].nameAr : product.colors[0].nameEn}
            </span>
          </div>
        )}

        {/* Primary Card CTA */}
        <div className="pt-2 mt-auto">
          <button
            disabled={isSoldOut}
            onClick={() => {
              addToCart(product, selectedSize, product.colors[0] || { nameEn: 'Standard', nameAr: 'قياسي', hex: '#000000' }, 1);
            }}
            className={`w-full min-h-[38px] sm:min-h-[42px] py-2 sm:py-2.5 px-2 sm:px-4 text-[10px] sm:text-xs font-extrabold tracking-wider uppercase flex items-center justify-center gap-1.5 sm:gap-2 transition-all ${
              isSoldOut
                ? 'bg-[#1C1C1C] text-neutral-500 cursor-not-allowed'
                : 'bg-[#1F1F1F] hover:bg-[#D4C3A3] text-white hover:text-black border border-[#2E2E2E] hover:border-[#D4C3A3] active:scale-[0.98] cursor-pointer'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>{isSoldOut ? t.outOfStock : t.addToCart}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
