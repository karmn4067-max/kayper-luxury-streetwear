import React from 'react';
import { useStore } from '../../context/StoreContext';
import { CheckCircle2, Printer, MapPin, ArrowRight } from 'lucide-react';

interface OrderSuccessModalProps {
  orderId: string | null;
  onClose: () => void;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({ orderId, onClose }) => {
  const {
    language,
    t,
    orders,
    setActiveOrderForReceipt,
    setIsTrackingOpen
  } = useStore();

  if (!orderId) return null;

  const order = orders.find((o) => o.id === orderId);
  if (!order) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="relative w-full max-w-lg bg-[#111111] border border-[#2B2B2B] shadow-2xl p-6 sm:p-8 text-center text-[#EAE1D1]">
        
        {/* Success Icon */}
        <div className="mx-auto w-16 h-16 bg-[#1A1A1A] border border-[#D4C3A3]/40 flex items-center justify-center mb-5 text-[#D4C3A3]">
          <CheckCircle2 className="w-9 h-9" />
        </div>

        <h3 className="font-['Syne',sans-serif] text-2xl font-bold uppercase text-white tracking-tight mb-2">
          {t.orderSuccessTitle}
        </h3>

        <p className="text-xs text-neutral-400 mb-6 leading-relaxed">
          {t.orderSuccessSubtitle}
        </p>

        {/* Order Number Box */}
        <div className="p-4 bg-[#161616] border border-[#262626] mb-6 flex flex-col items-center justify-center">
          <span className="text-[11px] font-mono uppercase text-neutral-500 mb-1">
            {t.orderIdLabel}
          </span>
          <span className="font-mono text-2xl font-black text-[#D4C3A3] tracking-wider">
            {order.id}
          </span>
          <span className="text-[11px] text-neutral-400 mt-2">
            {language === 'ar' ? 'المبلغ الإجمالي المطلوبة:' : 'Total Payable:'}{' '}
            <strong className="text-white font-mono">{order.total.toLocaleString()} {t.currency}</strong>
          </span>
        </div>

        {/* Shipping summary */}
        <div className="text-xs text-neutral-400 text-left rtl:text-right bg-[#141414] p-3 border border-[#222222] mb-6 space-y-1">
          <div className="flex justify-between">
            <span className="text-neutral-500">{t.fullName}:</span>
            <span className="text-white font-medium">{order.customerName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-neutral-500">{t.phoneLabel}:</span>
            <span className="text-white font-mono">{order.customerPhone}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-neutral-500">{t.governorate}:</span>
            <span className="text-white">{order.governorateNameAr || order.governorateNameEn}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => {
              setActiveOrderForReceipt(order);
            }}
            className="flex-1 py-3 px-4 bg-[#1F1F1F] hover:bg-[#282828] text-white border border-[#2E2E2E] text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <Printer className="w-4 h-4 text-[#D4C3A3]" />
            <span>{language === 'ar' ? 'طباعة الفاتورة' : 'Print Invoice'}</span>
          </button>

          <button
            onClick={() => {
              onClose();
              setIsTrackingOpen(true);
            }}
            className="flex-1 py-3 px-4 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <MapPin className="w-4 h-4" />
            <span>{t.trackOrderBtn}</span>
          </button>
        </div>

        <button
          onClick={onClose}
          className="mt-4 text-xs text-neutral-500 hover:text-white underline transition-colors"
        >
          {t.backToStore}
        </button>

      </div>
    </div>
  );
};
