import React from 'react';
import { useStore } from '../../context/StoreContext';
import { ProductCard } from './ProductCard';
import { SlidersHorizontal, SearchX } from 'lucide-react';
import { Category } from '../../types';

export const ProductGrid: React.FC = () => {
  const {
    language,
    t,
    products,
    activeCategory,
    setActiveCategory,
    searchQuery,
    setSearchQuery,
    sortBy,
    setSortBy
  } = useStore();

  const categories: { id: Category | 'all'; label: string }[] = [
    { id: 'all', label: t.filterAll },
    { id: 'hoodies', label: t.hoodies },
    { id: 'tshirts', label: t.tshirts },
    { id: 'cargos', label: t.cargos },
    { id: 'jackets', label: t.jackets },
    { id: 'accessories', label: t.accessories }
  ];

  // Filtering
  const filteredProducts = products.filter((p) => {
    const matchesCategory = activeCategory === 'all' || p.category === activeCategory;
    const query = searchQuery.trim().toLowerCase();
    const matchesSearch =
      query === '' ||
      p.nameEn.toLowerCase().includes(query) ||
      p.nameAr.toLowerCase().includes(query) ||
      p.sku.toLowerCase().includes(query) ||
      p.descriptionEn.toLowerCase().includes(query) ||
      p.descriptionAr.toLowerCase().includes(query);
    return matchesCategory && matchesSearch;
  });

  // Sorting
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    if (sortBy === 'popular') return (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0);
    // newest
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  return (
    <section id="catalog-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      
      {/* Header & Filter Controls Bar */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-8 border-b border-[#212121]">
        <div>
          <div className="text-xs uppercase font-mono tracking-widest text-[#D4C3A3] mb-1">
            {language === 'ar' ? 'تشكيلة الشارع الحصرية' : 'EXCLUSIVE STREETWEAR ARCHIVE'}
          </div>
          <h2 className="font-['Syne',sans-serif] text-2xl sm:text-3xl font-extrabold uppercase text-white tracking-tight">
            {activeCategory === 'all'
              ? t.allProducts
              : categories.find((c) => c.id === activeCategory)?.label}
          </h2>
        </div>

        {/* Filters and Sort */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Category Tabs */}
          <div className="flex items-center gap-1 p-1 bg-[#141414] border border-[#262626] overflow-x-auto no-scrollbar">
            {categories.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-colors cursor-pointer ${
                    isActive
                      ? 'bg-[#D4C3A3] text-black shadow-sm'
                      : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  {cat.label}
                </button>
              );
            })}
          </div>

          {/* Sort Dropdown */}
          <div className="flex items-center gap-2 bg-[#141414] border border-[#262626] px-3 py-1.5 text-xs text-neutral-300">
            <SlidersHorizontal className="w-3.5 h-3.5 text-[#D4C3A3] shrink-0" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent text-xs text-[#EAE1D1] focus:outline-none cursor-pointer"
            >
              <option value="newest" className="bg-[#141414] text-white">
                {t.sortNewest}
              </option>
              <option value="price-asc" className="bg-[#141414] text-white">
                {t.sortPriceLow}
              </option>
              <option value="price-desc" className="bg-[#141414] text-white">
                {t.sortPriceHigh}
              </option>
              <option value="popular" className="bg-[#141414] text-white">
                {t.sortPopular}
              </option>
            </select>
          </div>
        </div>
      </div>

      {/* Active Search Filter Chip */}
      {searchQuery && (
        <div className="flex items-center justify-between py-3 px-4 bg-[#141414] border border-[#222222] my-4 text-xs text-neutral-300">
          <span>
            {language === 'ar' ? 'نتائج البحث عن:' : 'Search results for:'}{' '}
            <strong className="text-[#D4C3A3]">"{searchQuery}"</strong> ({sortedProducts.length})
          </span>
          <button
            onClick={() => setSearchQuery('')}
            className="text-neutral-400 hover:text-white underline cursor-pointer"
          >
            {language === 'ar' ? 'مسح البحث' : 'Clear search'}
          </button>
        </div>
      )}

      {/* Product Cards Grid */}
      {sortedProducts.length > 0 ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6 lg:gap-8 pt-6 sm:pt-8">
          {sortedProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <div className="py-20 text-center flex flex-col items-center justify-center space-y-4">
          <div className="p-4 bg-[#141414] border border-[#262626] text-neutral-500 rounded-full">
            <SearchX className="w-8 h-8 text-[#D4C3A3]" />
          </div>
          <h3 className="text-lg font-bold text-white">
            {language === 'ar' ? 'لم نجد أي قطع مطابقة لبحثك' : 'No items match your criteria'}
          </h3>
          <p className="text-xs text-neutral-400 max-w-sm">
            {language === 'ar'
              ? 'يرجى تجربة كلمات بحث أخرى أو إزالة الفلاتر لتصفح جميع قطع كايبر الفاخرة.'
              : 'Try altering your search keywords or resetting filters to explore our full luxury drop.'}
          </p>
          <button
            onClick={() => {
              setActiveCategory('all');
              setSearchQuery('');
            }}
            className="px-6 py-2.5 bg-[#D4C3A3] text-black text-xs font-bold uppercase tracking-wider hover:bg-[#EAE1D1] transition-colors"
          >
            {language === 'ar' ? 'عرض كل القطع' : 'View All Pieces'}
          </button>
        </div>
      )}

    </section>
  );
};
