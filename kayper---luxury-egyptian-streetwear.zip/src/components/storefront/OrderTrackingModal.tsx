import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { Order, OrderStatus } from '../../types';
import { Search, X, CheckCircle2, Clock, Truck, Package, Printer, AlertCircle } from 'lucide-react';

export const OrderTrackingModal: React.FC = () => {
  const {
    language,
    t,
    isTrackingOpen,
    setIsTrackingOpen,
    orders,
    setActiveOrderForReceipt
  } = useStore();

  const [query, setQuery] = useState('');
  const [matchedOrder, setMatchedOrder] = useState<Order | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  if (!isTrackingOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = query.trim().toUpperCase();
    if (!clean) return;

    setHasSearched(true);
    // Search by order ID or phone
    const found = orders.find(
      (o) =>
        o.id.toUpperCase() === clean ||
        o.customerPhone.replace(/\s+/g, '') === query.trim().replace(/\s+/g, '')
    );
    setMatchedOrder(found || null);
  };

  const steps: { status: OrderStatus; labelEn: string; labelAr: string; descEn: string; descAr: string }[] = [
    {
      status: 'pending',
      labelEn: 'Order Received',
      labelAr: 'تم استلام الطلب',
      descEn: 'Your luxury order is confirmed and queued for fulfillment.',
      descAr: 'تم تسجيل طلبك بنجاح وجارٍ مراجعته وتأكيد بيانات الشحن.'
    },
    {
      status: 'processing',
      labelEn: 'Cairo Warehouse Packing',
      labelAr: 'التجهيز بمستودع القاهرة',
      descEn: 'Heavyweight fabrics inspected and packaged in protective archival bags.',
      descAr: 'فحص جودة الأقمشة وتغليف القطع في عبوات كايبر الفاخرة.'
    },
    {
      status: 'shipped',
      labelEn: 'Dispatched with Courier',
      labelAr: 'تم تسليم الشحنة للمندوب',
      descEn: 'Transferred to our express delivery fleet with live GPS route.',
      descAr: 'الشحنة مع شركة التوصيل السريع وفي طريقها إلى محافظتك.'
    },
    {
      status: 'delivered',
      labelEn: 'Delivered to Customer',
      labelAr: 'تم التوصيل بنجاح',
      descEn: 'Package delivered and payment completed. Enjoy your KAYPER piece.',
      descAr: 'تم تسليم الطلبية للعميل وسداد القيمة بنجاح.'
    }
  ];

  const getStepIndex = (status: OrderStatus): number => {
    switch (status) {
      case 'pending':
        return 0;
      case 'processing':
        return 1;
      case 'shipped':
        return 2;
      case 'delivered':
        return 3;
      case 'cancelled':
        return -1;
      default:
        return 0;
    }
  };

  const currentStepIdx = matchedOrder ? getStepIndex(matchedOrder.status) : 0;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-[#111111] border border-[#2B2B2B] shadow-2xl p-6 sm:p-8 text-[#EAE1D1]">
        
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-[#222222]">
          <div>
            <h3 className="font-['Syne',sans-serif] text-xl font-bold uppercase text-white tracking-wider">
              {t.trackingTitle}
            </h3>
            <p className="text-xs text-neutral-400 mt-1">
              {t.trackingSubtitle}
            </p>
          </div>
          <button
            onClick={() => {
              setIsTrackingOpen(false);
              setMatchedOrder(null);
              setQuery('');
              setHasSearched(false);
            }}
            className="p-1.5 text-neutral-400 hover:text-white bg-[#1A1A1A] hover:bg-[#252525] transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="my-6">
          <div className="flex items-center bg-[#161616] border border-[#2E2E2E] focus-within:border-[#D4C3A3]">
            <Search className="w-4 h-4 text-neutral-500 mx-3 shrink-0" />
            <input
              type="text"
              required
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={t.searchByOrderIdOrPhone}
              className="w-full bg-transparent border-none py-3 text-xs text-white placeholder:text-neutral-500 focus:outline-none font-mono"
            />
            <button
              type="submit"
              className="px-5 py-3 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-bold uppercase tracking-wider transition-colors shrink-0"
            >
              {t.trackBtn}
            </button>
          </div>
          <div className="flex items-center gap-2 mt-2 text-[11px] text-neutral-500">
            <span>{language === 'ar' ? 'طلب تجريبي للاختبار:' : 'Demo order to test:'}</span>
            <button
              type="button"
              onClick={() => {
                setQuery('KYP-9482');
              }}
              className="text-[#D4C3A3] underline font-mono"
            >
              KYP-9482
            </button>
            <span>/</span>
            <button
              type="button"
              onClick={() => {
                setQuery('01012345678');
              }}
              className="text-[#D4C3A3] underline font-mono"
            >
              01012345678
            </button>
          </div>
        </form>

        {/* Search Results */}
        {hasSearched && !matchedOrder && (
          <div className="p-4 bg-red-950/40 border border-red-900/60 text-red-300 text-xs flex items-center gap-3">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{t.orderNotFound}</span>
          </div>
        )}

        {matchedOrder && (
          <div className="space-y-6 pt-2 animate-fadeIn">
            {/* Status Card */}
            <div className="p-4 bg-[#161616] border border-[#262626] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-base font-extrabold text-[#D4C3A3]">
                    {matchedOrder.id}
                  </span>
                  <span className="text-xs text-neutral-400">·</span>
                  <span className="text-xs text-neutral-300 font-bold uppercase">
                    {matchedOrder.customerName}
                  </span>
                </div>
                <p className="text-[11px] text-neutral-500 mt-0.5">
                  {matchedOrder.governorateNameAr || matchedOrder.governorateNameEn} - {matchedOrder.city} ({matchedOrder.address})
                </p>
              </div>

              <button
                onClick={() => setActiveOrderForReceipt(matchedOrder)}
                className="flex items-center gap-2 px-3 py-1.5 bg-[#222222] hover:bg-[#D4C3A3] text-neutral-200 hover:text-black border border-[#2E2E2E] text-xs font-bold uppercase transition-colors shrink-0"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{language === 'ar' ? 'طباعة الفاتورة' : 'Print Invoice'}</span>
              </button>
            </div>

            {/* Cancelled Notice */}
            {matchedOrder.status === 'cancelled' && (
              <div className="p-3 bg-red-950/60 border border-red-800 text-red-300 text-xs">
                {t.statusCancelled}
              </div>
            )}

            {/* Progress Stepper Timeline */}
            {matchedOrder.status !== 'cancelled' && (
              <div className="space-y-6 py-2">
                <div className="relative pl-6 rtl:pl-0 rtl:pr-6 space-y-8 before:absolute before:left-2.5 rtl:before:left-auto rtl:before:right-2.5 before:top-2 before:bottom-2 before:w-[2px] before:bg-[#262626]">
                  {steps.map((step, idx) => {
                    const isDone = currentStepIdx >= idx;
                    const isCurrent = currentStepIdx === idx;

                    return (
                      <div key={step.status} className="relative flex items-start gap-4">
                        {/* Dot Icon */}
                        <div
                          className={`absolute -left-6 rtl:-left-auto rtl:-right-6 top-0 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold border ${
                            isCurrent
                              ? 'bg-[#D4C3A3] border-white text-black shadow-lg shadow-[#D4C3A3]/20 ring-4 ring-[#D4C3A3]/20'
                              : isDone
                              ? 'bg-black border-[#D4C3A3] text-[#D4C3A3]'
                              : 'bg-[#181818] border-[#333333] text-neutral-600'
                          }`}
                        >
                          {isDone ? '✓' : idx + 1}
                        </div>

                        {/* Text */}
                        <div>
                          <h4
                            className={`text-xs font-bold uppercase tracking-wider ${
                              isCurrent
                                ? 'text-[#D4C3A3]'
                                : isDone
                                ? 'text-white'
                                : 'text-neutral-500'
                            }`}
                          >
                            {language === 'ar' ? step.labelAr : step.labelEn}
                          </h4>
                          <p className="text-[11px] text-neutral-400 mt-0.5 leading-relaxed">
                            {language === 'ar' ? step.descAr : step.descEn}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Order Items Preview */}
            <div className="p-3.5 bg-[#141414] border border-[#242424] space-y-2">
              <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider block">
                {language === 'ar' ? 'القطع المشحونة:' : 'Shipped Items:'}
              </span>
              <div className="divide-y divide-[#1F1F1F]">
                {matchedOrder.items.map((item, i) => (
                  <div key={i} className="py-2 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[#D4C3A3]">{item.quantity}x</span>
                      <span className="text-white font-medium">
                        {language === 'ar' ? item.nameAr : item.nameEn}
                      </span>
                      <span className="text-neutral-500 font-mono text-[11px]">({item.size})</span>
                    </div>
                    <span className="font-mono tabular-nums text-neutral-300">
                      {(item.price * item.quantity).toLocaleString()} {t.currency}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex justify-between items-center pt-2 border-t border-[#262626] text-xs">
                <span className="text-neutral-400">{t.total}:</span>
                <span className="font-mono font-bold text-[#EAE1D1]">
                  {matchedOrder.total.toLocaleString()} {t.currency}
                </span>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
