import React from 'react';
import { useStore } from '../../context/StoreContext';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';

export const WishlistDrawer: React.FC = () => {
  const {
    language,
    t,
    isWishlistOpen,
    setIsWishlistOpen,
    wishlist,
    products,
    toggleWishlist,
    setSelectedProduct
  } = useStore();

  if (!isWishlistOpen) return null;

  const wishlistProducts = products.filter((p) => wishlist.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div className="absolute inset-0" onClick={() => setIsWishlistOpen(false)} />

      <div className="fixed inset-y-0 right-0 rtl:right-auto rtl:left-0 max-w-full flex pl-10 rtl:pl-0 rtl:pr-10">
        <div className="w-screen max-w-md bg-[#111111] border-l rtl:border-l-0 rtl:border-r border-[#262626] text-[#EAE1D1] flex flex-col shadow-2xl">
          
          {/* Header */}
          <div className="p-5 border-b border-[#212121] flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <Heart className="w-5 h-5 text-[#D4C3A3] fill-[#D4C3A3]" />
              <h3 className="font-['Syne',sans-serif] text-base font-bold uppercase tracking-wider text-white">
                {t.wishlistTitle} ({wishlistProducts.length})
              </h3>
            </div>
            <button
              onClick={() => setIsWishlistOpen(false)}
              className="p-1.5 text-neutral-400 hover:text-white bg-[#1A1A1A] hover:bg-[#262626] transition-colors"
              aria-label="Close wishlist"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* List */}
          <div className="flex-1 overflow-y-auto p-5 space-y-4">
            {wishlistProducts.length === 0 ? (
              <div className="py-20 flex flex-col items-center justify-center text-center space-y-4 text-neutral-400">
                <div className="p-4 bg-[#161616] border border-[#262626] rounded-full text-neutral-500">
                  <Heart className="w-8 h-8 text-[#D4C3A3]" />
                </div>
                <p className="text-sm font-medium text-white">{t.wishlistEmpty}</p>
                <button
                  onClick={() => setIsWishlistOpen(false)}
                  className="px-6 py-2.5 bg-[#D4C3A3] text-black text-xs font-bold uppercase tracking-wider hover:bg-[#EAE1D1] transition-colors"
                >
                  {t.startShopping}
                </button>
              </div>
            ) : (
              wishlistProducts.map((product) => {
                const name = language === 'ar' ? product.nameAr : product.nameEn;
                return (
                  <div
                    key={product.id}
                    className="flex gap-4 p-3 bg-[#161616] border border-[#242424] items-center"
                  >
                    <div
                      className="w-16 h-20 bg-[#1c1c1c] overflow-hidden shrink-0 border border-[#2b2b2b] cursor-pointer"
                      onClick={() => {
                        setSelectedProduct(product);
                        setIsWishlistOpen(false);
                      }}
                    >
                      <img
                        src={product.images[0]}
                        alt={name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover object-center"
                      />
                    </div>

                    <div className="flex-1 min-w-0 space-y-1">
                      <h4
                        onClick={() => {
                          setSelectedProduct(product);
                          setIsWishlistOpen(false);
                        }}
                        className="text-xs font-bold text-white hover:text-[#D4C3A3] cursor-pointer truncate"
                      >
                        {name}
                      </h4>
                      <div className="font-mono text-xs font-bold text-[#EAE1D1] tabular-nums">
                        {product.price.toLocaleString()} {t.currency}
                      </div>

                      <div className="pt-2 flex items-center gap-2">
                        <button
                          onClick={() => {
                            setSelectedProduct(product);
                            setIsWishlistOpen(false);
                          }}
                          className="flex items-center gap-1.5 px-3 py-1 bg-[#222222] hover:bg-[#D4C3A3] text-neutral-200 hover:text-black text-[11px] font-bold uppercase transition-colors"
                        >
                          <ShoppingBag className="w-3 h-3" />
                          <span>{t.viewDetails}</span>
                        </button>
                        <button
                          onClick={() => toggleWishlist(product.id)}
                          className="p-1 text-neutral-500 hover:text-red-400 transition-colors"
                          title="Remove"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
