import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  Product,
  Order,
  Coupon,
  Governorate,
  ProductSize,
  OrderStatus,
  Category
} from '../../types';
import {
  X,
  Package,
  ShoppingBag,
  Layers,
  Truck,
  Tag,
  Palette,
  Database,
  Plus,
  Trash2,
  Edit2,
  Printer,
  Download,
  Upload,
  Check,
  AlertTriangle,
  ArrowUpDown,
  Lock,
  LogOut,
  Image as ImageIcon
} from 'lucide-react';
import JSZip from 'jszip';
import { optimizeImageFile } from '../../utils/imageOptimizer';

export const AdminDashboard: React.FC = () => {
  const {
    language,
    t,
    isAdminOpen,
    setIsAdminOpen,
    isAdminAuthenticated,
    adminEditingProduct,
    setAdminEditingProduct,
    adminActiveTab,
    setAdminActiveTab,
    adminLogout,
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    updateInventoryStock,
    orders,
    updateOrderStatus,
    governorates,
    updateGovernorateRate,
    coupons,
    addCoupon,
    toggleCoupon,
    deleteCoupon,
    settings,
    updateSettings,
    changeAdminPassword,
    getFullBackupData,
    restoreBackupData,
    setActiveOrderForReceipt
  } = useStore();

  const activeTab = adminActiveTab;
  const setActiveTab = setAdminActiveTab;

  // Modal / Form states
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isCreatingProduct, setIsCreatingProduct] = useState(false);
  const [deleteCandidateId, setDeleteCandidateId] = useState<string | null>(null);

  // New product initial state
  const [prodForm, setProdForm] = useState<Partial<Product>>({
    sku: 'KYP-',
    nameEn: '',
    nameAr: '',
    category: 'hoodies',
    price: 1500,
    compareAtPrice: 1800,
    images: ['/src/assets/images/hoodie_anubis_black_1794002159476.jpg'],
    colors: [{ nameEn: 'Obsidian Black', nameAr: 'أسود بركاني', hex: '#0D0D0D' }],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    inventory: { S: 10, M: 10, L: 10, XL: 10, XXL: 5 },
    descriptionEn: '',
    descriptionAr: '',
    fabricEn: '100% Egyptian Combed Cotton (480 GSM)',
    fabricAr: '١٠٠٪ قطن مصري ممشط (٤٨٠ جم)',
    detailsEn: ['Double lined hood', 'Pre-shrunk wash'],
    detailsAr: ['قلنسوة مزدوجة', 'معالج ضد الانكماش']
  });

  const [newImageUrl, setNewImageUrl] = useState('');

  // Orders status filter & search
  const [orderFilter, setOrderFilter] = useState<OrderStatus | 'all'>('all');
  const [orderSearch, setOrderSearch] = useState('');

  // New coupon form
  const [newCouponCode, setNewCouponCode] = useState('');
  const [newCouponType, setNewCouponType] = useState<'percentage' | 'fixed'>('percentage');
  const [newCouponValue, setNewCouponValue] = useState(10);
  const [newCouponMin, setNewCouponMin] = useState(1000);
  const [newCouponExpiry, setNewCouponExpiry] = useState('2027-12-31');

  // Store Settings state
  const [themeForm, setThemeForm] = useState({ ...settings });
  const [newAdminPass, setNewAdminPass] = useState('');
  const [settingsSavedNotice, setSettingsSavedNotice] = useState(false);

  React.useEffect(() => {
    if (adminEditingProduct) {
      setEditingProduct(adminEditingProduct);
      setProdForm({ ...adminEditingProduct });
      setIsCreatingProduct(true);
      setAdminEditingProduct(null);
    }
  }, [adminEditingProduct]);

  React.useEffect(() => {
    setThemeForm({ ...settings });
  }, [settings]);

  // Backup restore status
  const [backupNotice, setBackupNotice] = useState('');

  if (!isAdminOpen || !isAdminAuthenticated) return null;

  // --- Handlers ---
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodForm.nameEn || !prodForm.nameAr || !prodForm.sku) return;

    if (editingProduct) {
      updateProduct({
        ...editingProduct,
        ...(prodForm as Product)
      });
      setEditingProduct(null);
    } else {
      addProduct({
        sku: prodForm.sku || 'KYP-00',
        slug: prodForm.nameEn.toLowerCase().replace(/\s+/g, '-'),
        nameEn: prodForm.nameEn,
        nameAr: prodForm.nameAr,
        category: (prodForm.category as Category) || 'hoodies',
        price: Number(prodForm.price) || 0,
        compareAtPrice: prodForm.compareAtPrice ? Number(prodForm.compareAtPrice) : undefined,
        images: prodForm.images && prodForm.images.length > 0 ? prodForm.images : ['/src/assets/images/hoodie_anubis_black_1794002159476.jpg'],
        colors: prodForm.colors || [{ nameEn: 'Black', nameAr: 'أسود', hex: '#000000' }],
        sizes: prodForm.sizes || ['S', 'M', 'L', 'XL', 'XXL'],
        inventory: prodForm.inventory || { S: 5, M: 5, L: 5, XL: 5, XXL: 5 },
        descriptionEn: prodForm.descriptionEn || '',
        descriptionAr: prodForm.descriptionAr || '',
        fabricEn: prodForm.fabricEn || '100% Egyptian Cotton',
        fabricAr: prodForm.fabricAr || '١٠٠٪ قطن مصري',
        detailsEn: prodForm.detailsEn || [],
        detailsAr: prodForm.detailsAr || [],
        isFeatured: false,
        isBestSeller: false,
        isNew: true
      });
      setIsCreatingProduct(false);
    }
  };

  const handleAddImage = () => {
    if (!newImageUrl.trim()) return;
    const currentImages = prodForm.images || [];
    setProdForm({ ...prodForm, images: [...currentImages, newImageUrl.trim()] });
    setNewImageUrl('');
  };

  const handleLocalImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const optimizedDataUrl = await optimizeImageFile(file, 1200, 1200, 0.85);
      const currentImages = prodForm.images || [];
      setProdForm({ ...prodForm, images: [...currentImages, optimizedDataUrl] });
    } catch {
      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        if (dataUrl) {
          const currentImages = prodForm.images || [];
          setProdForm({ ...prodForm, images: [...currentImages, dataUrl] });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleHeroImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const optimized = await optimizeImageFile(file, 1600, 1000, 0.88);
      setThemeForm((prev) => ({ ...prev, heroImage: optimized }));
    } catch {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const dataUrl = ev.target?.result as string;
        if (dataUrl) {
          setThemeForm((prev) => ({ ...prev, heroImage: dataUrl }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemoveImage = (indexToRemove: number) => {
    const currentImages = prodForm.images || [];
    setProdForm({
      ...prodForm,
      images: currentImages.filter((_, idx) => idx !== indexToRemove)
    });
  };

  const handleSetPrimaryImage = (index: number) => {
    const currentImages = [...(prodForm.images || [])];
    const item = currentImages.splice(index, 1)[0];
    setProdForm({
      ...prodForm,
      images: [item, ...currentImages]
    });
  };

  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCouponCode.trim()) return;
    addCoupon({
      code: newCouponCode.trim().toUpperCase(),
      type: newCouponType,
      value: Number(newCouponValue),
      minOrderValue: Number(newCouponMin),
      expiresAt: newCouponExpiry,
      isActive: true,
      usageCount: 0
    });
    setNewCouponCode('');
  };

  const handleSaveThemeSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(themeForm);
    if (newAdminPass.trim()) {
      changeAdminPassword(newAdminPass.trim());
      setNewAdminPass('');
    }
    setSettingsSavedNotice(true);
    setTimeout(() => setSettingsSavedNotice(false), 3000);
  };

  // CSV Exports
  const handleExportOrdersCSV = () => {
    const headers = ['Order ID', 'Customer Name', 'Phone', 'Governorate', 'City', 'Address', 'Payment Method', 'Payment Ref', 'Subtotal', 'Discount', 'Shipping', 'Total', 'Status', 'Date'];
    const rows = orders.map((o) => [
      o.id,
      `"${o.customerName}"`,
      `"${o.customerPhone}"`,
      `"${o.governorateNameEn}"`,
      `"${o.city}"`,
      `"${o.address.replace(/"/g, '""')}"`,
      o.paymentMethod,
      `"${o.paymentRef || ''}"`,
      o.subtotal,
      o.discount,
      o.shippingFee,
      o.total,
      o.status,
      o.createdAt
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `kayper_orders_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportProductsCSV = () => {
    const headers = ['ID', 'SKU', 'Name EN', 'Name AR', 'Category', 'Price EGP', 'Compare Price', 'Total Stock'];
    const rows = products.map((p) => {
      const totalStock = Object.values(p.inventory).reduce((a, b) => a + b, 0);
      return [
        p.id,
        p.sku,
        `"${p.nameEn}"`,
        `"${p.nameAr}"`,
        p.category,
        p.price,
        p.compareAtPrice || '',
        totalStock
      ];
    });
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `kayper_products_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // JSON Database Backup
  const handleDownloadJsonBackup = () => {
    const data = getFullBackupData();
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `kayper_database_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // 1-Click ZIP Export of Source Code & Database
  const handleDownloadSourceZip = async () => {
    try {
      const zip = new JSZip();
      
      // Add database dump
      const dbBackup = getFullBackupData();
      zip.file('kayper_database.json', JSON.stringify(dbBackup, null, 2));

      // Add deployment routing configurations
      zip.file(
        'vercel.json',
        JSON.stringify(
          {
            rewrites: [{ source: '/(.*)', destination: '/index.html' }]
          },
          null,
          2
        )
      );

      zip.file('_redirects', '/*    /index.html   200\n');

      zip.file(
        'README.md',
        `# KAYPER - Luxury Egyptian Streetwear Platform
## Production Deployment Guide

### Requirements
- Node.js >= 18
- Vite & React 19

### Run locally:
\`\`\`bash
npm install
npm run dev
\`\`\`

### Build for Production:
\`\`\`bash
npm run build
\`\`\`

### Egyptian Features Included:
- Bilingual interface (Arabic native RTL + English LTR)
- All 27 Egyptian Governorates with custom rates
- Cash on Delivery, InstaPay (IPA) and Vodafone Cash
- Thermal 80mm & A4 Egyptian sales receipts
- Real-time inventory matrix with low-stock alerts
`
      );

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = `kayper_streetwear_source_${new Date().toISOString().slice(0, 10)}.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      alert('Error building ZIP file');
    }
  };

  const handleRestoreJsonFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const ok = restoreBackupData(content);
        if (ok) {
          setBackupNotice(language === 'ar' ? 'تم استرجاع قاعدة البيانات بنجاح!' : 'Database restored successfully!');
        } else {
          setBackupNotice(language === 'ar' ? 'ملف النسخة الاحتياطية غير صالح' : 'Invalid backup JSON file');
        }
        setTimeout(() => setBackupNotice(''), 4000);
      }
    };
    reader.readAsText(file);
  };

  // KPIs
  const totalOrdersCount = orders.length;
  const totalRevenue = orders.reduce((sum, o) => (o.status !== 'cancelled' ? sum + o.total : sum), 0);
  const pendingOrdersCount = orders.filter((o) => o.status === 'pending').length;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 animate-fadeIn">
      <div className="relative w-full max-w-6xl bg-[#111111] border border-[#2B2B2B] shadow-2xl text-[#EAE1D1] my-4 flex flex-col h-[92vh] overflow-hidden">
        
        {/* Top Header */}
        <div className="p-4 sm:p-5 border-b border-[#212121] bg-[#141414] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#1A1A1A] border border-[#D4C3A3]/40 text-[#D4C3A3]">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-['Syne',sans-serif] text-lg font-bold uppercase text-white tracking-wider">
                  {t.adminTitle}
                </h3>
                <span className="bg-emerald-950 border border-emerald-800 text-emerald-300 text-[10px] font-mono px-2 py-0.5">
                  AUTHENTICATED
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                {language === 'ar' ? 'إدارة المنتجات، الطلبيات، المخزون، محافظات مصر، والتصدير' : 'Products, Orders, Inventory, Governorates, and Database Portability'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={handleDownloadJsonBackup}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-bold uppercase transition-colors shadow-sm"
              title={language === 'ar' ? 'حفظ وتنزيل الموقع كاملاً بالصور والواجهة (JSON)' : 'Save & Download Full Store with Images'}
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">
                {language === 'ar' ? 'حفظ نسخة بالصور' : 'Save Full Site'}
              </span>
            </button>

            <button
              onClick={adminLogout}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1F1F1F] hover:bg-red-950 text-neutral-300 hover:text-red-300 border border-[#2E2E2E] text-xs font-bold uppercase transition-colors"
              title="Logout"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{t.adminLogout}</span>
            </button>
            <button
              onClick={() => setIsAdminOpen(false)}
              className="p-2 text-neutral-400 hover:text-white bg-[#1A1A1A] hover:bg-[#252525] transition-colors"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 p-2 bg-[#141414] border-b border-[#212121] overflow-x-auto no-scrollbar">
          {[
            { id: 'orders', label: t.tabOrders, icon: ShoppingBag, count: pendingOrdersCount > 0 ? pendingOrdersCount : undefined },
            { id: 'products', label: t.tabProducts, icon: Package },
            { id: 'inventory', label: t.tabInventory, icon: Layers },
            { id: 'shipping', label: t.tabShipping, icon: Truck },
            { id: 'coupons', label: t.tabCoupons, icon: Tag },
            { id: 'theme', label: t.tabTheme, icon: Palette },
            { id: 'backup', label: t.tabBackup, icon: Database }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-3.5 py-2 text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-[#D4C3A3] text-black shadow-md'
                    : 'text-neutral-400 hover:text-white bg-[#181818]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.count !== undefined && (
                  <span className="bg-red-600 text-white text-[10px] px-1.5 py-0.2 rounded-full font-mono">
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Main Tab Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-[#0E0E0E]">
          
          {/* TAB 1: ORDERS */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              {/* KPIs Header */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 bg-[#141414] border border-[#242424]">
                  <span className="text-[11px] text-neutral-400 uppercase font-mono">{t.ordersTotalCount}</span>
                  <div className="text-2xl font-black font-mono text-white mt-1 tabular-nums">{totalOrdersCount}</div>
                </div>
                <div className="p-4 bg-[#141414] border border-[#242424]">
                  <span className="text-[11px] text-neutral-400 uppercase font-mono">{t.revenueTotal}</span>
                  <div className="text-2xl font-black font-mono text-[#D4C3A3] mt-1 tabular-nums">
                    {totalRevenue.toLocaleString()} {t.currency}
                  </div>
                </div>
                <div className="p-4 bg-[#141414] border border-[#242424]">
                  <span className="text-[11px] text-neutral-400 uppercase font-mono">{language === 'ar' ? 'طلبات قيد المراجعة:' : 'Pending Orders:'}</span>
                  <div className="text-2xl font-black font-mono text-amber-400 mt-1 tabular-nums">{pendingOrdersCount}</div>
                </div>
              </div>

              {/* Filter & Actions Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-2 flex-wrap">
                  {(['all', 'pending', 'processing', 'shipped', 'delivered', 'cancelled'] as const).map((st) => (
                    <button
                      key={st}
                      onClick={() => setOrderFilter(st)}
                      className={`px-3 py-1 text-xs font-bold uppercase transition-colors ${
                        orderFilter === st
                          ? 'bg-white text-black'
                          : 'bg-[#181818] text-neutral-400 hover:text-white border border-[#262626]'
                      }`}
                    >
                      {st}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={orderSearch}
                    onChange={(e) => setOrderSearch(e.target.value)}
                    placeholder={language === 'ar' ? 'بحث بالاسم أو الهاتف أو كود الطلب...' : 'Search by name, phone or ID...'}
                    className="bg-[#161616] border border-[#2B2B2B] px-3 py-1.5 text-xs text-white focus:outline-none w-56 font-mono"
                  />
                  <button
                    onClick={handleExportOrdersCSV}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1F1F1F] hover:bg-[#D4C3A3] text-neutral-200 hover:text-black border border-[#2E2E2E] text-xs font-bold uppercase transition-colors"
                    title={t.exportOrdersExcel}
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>CSV</span>
                  </button>
                </div>
              </div>

              {/* Orders Table */}
              <div className="border border-[#242424] overflow-x-auto bg-[#141414]">
                <table className="w-full text-left rtl:text-right text-xs">
                  <thead>
                    <tr className="border-b border-[#242424] text-neutral-400 uppercase tracking-wider bg-[#181818]">
                      <th className="py-3 px-4 font-mono">Order ID</th>
                      <th className="py-3 px-4">Customer</th>
                      <th className="py-3 px-4">Governorate</th>
                      <th className="py-3 px-4">Items</th>
                      <th className="py-3 px-4">Total</th>
                      <th className="py-3 px-4">Payment</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-center">Receipt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1F1F1F]">
                    {orders
                      .filter((o) => {
                        const matchStatus = orderFilter === 'all' || o.status === orderFilter;
                        const matchQ =
                          !orderSearch ||
                          o.id.toLowerCase().includes(orderSearch.toLowerCase()) ||
                          o.customerName.toLowerCase().includes(orderSearch.toLowerCase()) ||
                          o.customerPhone.includes(orderSearch);
                        return matchStatus && matchQ;
                      })
                      .map((ord) => (
                        <tr key={ord.id} className="hover:bg-[#181818] transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-[#D4C3A3]">
                            {ord.id}
                          </td>
                          <td className="py-3 px-4">
                            <div className="font-bold text-white">{ord.customerName}</div>
                            <div className="text-[11px] font-mono text-neutral-400">{ord.customerPhone}</div>
                          </td>
                          <td className="py-3 px-4 text-neutral-300">
                            <div>{ord.governorateNameAr || ord.governorateNameEn}</div>
                            <div className="text-[10px] text-neutral-500 truncate max-w-[150px]">{ord.city}</div>
                          </td>
                          <td className="py-3 px-4 font-mono">
                            {ord.items.length} items
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-white tabular-nums">
                            {ord.total.toLocaleString()} {t.currency}
                          </td>
                          <td className="py-3 px-4 text-neutral-400 uppercase text-[11px]">
                            {ord.paymentMethod}
                            {ord.paymentRef && <div className="text-[10px] font-mono text-neutral-500 truncate max-w-[100px]">{ord.paymentRef}</div>}
                          </td>
                          <td className="py-3 px-4">
                            <select
                              value={ord.status}
                              onChange={(e) => updateOrderStatus(ord.id, e.target.value as OrderStatus)}
                              className="bg-[#1C1C1C] border border-[#2E2E2E] text-xs text-white px-2 py-1 focus:outline-none"
                            >
                              <option value="pending">Pending</option>
                              <option value="processing">Processing</option>
                              <option value="shipped">Shipped</option>
                              <option value="delivered">Delivered</option>
                              <option value="cancelled">Cancelled</option>
                            </select>
                          </td>
                          <td className="py-3 px-4 text-center">
                            <button
                              onClick={() => setActiveOrderForReceipt(ord)}
                              className="p-1.5 bg-[#202020] hover:bg-[#D4C3A3] text-neutral-300 hover:text-black transition-colors"
                              title="Print A4 / Thermal Receipt"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: PRODUCTS MANAGER */}
          {activeTab === 'products' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                    {t.tabProducts} ({products.length})
                  </h4>
                  <p className="text-xs text-neutral-400">
                    {language === 'ar' ? 'إدارة القطع، الأسعار، الصور المتعددة والمقاسات' : 'Manage streetwear pieces, prices, images, and sizes'}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExportProductsCSV}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-[#1F1F1F] hover:bg-neutral-800 text-neutral-300 text-xs font-bold uppercase border border-[#2E2E2E]"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>CSV</span>
                  </button>
                  <button
                    onClick={() => {
                      setEditingProduct(null);
                      setProdForm({
                        sku: `KYP-0${products.length + 1}`,
                        nameEn: '',
                        nameAr: '',
                        category: 'hoodies',
                        price: 1650,
                        compareAtPrice: 1950,
                        images: ['/src/assets/images/hoodie_anubis_black_1794002159476.jpg'],
                        colors: [{ nameEn: 'Obsidian Black', nameAr: 'أسود بركاني', hex: '#0D0D0D' }],
                        sizes: ['S', 'M', 'L', 'XL', 'XXL'],
                        inventory: { S: 10, M: 10, L: 10, XL: 10, XXL: 5 },
                        descriptionEn: '',
                        descriptionAr: '',
                        fabricEn: '100% Egyptian Combed Cotton (480 GSM)',
                        fabricAr: '١٠٠٪ قطن مصري ممشط (٤٨٠ جم)',
                        detailsEn: ['Artisanal drop-shoulder cut', 'Enzyme washed'],
                        detailsAr: ['قصة أكتاف منسدلة', 'غسيل إنزيمي مقاوم للانكماش']
                      });
                      setIsCreatingProduct(true);
                    }}
                    className="flex items-center gap-1.5 px-4 py-2 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-bold uppercase transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{t.addProduct}</span>
                  </button>
                </div>
              </div>

              {/* Products Grid / Table */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {products.map((prod) => (
                  <div
                    key={prod.id}
                    className="p-4 bg-[#141414] border border-[#242424] flex gap-4 items-start"
                  >
                    <div className="w-20 h-24 bg-[#1C1C1C] overflow-hidden shrink-0 border border-[#2B2B2B]">
                      <img
                        src={prod.images[0]}
                        alt={prod.nameEn}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center justify-between text-[11px] text-[#D4C3A3] font-mono">
                        <span className="uppercase">{prod.category}</span>
                        <span>{prod.sku}</span>
                      </div>
                      <h5 className="font-bold text-white text-xs truncate">
                        {language === 'ar' ? prod.nameAr : prod.nameEn}
                      </h5>
                      <div className="font-mono text-xs text-neutral-300 font-bold tabular-nums">
                        {prod.price.toLocaleString()} {t.currency}
                      </div>

                      <div className="pt-2 flex items-center gap-2">
                        <button
                          onClick={() => {
                            setEditingProduct(prod);
                            setProdForm({ ...prod });
                            setIsCreatingProduct(true);
                          }}
                          className="flex items-center gap-1 px-2.5 py-1 bg-[#202020] hover:bg-[#2A2A2A] text-neutral-300 text-xs font-semibold"
                        >
                          <Edit2 className="w-3 h-3" />
                          <span>{t.editProduct}</span>
                        </button>
                        <button
                          onClick={() => setDeleteCandidateId(prod.id)}
                          className="p-1 text-neutral-500 hover:text-red-400"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: INVENTORY MATRIX */}
          {activeTab === 'inventory' && (
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                  {t.tabInventory}
                </h4>
                <p className="text-xs text-neutral-400">
                  {language === 'ar'
                    ? 'تعديل مباشر وفوري لكميات المقاسات في المخزن مع تنبيهات عند اقتراب النفاد (< 10 قطع)'
                    : 'Real-time stock control across S/M/L/XL/XXL with automated low-stock warnings (< 10 units)'}
                </p>
              </div>

              <div className="border border-[#242424] overflow-x-auto bg-[#141414]">
                <table className="w-full text-left rtl:text-right text-xs">
                  <thead>
                    <tr className="border-b border-[#242424] text-neutral-400 uppercase tracking-wider bg-[#181818]">
                      <th className="py-3 px-4 font-mono">SKU</th>
                      <th className="py-3 px-4">Product Name</th>
                      <th className="py-3 px-4 text-center">S</th>
                      <th className="py-3 px-4 text-center">M</th>
                      <th className="py-3 px-4 text-center">L</th>
                      <th className="py-3 px-4 text-center">XL</th>
                      <th className="py-3 px-4 text-center">XXL</th>
                      <th className="py-3 px-4 text-center">Total Stock</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1F1F1F]">
                    {products.map((p) => {
                      const totalStock = Object.values(p.inventory).reduce((a, b) => a + b, 0);
                      const isLow = totalStock < 15;

                      return (
                        <tr key={p.id} className="hover:bg-[#181818] transition-colors">
                          <td className="py-3 px-4 font-mono font-bold text-[#D4C3A3]">{p.sku}</td>
                          <td className="py-3 px-4">
                            <span className="font-bold text-white">{language === 'ar' ? p.nameAr : p.nameEn}</span>
                            {isLow && (
                              <span className="ml-2 rtl:mr-2 text-[10px] text-amber-400 font-bold bg-amber-950/60 px-1.5 py-0.5">
                                LOW
                              </span>
                            )}
                          </td>
                          {(['S', 'M', 'L', 'XL', 'XXL'] as ProductSize[]).map((sz) => {
                            const count = p.inventory[sz] ?? 0;
                            return (
                              <td key={sz} className="py-2 px-2 text-center">
                                <div className="inline-flex items-center border border-[#2B2B2B] bg-[#161616]">
                                  <button
                                    onClick={() => updateInventoryStock(p.id, sz, count - 1)}
                                    className="px-2 py-0.5 text-neutral-400 hover:text-white"
                                  >
                                    -
                                  </button>
                                  <span className={`px-2 py-0.5 font-mono font-bold tabular-nums ${count <= 3 ? 'text-red-400' : 'text-neutral-200'}`}>
                                    {count}
                                  </span>
                                  <button
                                    onClick={() => updateInventoryStock(p.id, sz, count + 1)}
                                    className="px-2 py-0.5 text-neutral-400 hover:text-white"
                                  >
                                    +
                                  </button>
                                </div>
                              </td>
                            );
                          })}
                          <td className="py-3 px-4 text-center font-mono font-extrabold text-[#EAE1D1] tabular-nums">
                            {totalStock}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: SHIPPING RATES CONFIGURATOR */}
          {activeTab === 'shipping' && (
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                  {t.tabShipping} (27 Governorates)
                </h4>
                <p className="text-xs text-neutral-400">
                  {language === 'ar'
                    ? 'تخصيص تسعيرة التوصيل بالجنيه المصري ومدة الشحن التقديرية لكل محافظة من محافظات مصر الـ 27'
                    : 'Configure dynamic delivery tariffs in EGP and transit days for all 27 Egyptian governorates'}
                </p>
              </div>

              <div className="border border-[#242424] overflow-x-auto bg-[#141414]">
                <table className="w-full text-left rtl:text-right text-xs">
                  <thead>
                    <tr className="border-b border-[#242424] text-neutral-400 uppercase tracking-wider bg-[#181818]">
                      <th className="py-3 px-4">Governorate (En / Ar)</th>
                      <th className="py-3 px-4">Zone</th>
                      <th className="py-3 px-4">Shipping Fee (EGP)</th>
                      <th className="py-3 px-4">Transit Time (Days)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1F1F1F]">
                    {governorates.map((gov) => (
                      <tr key={gov.id} className="hover:bg-[#181818] transition-colors">
                        <td className="py-3 px-4 font-bold text-white">
                          <span>{gov.nameEn}</span>
                          <span className="text-neutral-500 mx-2">/</span>
                          <span className="text-[#D4C3A3]">{gov.nameAr}</span>
                        </td>
                        <td className="py-3 px-4 font-mono text-neutral-400 uppercase text-[11px]">
                          {gov.zone}
                        </td>
                        <td className="py-3 px-4">
                          <input
                            type="number"
                            value={gov.shippingFee}
                            onChange={(e) => updateGovernorateRate(gov.id, Number(e.target.value), gov.deliveryDays)}
                            className="w-24 bg-[#1C1C1C] border border-[#2E2E2E] focus:border-[#D4C3A3] px-2 py-1 text-xs text-white font-mono focus:outline-none"
                          />
                        </td>
                        <td className="py-3 px-4">
                          <input
                            type="text"
                            value={gov.deliveryDays}
                            onChange={(e) => updateGovernorateRate(gov.id, gov.shippingFee, e.target.value)}
                            className="w-24 bg-[#1C1C1C] border border-[#2E2E2E] focus:border-[#D4C3A3] px-2 py-1 text-xs text-white font-mono focus:outline-none"
                          />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 5: PROMO CODES */}
          {activeTab === 'coupons' && (
            <div className="space-y-6">
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                  {t.tabCoupons}
                </h4>
                <p className="text-xs text-neutral-400">
                  {language === 'ar'
                    ? 'إنشاء كوبونات خصم بنسبة مئوية أو قيمة ثابتة مع تحديد الحد الأدنى للطلب وتاريخ الانتهاء'
                    : 'Manage discount vouchers, percentages, fixed EGP discounts, and min cart thresholds'}
                </p>
              </div>

              {/* Create Coupon Form */}
              <form onSubmit={handleCreateCoupon} className="p-4 bg-[#141414] border border-[#242424] grid grid-cols-1 sm:grid-cols-5 gap-3 items-end">
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">Coupon Code</label>
                  <input
                    type="text"
                    required
                    value={newCouponCode}
                    onChange={(e) => setNewCouponCode(e.target.value)}
                    placeholder="e.g. VIP20"
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white uppercase font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">Type</label>
                  <select
                    value={newCouponType}
                    onChange={(e) => setNewCouponType(e.target.value as any)}
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white"
                  >
                    <option value="percentage">% Percentage</option>
                    <option value="fixed">Fixed EGP Amount</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">Value (% or EGP)</label>
                  <input
                    type="number"
                    required
                    value={newCouponValue}
                    onChange={(e) => setNewCouponValue(Number(e.target.value))}
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">Min Spend (EGP)</label>
                  <input
                    type="number"
                    value={newCouponMin}
                    onChange={(e) => setNewCouponMin(Number(e.target.value))}
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-bold uppercase transition-colors"
                >
                  Create Code
                </button>
              </form>

              {/* Coupons List */}
              <div className="border border-[#242424] bg-[#141414]">
                <table className="w-full text-left rtl:text-right text-xs">
                  <thead>
                    <tr className="border-b border-[#242424] text-neutral-400 uppercase tracking-wider bg-[#181818]">
                      <th className="py-3 px-4 font-mono">Code</th>
                      <th className="py-3 px-4">Discount</th>
                      <th className="py-3 px-4">Min Spend</th>
                      <th className="py-3 px-4">Usage</th>
                      <th className="py-3 px-4">Status</th>
                      <th className="py-3 px-4 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1F1F1F]">
                    {coupons.map((c) => (
                      <tr key={c.code} className="hover:bg-[#181818] transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-[#D4C3A3]">{c.code}</td>
                        <td className="py-3 px-4 font-bold text-white font-mono">
                          {c.type === 'percentage' ? `${c.value}%` : `${c.value} ${t.currency}`}
                        </td>
                        <td className="py-3 px-4 font-mono text-neutral-300">
                          {c.minOrderValue.toLocaleString()} {t.currency}
                        </td>
                        <td className="py-3 px-4 font-mono text-neutral-400">{c.usageCount} times</td>
                        <td className="py-3 px-4">
                          <button
                            onClick={() => toggleCoupon(c.code)}
                            className={`px-2 py-0.5 text-[11px] font-bold ${
                              c.isActive
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                : 'bg-neutral-800 text-neutral-400 border border-neutral-700'
                            }`}
                          >
                            {c.isActive ? 'Active' : 'Disabled'}
                          </button>
                        </td>
                        <td className="py-3 px-4 text-center">
                          <button
                            onClick={() => deleteCoupon(c.code)}
                            className="p-1 text-neutral-500 hover:text-red-400"
                            title="Delete coupon"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 6: THEME & STOREFRONT CUSTOMIZER */}
          {activeTab === 'theme' && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                  {t.tabTheme}
                </h4>
                <p className="text-xs text-neutral-400">
                  {language === 'ar'
                    ? 'تخصيص نصوص المتجر، بيانات إنستاباي، فودافون كاش، وتغيير كلمة مرور المشرف'
                    : 'Customize storefront branding, announcements, InstaPay handle, and security key'}
                </p>
              </div>

              {settingsSavedNotice && (
                <div className="p-3 bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-xs flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  <span>{language === 'ar' ? 'تم حفظ التعديلات بنجاح!' : 'Store settings updated successfully!'}</span>
                </div>
              )}

              <form onSubmit={handleSaveThemeSettings} className="space-y-4 p-5 bg-[#141414] border border-[#242424]">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">Brand Name (EN)</label>
                    <input
                      type="text"
                      value={themeForm.brandNameEn}
                      onChange={(e) => setThemeForm({ ...themeForm, brandNameEn: e.target.value })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">اسم العلامة (عربي)</label>
                    <input
                      type="text"
                      value={themeForm.brandNameAr}
                      onChange={(e) => setThemeForm({ ...themeForm, brandNameAr: e.target.value })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">شريط الإعلانات العربي (Marquee Banner)</label>
                    <input
                      type="text"
                      value={themeForm.announcementAr}
                      onChange={(e) => setThemeForm({ ...themeForm, announcementAr: e.target.value })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">Announcement Banner (EN)</label>
                    <input
                      type="text"
                      value={themeForm.announcementEn}
                      onChange={(e) => setThemeForm({ ...themeForm, announcementEn: e.target.value })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">عنوان الهيرو الرئيسي (AR)</label>
                    <input
                      type="text"
                      value={themeForm.heroTitleAr}
                      onChange={(e) => setThemeForm({ ...themeForm, heroTitleAr: e.target.value })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">Hero Headline (EN)</label>
                    <input
                      type="text"
                      value={themeForm.heroTitleEn}
                      onChange={(e) => setThemeForm({ ...themeForm, heroTitleEn: e.target.value })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">وصف الهيرو التوضيحي (AR Subtitle)</label>
                    <textarea
                      rows={2}
                      value={themeForm.heroSubtitleAr}
                      onChange={(e) => setThemeForm({ ...themeForm, heroSubtitleAr: e.target.value })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white resize-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">Hero Subtitle (EN)</label>
                    <textarea
                      rows={2}
                      value={themeForm.heroSubtitleEn}
                      onChange={(e) => setThemeForm({ ...themeForm, heroSubtitleEn: e.target.value })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white resize-none"
                    />
                  </div>

                  {/* Hero Banner Image Upload & URL */}
                  <div className="sm:col-span-2 p-3 bg-[#181818] border border-[#282828] space-y-3">
                    <label className="block text-xs font-bold text-white uppercase">
                      {language === 'ar' ? 'صورة غلاف الهيرو الرئيسية (Hero Cover Image)' : 'Hero Banner Cover Image'}
                    </label>
                    <div className="flex flex-col sm:flex-row items-center gap-4">
                      <div className="w-40 h-24 bg-black border border-[#333] overflow-hidden shrink-0">
                        <img
                          src={themeForm.heroImage}
                          alt="Hero Cover Preview"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 w-full space-y-2">
                        <input
                          type="text"
                          value={themeForm.heroImage}
                          onChange={(e) => setThemeForm({ ...themeForm, heroImage: e.target.value })}
                          placeholder="Paste image URL..."
                          className="w-full bg-[#121212] border border-[#2C2C2C] px-3 py-2 text-xs text-white font-mono"
                        />
                        <label className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-bold uppercase cursor-pointer">
                          <span>{language === 'ar' ? 'رفع صورة جديدة من جهازك' : 'Upload Image from Computer'}</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleHeroImageUpload}
                            className="hidden"
                          />
                        </label>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">حساب إنستاباي (InstaPay IPA)</label>
                    <input
                      type="text"
                      value={themeForm.instapayAccount}
                      onChange={(e) => setThemeForm({ ...themeForm, instapayAccount: e.target.value })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">محفظة فودافون كاش (Vodafone Cash)</label>
                    <input
                      type="text"
                      value={themeForm.vodafoneCashWallet}
                      onChange={(e) => setThemeForm({ ...themeForm, vodafoneCashWallet: e.target.value })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">حد الشحن المجاني (جنيه مصري)</label>
                    <input
                      type="number"
                      value={themeForm.freeShippingThreshold}
                      onChange={(e) => setThemeForm({ ...themeForm, freeShippingThreshold: Number(e.target.value) })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">رقم خدمة العملاء</label>
                    <input
                      type="text"
                      value={themeForm.supportPhone}
                      onChange={(e) => setThemeForm({ ...themeForm, supportPhone: e.target.value })}
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>

                  <div className="sm:col-span-2 pt-2 border-t border-[#262626]">
                    <label className="block text-xs text-neutral-300 mb-1 font-medium">
                      {language === 'ar' ? 'تغيير كلمة مرور المشرف (اترك فارغاً إن لم ترغب بالتغيير)' : 'Change Admin Password (leave blank to keep current)'}
                    </label>
                    <input
                      type="password"
                      value={newAdminPass}
                      onChange={(e) => setNewAdminPass(e.target.value)}
                      placeholder="Enter new administrator password..."
                      className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="py-3 px-6 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  {t.saveChanges}
                </button>
              </form>
            </div>
          )}

          {/* TAB 7: BACKUP, PORTABILITY & DEPLOYMENT */}
          {activeTab === 'backup' && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                  {t.tabBackup} & Source Export
                </h4>
                <p className="text-xs text-neutral-400">
                  {language === 'ar'
                    ? 'تصدير البيانات بصيغة JSON و Excel، تحميل الكود المصدري كاملاً بصيغة ZIP، وجاهزية النشر على Vercel و Netlify'
                    : 'Export complete JSON databases, download full source ZIP archive, and deployment configs'}
                </p>
              </div>

              {backupNotice && (
                <div className="p-3 bg-emerald-950/70 border border-emerald-800 text-emerald-300 text-xs">
                  {backupNotice}
                </div>
              )}

              {/* Action Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* 1-Click ZIP Source Export */}
                <div className="p-5 bg-[#141414] border border-[#2B2B2B] space-y-3">
                  <div className="flex items-center gap-2 text-[#D4C3A3]">
                    <Download className="w-5 h-5" />
                    <h5 className="font-bold text-white text-xs uppercase">Complete Source ZIP</h5>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {language === 'ar'
                      ? 'تنزيل أرشيف مضغوط يحتوي على ملفات المشروع وبيانات المتجر وملفات التوجيه الجاهزة للنشر الفوري.'
                      : 'Download a clean ZIP bundle with project files, seed database, and single-page routing configs.'}
                  </p>
                  <button
                    onClick={handleDownloadSourceZip}
                    className="w-full py-2.5 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-bold uppercase transition-colors"
                  >
                    {t.downloadSourceZip}
                  </button>
                </div>

                {/* JSON Database Backup */}
                <div className="p-5 bg-[#141414] border border-[#2B2B2B] space-y-3">
                  <div className="flex items-center gap-2 text-[#D4C3A3]">
                    <Database className="w-5 h-5" />
                    <h5 className="font-bold text-white text-xs uppercase">JSON Database Snapshot</h5>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {language === 'ar'
                      ? 'تحميل نسخة احتياطية لكافة المنتجات والطلبيات والكوبونات والمحافظات والإعدادات.'
                      : 'Snapshot export of all products, customer orders, coupons, and governorate tariffs.'}
                  </p>
                  <button
                    onClick={handleDownloadJsonBackup}
                    className="w-full py-2.5 bg-[#222222] hover:bg-[#2A2A2A] text-white border border-[#333333] text-xs font-bold uppercase transition-colors"
                  >
                    {t.downloadJsonBackup}
                  </button>
                </div>

                {/* 1-Click Restore JSON */}
                <div className="p-5 bg-[#141414] border border-[#2B2B2B] space-y-3 sm:col-span-2">
                  <div className="flex items-center gap-2 text-white">
                    <Upload className="w-5 h-5 text-[#D4C3A3]" />
                    <h5 className="font-bold text-white text-xs uppercase">1-Click Database Restore</h5>
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed">
                    {language === 'ar'
                      ? 'رفع ملف نسخة احتياطية (.json) لاستعادة كافة المنتجات والطلبات فوراً.'
                      : 'Upload a previously exported JSON backup file to overwrite or restore all store records.'}
                  </p>
                  <label className="inline-block py-2.5 px-4 bg-[#1F1F1F] hover:bg-[#2E2E2E] text-neutral-200 border border-[#333333] text-xs font-bold uppercase cursor-pointer">
                    <span>{t.restoreJsonBackup}</span>
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleRestoreJsonFile}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Vercel & Netlify Deployment info */}
              <div className="p-5 bg-[#141414] border border-[#222222] space-y-3 text-xs">
                <h5 className="font-bold text-white uppercase text-xs">
                  {language === 'ar' ? 'ملفات النشر الجاهزة (Deployment Ready)' : 'Deployment Ready Files'}
                </h5>
                <p className="text-neutral-400 leading-relaxed">
                  {language === 'ar'
                    ? 'المشروع مزود تلقائياً بملف vercel.json وملف _redirects لضمان عمل التوجيه الداخلي (Single Page Routing) بسلاسة عند نشره على منصات الاستضافة العالمية.'
                    : 'Pre-configured with vercel.json and public/_redirects for instant single-page route rewrites.'}
                </p>
                <div className="p-3 bg-black/60 font-mono text-[11px] text-[#D4C3A3]">
                  vercel.json: rewrites to /index.html | public/_redirects: 200 rewrite rule
                </div>
              </div>
            </div>
          )}

        </div>

      </div>

      {/* Product Add / Edit Modal */}
      {isCreatingProduct && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/85 backdrop-blur-md flex items-center justify-center p-3 animate-fadeIn">
          <div className="relative w-full max-w-3xl bg-[#141414] border border-[#2B2B2B] shadow-2xl p-6 text-[#EAE1D1] max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-4 border-b border-[#242424] mb-4">
              <h4 className="font-bold text-sm uppercase text-white">
                {editingProduct ? t.editProduct : t.addProduct}
              </h4>
              <button
                onClick={() => setIsCreatingProduct(false)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">SKU *</label>
                  <input
                    type="text"
                    required
                    value={prodForm.sku}
                    onChange={(e) => setProdForm({ ...prodForm, sku: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">Category *</label>
                  <select
                    value={prodForm.category}
                    onChange={(e) => setProdForm({ ...prodForm, category: e.target.value as Category })}
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white"
                  >
                    <option value="hoodies">Hoodies (هوديز)</option>
                    <option value="tshirts">T-Shirts (تيشيرتات)</option>
                    <option value="cargos">Cargo Pants (بناطيل كارجو)</option>
                    <option value="jackets">Jackets (جاكيتات)</option>
                    <option value="accessories">Accessories (إكسسوارات)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">Name (English) *</label>
                  <input
                    type="text"
                    required
                    value={prodForm.nameEn}
                    onChange={(e) => setProdForm({ ...prodForm, nameEn: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">الاسم بالعربية *</label>
                  <input
                    type="text"
                    required
                    value={prodForm.nameAr}
                    onChange={(e) => setProdForm({ ...prodForm, nameAr: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">Price (EGP) *</label>
                  <input
                    type="number"
                    required
                    value={prodForm.price}
                    onChange={(e) => setProdForm({ ...prodForm, price: Number(e.target.value) })}
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-neutral-400 mb-1">Compare-At Price (Discount EGP)</label>
                  <input
                    type="number"
                    value={prodForm.compareAtPrice || ''}
                    onChange={(e) => setProdForm({ ...prodForm, compareAtPrice: e.target.value ? Number(e.target.value) : undefined })}
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white font-mono"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] text-neutral-400 mb-1">Description (English)</label>
                  <textarea
                    rows={2}
                    value={prodForm.descriptionEn}
                    onChange={(e) => setProdForm({ ...prodForm, descriptionEn: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white resize-none"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-[11px] text-neutral-400 mb-1">الوصف بالعربية</label>
                  <textarea
                    rows={2}
                    value={prodForm.descriptionAr}
                    onChange={(e) => setProdForm({ ...prodForm, descriptionAr: e.target.value })}
                    className="w-full bg-[#181818] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white resize-none"
                  />
                </div>

                {/* Multi-Image Manager */}
                <div className="sm:col-span-2 p-3 bg-[#181818] border border-[#282828] space-y-3">
                  <label className="block text-xs font-bold text-white uppercase">
                    {language === 'ar' ? 'إدارة صور المنتج المتعددة' : 'Product Image Gallery Manager'}
                  </label>
                  
                  {/* Current Images List */}
                  <div className="flex gap-3 overflow-x-auto pb-2">
                    {prodForm.images?.map((img, idx) => (
                      <div key={idx} className="relative w-24 h-28 bg-black border border-[#333333] shrink-0 group">
                        <img src={img} alt="preview" className="w-full h-full object-cover" />
                        
                        {idx === 0 && (
                          <span className="absolute top-1 left-1 bg-[#D4C3A3] text-black text-[9px] font-bold px-1 uppercase">
                            Cover
                          </span>
                        )}

                        <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-1 p-1">
                          {idx !== 0 && (
                            <button
                              type="button"
                              onClick={() => handleSetPrimaryImage(idx)}
                              className="text-[9px] bg-[#D4C3A3] text-black px-1.5 py-0.5 font-bold"
                            >
                              Make Cover
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => handleRemoveImage(idx)}
                            className="text-[9px] bg-red-600 text-white px-1.5 py-0.5 font-bold"
                          >
                            Remove
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Add Image by URL or Upload local file */}
                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      type="text"
                      value={newImageUrl}
                      onChange={(e) => setNewImageUrl(e.target.value)}
                      placeholder="Paste image URL (e.g. /src/assets/images/...)"
                      className="flex-1 bg-[#121212] border border-[#2C2C2C] px-3 py-1.5 text-xs text-white font-mono"
                    />
                    <button
                      type="button"
                      onClick={handleAddImage}
                      className="px-3 py-1.5 bg-[#252525] hover:bg-neutral-700 text-white text-xs font-bold uppercase"
                    >
                      {t.addImageUrl}
                    </button>
                    <label className="px-3 py-1.5 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-bold uppercase cursor-pointer flex items-center justify-center">
                      <span>{t.uploadLocalImage}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleLocalImageUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>

                {/* Stock Matrix per size */}
                <div className="sm:col-span-2 p-3 bg-[#181818] border border-[#282828] space-y-2">
                  <label className="block text-xs font-bold text-white uppercase">
                    {language === 'ar' ? 'مخزون المقاسات (S, M, L, XL, XXL)' : 'Inventory Matrix per Size'}
                  </label>
                  <div className="grid grid-cols-5 gap-2">
                    {(['S', 'M', 'L', 'XL', 'XXL'] as ProductSize[]).map((sz) => (
                      <div key={sz}>
                        <label className="block text-[10px] text-neutral-400 font-mono mb-1">{sz}</label>
                        <input
                          type="number"
                          value={prodForm.inventory?.[sz] ?? 0}
                          onChange={(e) => {
                            const currentInv = { ...(prodForm.inventory || { S: 0, M: 0, L: 0, XL: 0, XXL: 0 }) };
                            currentInv[sz] = Math.max(0, Number(e.target.value));
                            setProdForm({ ...prodForm, inventory: currentInv });
                          }}
                          className="w-full bg-[#121212] border border-[#2C2C2C] px-2 py-1 text-xs text-white font-mono"
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-[#242424]">
                <button
                  type="button"
                  onClick={() => setIsCreatingProduct(false)}
                  className="px-4 py-2 bg-neutral-800 text-neutral-300 text-xs font-bold uppercase"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#D4C3A3] text-black text-xs font-bold uppercase hover:bg-[#EAE1D1]"
                >
                  {t.saveChanges}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Safety Confirmation Dialog for Product Deletion */}
      {deleteCandidateId && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="max-w-md w-full bg-[#161616] border border-[#333333] p-6 text-center space-y-4">
            <div className="w-12 h-12 bg-red-950 text-red-400 border border-red-800 mx-auto flex items-center justify-center rounded-full">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h4 className="text-sm font-bold text-white uppercase">
              {language === 'ar' ? 'تأكيد حذف المنتج نهائياً' : 'Confirm Permanent Deletion'}
            </h4>
            <p className="text-xs text-neutral-400 leading-relaxed">
              {t.confirmDelete}
            </p>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setDeleteCandidateId(null)}
                className="px-4 py-2 bg-[#252525] text-neutral-300 text-xs font-bold uppercase"
              >
                {t.cancel}
              </button>
              <button
                onClick={() => {
                  deleteProduct(deleteCandidateId);
                  setDeleteCandidateId(null);
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold uppercase"
              >
                {t.deleteProduct}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
