import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { Lock, X, KeyRound, AlertCircle } from 'lucide-react';

export const AdminLoginModal: React.FC = () => {
  const {
    language,
    t,
    isAdminOpen,
    setIsAdminOpen,
    isAdminAuthenticated,
    verifyAdminPassword
  } = useStore();

  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  if (!isAdminOpen || isAdminAuthenticated) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const ok = verifyAdminPassword(password);
    if (!ok) {
      setError(true);
    } else {
      setError(false);
      setPassword('');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/90 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="relative w-full max-w-md bg-[#111111] border border-[#2B2B2B] shadow-2xl p-6 sm:p-8 text-[#EAE1D1]">
        
        <button
          onClick={() => setIsAdminOpen(false)}
          className="absolute top-4 right-4 rtl:right-auto rtl:left-4 p-1.5 text-neutral-400 hover:text-white bg-[#1A1A1A] hover:bg-[#252525] transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-3 mb-6">
          <div className="w-12 h-12 bg-[#1A1A1A] border border-[#D4C3A3]/40 text-[#D4C3A3] mx-auto flex items-center justify-center">
            <Lock className="w-6 h-6" />
          </div>
          <h3 className="font-['Syne',sans-serif] text-xl font-bold uppercase text-white tracking-wider">
            {t.adminSecurePortal}
          </h3>
          <p className="text-xs text-neutral-400">
            {t.adminLoginPrompt}
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-950/60 border border-red-800 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{t.adminWrongPassword}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-neutral-500 absolute left-3 rtl:left-auto rtl:right-3 top-3" />
              <input
                type="password"
                required
                autoFocus
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setError(false);
                }}
                placeholder={t.adminPasswordPlaceholder}
                className="w-full bg-[#161616] border border-[#2E2E2E] focus:border-[#D4C3A3] px-9 py-2.5 text-xs text-white focus:outline-none font-mono"
              />
            </div>
            <div className="flex items-center justify-between mt-2">
              <span className="text-[11px] text-neutral-400 font-mono">
                {language === 'ar' ? 'كلمة المرور الافتراضية: kayper2026' : 'Default Key: kayper2026'}
              </span>
              <button
                type="button"
                onClick={() => {
                  setPassword('kayper2026');
                  setError(false);
                }}
                className="text-[11px] text-[#D4C3A3] underline hover:text-white font-mono cursor-pointer"
              >
                {language === 'ar' ? 'تعبئة تلقائية (kayper2026)' : 'Autofill (kayper2026)'}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3 px-4 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
          >
            {t.adminLoginBtn}
          </button>
        </form>

      </div>
    </div>
  );
};
