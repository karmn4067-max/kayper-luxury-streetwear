import React from 'react';
import { useStore } from '../../context/StoreContext';
import { Home, Compass, Search, Heart, ShoppingBag } from 'lucide-react';

interface MobileBottomNavProps {
  onOpenMobileSearch: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ onOpenMobileSearch }) => {
  const {
    language,
    t,
    cartCount,
    wishlist,
    setIsCartOpen,
    setIsWishlistOpen,
    setActiveCategory
  } = useStore();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToCatalog = () => {
    const el = document.getElementById('catalog-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#0E0E0E]/95 backdrop-blur-lg border-t border-[#222222] px-2 py-1.5 safe-area-bottom select-none shadow-[0_-4px_20px_rgba(0,0,0,0.6)]"
      aria-label="Mobile Navigation"
    >
      <div className="grid grid-cols-5 items-center h-14">
        {/* Tab 1: Home */}
        <button
          onClick={scrollToTop}
          className="flex flex-col items-center justify-center min-h-[44px] text-neutral-400 hover:text-[#D4C3A3] active:scale-95 transition-all focus:outline-none"
        >
          <Home className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-bold tracking-tight">
            {language === 'ar' ? 'الرئيسية' : 'Home'}
          </span>
        </button>

        {/* Tab 2: Shop / Catalog */}
        <button
          onClick={scrollToCatalog}
          className="flex flex-col items-center justify-center min-h-[44px] text-neutral-400 hover:text-[#D4C3A3] active:scale-95 transition-all focus:outline-none"
        >
          <Compass className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-bold tracking-tight">
            {language === 'ar' ? 'المتجر' : 'Shop'}
          </span>
        </button>

        {/* Tab 3: Search */}
        <button
          onClick={onOpenMobileSearch}
          className="flex flex-col items-center justify-center min-h-[44px] text-neutral-400 hover:text-[#D4C3A3] active:scale-95 transition-all focus:outline-none"
        >
          <Search className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-bold tracking-tight">
            {language === 'ar' ? 'بحث' : 'Search'}
          </span>
        </button>

        {/* Tab 4: Wishlist with badge */}
        <button
          onClick={() => setIsWishlistOpen(true)}
          className="flex flex-col items-center justify-center min-h-[44px] text-neutral-400 hover:text-[#D4C3A3] active:scale-95 transition-all relative focus:outline-none"
        >
          <div className="relative">
            <Heart className="w-5 h-5 mb-1" />
            {wishlist.length > 0 && (
              <span className="absolute -top-1 -right-2 bg-[#D4C3A3] text-black text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center tabular-nums">
                {wishlist.length}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold tracking-tight">
            {language === 'ar' ? 'المفضلة' : 'Wishlist'}
          </span>
        </button>

        {/* Tab 5: Cart / Bag with badge */}
        <button
          onClick={() => setIsCartOpen(true)}
          className="flex flex-col items-center justify-center min-h-[44px] text-[#D4C3A3] active:scale-95 transition-all relative focus:outline-none"
        >
          <div className="relative">
            <ShoppingBag className="w-5 h-5 mb-1" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-white text-black text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center tabular-nums">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-black tracking-tight text-white">
            {language === 'ar' ? 'الحقيبة' : 'Bag'}
          </span>
        </button>
      </div>
    </nav>
  );
};
