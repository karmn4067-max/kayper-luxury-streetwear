import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { ShoppingBag, Heart, Search, Globe, X, MapPin, Menu, Smartphone, Monitor, Lock } from 'lucide-react';
import { MobileMenuDrawer } from './MobileMenuDrawer';

interface HeaderProps {
  deviceMode: 'responsive' | 'mobile-preview';
  onToggleDeviceMode: () => void;
  onOpenMobileSearch?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  deviceMode,
  onToggleDeviceMode
}) => {
  const {
    language,
    t,
    setLanguage,
    cartCount,
    cartSubtotal,
    wishlist,
    setIsCartOpen,
    setIsWishlistOpen,
    setIsTrackingOpen,
    activeCategory,
    setActiveCategory,
    searchQuery,
    setSearchQuery,
    settings,
    isAdminAuthenticated,
    setIsAdminOpen
  } = useStore();

  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'all', label: t.allProducts },
    { id: 'hoodies', label: t.hoodies },
    { id: 'tshirts', label: t.tshirts },
    { id: 'cargos', label: t.cargos },
    { id: 'jackets', label: t.jackets },
    { id: 'accessories', label: t.accessories }
  ];

  return (
    <>
      <header className="sticky top-0 z-30 bg-[#0A0A0A]/95 backdrop-blur-md border-b border-[#1E1E1E]">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-20 gap-4 sm:gap-8">
            
            {/* Left: Mobile Hamburger Menu & Brand Wordmark */}
            <div className="flex items-center gap-2 sm:gap-4 shrink-0">
              {/* Mobile Hamburger Drawer Trigger */}
              <button
                onClick={() => setIsMobileMenuOpen(true)}
                className="md:hidden min-w-[44px] min-h-[44px] flex items-center justify-center text-neutral-300 hover:text-white -ml-2 rtl:-ml-0 rtl:-mr-2 focus:outline-none"
                aria-label="Open mobile navigation menu"
              >
                <Menu className="w-5 h-5 text-[#D4C3A3]" />
              </button>

              {/* Brand Logo Wordmark */}
              <button
                onClick={() => {
                  setActiveCategory('all');
                  setSearchQuery('');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="text-left rtl:text-right group cursor-pointer focus:outline-none flex items-baseline gap-2 py-1"
                aria-label="KAYPER Home"
              >
                <span className="font-['Syne',sans-serif] text-xl sm:text-3xl font-extrabold tracking-widest text-[#EAE1D1] group-hover:text-[#D4C3A3] transition-colors">
                  {settings.brandNameEn}
                </span>
                <span className="font-['Cairo',sans-serif] text-[11px] sm:text-xs font-bold text-[#D4C3A3] opacity-80">
                  {settings.brandNameAr}
                </span>
              </button>
            </div>

            {/* Center: Desktop Navigation Links (4-5 single-line clean text links) */}
            <nav className="hidden md:flex items-center gap-6 lg:gap-8">
              {navLinks.map((link) => {
                const isActive = activeCategory === link.id;
                return (
                  <button
                    key={link.id}
                    onClick={() => {
                      setActiveCategory(link.id as any);
                      const catalogEl = document.getElementById('catalog-section');
                      if (catalogEl) {
                        catalogEl.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    className={`text-xs lg:text-sm tracking-wider uppercase whitespace-nowrap transition-colors relative py-1 cursor-pointer font-medium ${
                      isActive
                        ? 'text-[#D4C3A3]'
                        : 'text-neutral-400 hover:text-[#EAE1D1]'
                    }`}
                  >
                    {link.label}
                    {isActive && (
                      <span className="absolute bottom-0 inset-x-0 h-[2px] bg-[#D4C3A3]" />
                    )}
                  </button>
                );
              })}
            </nav>

            {/* Right: Actions, Device Mode Switcher, Wishlist & Cart */}
            <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
              
              {/* Desktop / Mobile View Mode Switcher */}
              <button
                onClick={onToggleDeviceMode}
                className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 border border-[#2B2B2B] hover:border-[#D4C3A3] bg-[#141414] text-[11px] font-mono text-neutral-300 hover:text-[#D4C3A3] transition-all"
                title={
                  deviceMode === 'responsive'
                    ? (language === 'ar' ? 'عرض تجربة الموبايل (iPhone Preview)' : 'Switch to Mobile Preview')
                    : (language === 'ar' ? 'عرض تجربة الكمبيوتر (Desktop View)' : 'Switch to Desktop View')
                }
              >
                {deviceMode === 'responsive' ? (
                  <>
                    <Smartphone className="w-3.5 h-3.5 text-[#D4C3A3]" />
                    <span>{language === 'ar' ? 'عرض الموبايل' : 'Mobile View'}</span>
                  </>
                ) : (
                  <>
                    <Monitor className="w-3.5 h-3.5 text-[#D4C3A3]" />
                    <span>{language === 'ar' ? 'عرض الكمبيوتر' : 'Desktop View'}</span>
                  </>
                )}
              </button>

              {/* Live Search Toggle/Input */}
              {isSearchExpanded ? (
                <div className="relative flex items-center bg-[#141414] border border-[#2B2B2B] px-3 py-1.5 w-40 sm:w-60 transition-all">
                  <Search className="w-4 h-4 text-neutral-400 shrink-0" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={language === 'ar' ? 'بحث سريع...' : 'Search...'}
                    autoFocus
                    className="w-full bg-transparent border-none text-xs text-[#EAE1D1] focus:outline-none px-2 placeholder:text-neutral-500"
                  />
                  <button
                    onClick={() => {
                      setIsSearchExpanded(false);
                      setSearchQuery('');
                    }}
                    className="text-neutral-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setIsSearchExpanded(true)}
                  className="min-w-[40px] min-h-[40px] flex items-center justify-center text-neutral-300 hover:text-[#D4C3A3] transition-colors focus:outline-none"
                  aria-label="Search"
                  title={language === 'ar' ? 'بحث' : 'Search'}
                >
                  <Search className="w-4 sm:w-5 h-4 sm:h-5" />
                </button>
              )}

              {/* Track Order Icon Button (hidden on extra small screens since it is in mobile menu and bottom nav) */}
              <button
                onClick={() => setIsTrackingOpen(true)}
                className="hidden sm:flex min-w-[40px] min-h-[40px] items-center justify-center text-neutral-300 hover:text-[#D4C3A3] transition-colors focus:outline-none"
                title={t.trackOrder}
                aria-label={t.trackOrder}
              >
                <MapPin className="w-4 sm:w-5 h-4 sm:h-5" />
              </button>

              {/* Language Switcher */}
              <button
                onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
                className="flex items-center gap-1 px-2 sm:px-2.5 py-1.5 border border-[#262626] hover:border-[#D4C3A3] text-xs font-bold text-neutral-300 hover:text-[#D4C3A3] transition-all bg-[#141414] min-h-[36px]"
                title={language === 'ar' ? 'Switch to English' : 'التحويل للغة العربية'}
              >
                <Globe className="w-3.5 h-3.5" />
                <span>{t.switchLang}</span>
              </button>

              {/* Wishlist Button (desktop/tablet) */}
              <button
                onClick={() => setIsWishlistOpen(true)}
                className="hidden sm:flex min-w-[40px] min-h-[40px] items-center justify-center text-neutral-300 hover:text-[#D4C3A3] transition-colors relative focus:outline-none"
                aria-label={t.wishlist}
                title={t.wishlist}
              >
                <Heart className="w-5 h-5" />
                {wishlist.length > 0 && (
                  <span className="absolute 1 right-1 bg-[#D4C3A3] text-black text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center tabular-nums">
                    {wishlist.length}
                  </span>
                )}
              </button>

              {/* Prominent Admin Portal Button */}
              <button
                onClick={() => setIsAdminOpen(true)}
                className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-bold uppercase transition-all min-h-[36px] ${
                  isAdminAuthenticated
                    ? 'bg-[#D4C3A3] text-black border border-[#D4C3A3] shadow-md shadow-[#D4C3A3]/20'
                    : 'bg-[#181818] hover:bg-[#252525] text-neutral-300 hover:text-white border border-[#333333]'
                }`}
                title={
                  isAdminAuthenticated
                    ? (language === 'ar' ? 'لوحة تحكم الأدمن (مفعلة)' : 'Admin Dashboard (Active)')
                    : (language === 'ar' ? 'تسجيل دخول الأدمن (كلمة السر الافتراضية: kayper2026)' : 'Admin Portal (Default Key: kayper2026)')
                }
              >
                <Lock className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">
                  {isAdminAuthenticated ? (language === 'ar' ? 'لوحة الأدمن' : 'Admin Panel') : (language === 'ar' ? 'دخول الأدمن' : 'Admin')}
                </span>
                <span className="sm:hidden font-mono text-[10px]">
                  {isAdminAuthenticated ? '⚡' : (language === 'ar' ? 'أدمن' : 'Admin')}
                </span>
              </button>

              {/* Shopping Bag Trigger Button */}
              <button
                onClick={() => setIsCartOpen(true)}
                className="flex items-center gap-1.5 sm:gap-2 bg-[#D4C3A3] hover:bg-[#EAE1D1] text-black px-2.5 sm:px-3.5 py-2 text-xs font-bold tracking-wider uppercase transition-colors shrink-0 min-h-[38px]"
                aria-label={t.cart}
              >
                <ShoppingBag className="w-4 h-4" />
                <span className="tabular-nums font-bold">
                  {cartCount}
                </span>
                <span className="hidden sm:inline-block border-l border-black/20 pl-2 rtl:border-r rtl:border-l-0 rtl:pr-2 rtl:pl-0 font-extrabold tabular-nums">
                  {cartSubtotal} {t.currency}
                </span>
              </button>
            </div>
          </div>

          {/* Mobile Categories Horizontal Strip */}
          <div className="md:hidden flex items-center gap-2 overflow-x-auto py-2.5 border-t border-[#1a1a1a] no-scrollbar">
            {navLinks.map((link) => {
              const isActive = activeCategory === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => {
                    setActiveCategory(link.id as any);
                    const catalogEl = document.getElementById('catalog-section');
                    if (catalogEl) {
                      catalogEl.scrollIntoView({ behavior: 'smooth' });
                    }
                  }}
                  className={`text-[11px] whitespace-nowrap px-3 py-1.5 uppercase tracking-wide font-bold transition-colors shrink-0 ${
                    isActive
                      ? 'text-black bg-[#D4C3A3]'
                      : 'text-neutral-400 hover:text-white bg-[#141414] border border-[#222222]'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Mobile Menu Slide-Over Drawer */}
      <MobileMenuDrawer
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
      />
    </>
  );
};
