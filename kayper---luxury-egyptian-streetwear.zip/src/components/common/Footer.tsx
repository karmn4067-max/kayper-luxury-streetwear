import React from 'react';
import { useStore } from '../../context/StoreContext';
import { ShieldCheck, Truck, RefreshCw, Lock, Phone, CreditCard } from 'lucide-react';

export const Footer: React.FC = () => {
  const { language, t, settings, setIsAdminOpen } = useStore();

  return (
    <footer className="bg-[#0D0D0D] border-t border-[#1F1F1F] text-neutral-400 text-sm mt-20">
      {/* Trust Pillars */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 border-b border-[#1A1A1A]">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-[#171717] text-[#D4C3A3] shrink-0">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-white font-bold text-sm mb-1 uppercase tracking-wider">
                {language === 'ar' ? 'شحن لجميع المحافظات' : 'All 27 Governorates'}
              </h4>
              <p className="text-xs text-neutral-400 leading-relaxed">
                {language === 'ar'
                  ? 'توصيل سريع بأسعار موحدة للوجه البحري والقبلي والقناة وسيناء والبحر الأحمر.'
                  : 'Fast doorstep express delivery covering Greater Cairo, Delta, Canal, Upper Egypt & Sinai.'}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="p-3 bg-[#171717] text-[#D4C3A3] shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-white font-bold text-sm mb-1 uppercase tracking-wider">
                {language === 'ar' ? 'قطن مصري فاخر ٤٨٠ جم' : 'Heavyweight 480 GSM'}
              </h4>
              <p className="text-xs text-neutral-400 leading-relaxed">
                {language === 'ar'
                  ? 'نسيج قطني مصري طبيعي ١٠٠٪ معالج ضد الانكماش والبهتان بأعلى معايير الحياكة.'
                  : '100% authentic long-staple Egyptian cotton crafted with artisan French Terry drape.'}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="p-3 bg-[#171717] text-[#D4C3A3] shrink-0">
              <CreditCard className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-white font-bold text-sm mb-1 uppercase tracking-wider">
                {language === 'ar' ? 'طرق دفع مصرية مرنة' : 'Localized Payments'}
              </h4>
              <p className="text-xs text-neutral-400 leading-relaxed">
                {language === 'ar'
                  ? 'الدفع نقداً عند الاستلام، أو تحويل فوري عبر إنستاباي ومحافظ فودافون كاش.'
                  : 'Pay upon delivery in cash, or instantly via InstaPay IPA and Vodafone Cash wallets.'}
              </p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="p-3 bg-[#171717] text-[#D4C3A3] shrink-0">
              <RefreshCw className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-white font-bold text-sm mb-1 uppercase tracking-wider">
                {language === 'ar' ? 'استبدال واسترجاع ١٤ يوماً' : '14-Day Exchanges'}
              </h4>
              <p className="text-xs text-neutral-400 leading-relaxed">
                {language === 'ar'
                  ? 'حق استبدال المقاس أو استرجاع المنتج وفقاً لقانون حماية المستهلك المصري.'
                  : 'Hassle-free size exchanges and returns guaranteed by Egyptian consumer laws.'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-baseline gap-2">
              <span className="font-['Syne',sans-serif] text-3xl font-extrabold text-[#EAE1D1] tracking-widest">
                {settings.brandNameEn}
              </span>
              <span className="font-['Cairo',sans-serif] text-sm font-bold text-[#D4C3A3]">
                {settings.brandNameAr}
              </span>
            </div>
            <p className="text-xs text-neutral-400 max-w-md leading-relaxed">
              {language === 'ar'
                ? 'علامة أزياء الشارع المصرية الراقية المستلهمة من شوارع القاهرة الليلية وتاريخها المعماري العريق. ندمج بين أثقل الأقطان المصرية وقصات البوكسي العالمية بأيدي حرفيين مصريين.'
                : 'A vanguard Egyptian streetwear label born from the nocturnal architectural concrete of Cairo. We fuse monumental Egyptian cotton weight with modern international street cuts.'}
            </p>
            <div className="flex items-center gap-3 pt-2 text-xs text-neutral-300">
              <Phone className="w-4 h-4 text-[#D4C3A3]" />
              <span className="font-mono tabular-nums">{settings.supportPhone}</span>
              <span className="text-neutral-600">|</span>
              <span className="font-mono text-neutral-400">{settings.instapayAccount}</span>
            </div>
          </div>

          {/* Governorates Coverage */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
              {language === 'ar' ? 'تغطية الشحن السريع' : 'Courier Network'}
            </h4>
            <ul className="space-y-1.5 text-xs text-neutral-400">
              <li>{language === 'ar' ? 'القاهرة والجيزة (١-٢ يوم)' : 'Cairo & Giza (1-2 Days)'}</li>
              <li>{language === 'ar' ? 'الإسكندرية والساحل الشمالي' : 'Alexandria & North Coast'}</li>
              <li>{language === 'ar' ? 'محافظات الدلتا والقناة' : 'Delta & Suez Canal'}</li>
              <li>{language === 'ar' ? 'الصعيد والبحر الأحمر وجنوب سيناء' : 'Upper Egypt, Red Sea & Sinai'}</li>
            </ul>
          </div>

          {/* Egyptian Payment Badges */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">
              {language === 'ar' ? 'بوابات الدفع المعتمدة' : 'Official Gateways'}
            </h4>
            <div className="flex flex-col gap-2">
              <div className="px-3 py-2 bg-[#171717] border border-[#262626] text-xs text-neutral-300 flex items-center justify-between">
                <span>{language === 'ar' ? 'الدفع عند الاستلام' : 'Cash on Delivery'}</span>
                <span className="text-[10px] text-[#D4C3A3] font-bold">COD</span>
              </div>
              <div className="px-3 py-2 bg-[#171717] border border-[#262626] text-xs text-neutral-300 flex items-center justify-between">
                <span>{language === 'ar' ? 'شبكة إنستاباي اللحظية' : 'InstaPay Network'}</span>
                <span className="text-[10px] text-[#D4C3A3] font-bold">IPA</span>
              </div>
              <div className="px-3 py-2 bg-[#171717] border border-[#262626] text-xs text-neutral-300 flex items-center justify-between">
                <span>{language === 'ar' ? 'فودافون كاش' : 'Vodafone Cash'}</span>
                <span className="text-[10px] text-[#D4C3A3] font-bold">010</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar with Discreet Admin Access */}
      <div className="border-t border-[#171717] bg-[#080808] py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <div>
            <p>{t.footerRights}</p>
            <p className="text-[11px] text-neutral-600 mt-0.5">{t.egyptMade}</p>
          </div>

          <div className="flex items-center gap-6">
            <span className="text-neutral-600">
              {language === 'ar' ? 'سجل تجاري: ٩٤٨٢٧١' : 'CR: 948271'}
            </span>
            
            {/* Discreet Admin Login Trigger */}
            <button
              onClick={() => setIsAdminOpen(true)}
              className="flex items-center gap-1.5 text-neutral-500 hover:text-[#D4C3A3] transition-colors p-1"
              title="Admin Portal"
            >
              <Lock className="w-3 h-3" />
              <span className="text-[11px] tracking-wider uppercase">{t.adminLogin}</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
