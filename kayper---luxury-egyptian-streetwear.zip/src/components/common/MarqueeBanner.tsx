import React from 'react';
import { useStore } from '../../context/StoreContext';
import { Truck, ShieldCheck, RefreshCw, Zap } from 'lucide-react';

export const MarqueeBanner: React.FC = () => {
  const { language, settings } = useStore();

  const text = language === 'ar' ? settings.announcementAr : settings.announcementEn;

  return (
    <div className="bg-[#141414] border-b border-[#262626] text-[#D4C3A3] text-xs font-semibold py-2.5 overflow-hidden select-none">
      <div className="flex items-center whitespace-nowrap animate-marquee gap-8">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="flex items-center gap-6 shrink-0">
            <span className="flex items-center gap-2">
              <Truck className="w-3.5 h-3.5 text-[#D4C3A3]" />
              {text}
            </span>
            <span className="text-[#333333]">✦</span>
            <span className="flex items-center gap-2">
              <Zap className="w-3.5 h-3.5 text-[#D4C3A3]" />
              {language === 'ar' ? 'إنستاباي وفودافون كاش متاحان' : 'INSTAPAY & VODAFONE CASH ACCEPTED'}
            </span>
            <span className="text-[#333333]">✦</span>
            <span className="flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-[#D4C3A3]" />
              {language === 'ar' ? 'قطن مصري أصيل ١٠٠٪' : 'AUTHENTIC 100% EGYPTIAN COTTON'}
            </span>
            <span className="text-[#333333]">✦</span>
            <span className="flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5 text-[#D4C3A3]" />
              {language === 'ar' ? 'استبدال مجاني خلال 14 يوماً' : '14-DAY HASSLE-FREE RETURNS'}
            </span>
            <span className="text-[#333333]">✦</span>
          </div>
        ))}
      </div>
    </div>
  );
};
