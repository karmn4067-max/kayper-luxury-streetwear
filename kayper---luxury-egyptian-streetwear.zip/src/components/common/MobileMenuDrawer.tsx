import React from 'react';
import { useStore } from '../../context/StoreContext';
import { X, Globe, MapPin, Ruler, Lock, Phone, MessageSquare, ChevronRight, ShieldCheck } from 'lucide-react';
import { Category } from '../../types';

interface MobileMenuDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileMenuDrawer: React.FC<MobileMenuDrawerProps> = ({ isOpen, onClose }) => {
  const {
    language,
    t,
    setLanguage,
    activeCategory,
    setActiveCategory,
    setIsTrackingOpen,
    setIsSizeGuideOpen,
    setIsAdminOpen,
    settings
  } = useStore();

  if (!isOpen) return null;

  const categories: { id: Category | 'all'; label: string; count?: string }[] = [
    { id: 'all', label: t.allProducts },
    { id: 'hoodies', label: t.hoodies },
    { id: 'tshirts', label: t.tshirts },
    { id: 'cargos', label: t.cargos },
    { id: 'jackets', label: t.jackets },
    { id: 'accessories', label: t.accessories }
  ];

  const handleSelectCategory = (cat: Category | 'all') => {
    setActiveCategory(cat);
    onClose();
    const el = document.getElementById('catalog-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/85 backdrop-blur-md animate-fadeIn md:hidden">
      <div className="absolute inset-0" onClick={onClose} />

      <div className="fixed inset-y-0 left-0 rtl:left-auto rtl:right-0 max-w-[300px] w-full bg-[#111111] border-r rtl:border-r-0 rtl:border-l border-[#262626] text-[#EAE1D1] flex flex-col shadow-2xl">
        
        {/* Drawer Header */}
        <div className="p-4 border-b border-[#212121] flex items-center justify-between bg-[#141414]">
          <div className="flex items-baseline gap-2">
            <span className="font-['Syne',sans-serif] text-xl font-extrabold text-white tracking-widest">
              KAYPER
            </span>
            <span className="font-['Cairo',sans-serif] text-xs font-bold text-[#D4C3A3]">
              كايبر
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white bg-[#1A1A1A] hover:bg-[#252525] transition-colors"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          
          {/* Categories List */}
          <div className="space-y-1">
            <span className="text-[10px] font-mono uppercase text-neutral-500 tracking-wider block px-2 mb-2">
              {language === 'ar' ? 'أقسام المتجر' : 'Collections'}
            </span>
            {categories.map((c) => {
              const isActive = activeCategory === c.id;
              return (
                <button
                  key={c.id}
                  onClick={() => handleSelectCategory(c.id)}
                  className={`w-full flex items-center justify-between px-3 py-3 text-xs font-bold uppercase transition-colors rounded-none ${
                    isActive
                      ? 'bg-[#D4C3A3] text-black font-black'
                      : 'text-neutral-300 hover:bg-[#181818] hover:text-white'
                  }`}
                >
                  <span>{c.label}</span>
                  <ChevronRight className="w-4 h-4 opacity-50 rtl:rotate-180" />
                </button>
              );
            })}
          </div>

          {/* Quick Utility Links */}
          <div className="space-y-1 pt-3 border-t border-[#212121]">
            <span className="text-[10px] font-mono uppercase text-neutral-500 tracking-wider block px-2 mb-2">
              {language === 'ar' ? 'خدمات العملاء' : 'Customer Care'}
            </span>

            {/* Size Guide */}
            <button
              onClick={() => {
                onClose();
                setIsSizeGuideOpen(true);
              }}
              className="w-full flex items-center gap-3 px-3 py-2.5 text-xs text-neutral-300 hover:text-[#D4C3A3] hover:bg-[#181818] transition-colors"
            >
              <Ruler className="w-4 h-4 text-[#D4C3A3]" />
              <span>{t.sizeGuide}</span>
            </button>

            {/* Track Order */}
            <button
              onClick={() => {
                onClose();
                setIsTrackingOpen(true);
              }}
              className="w-full flex items-center gap-3 px-3 py-2.5 text-xs text-neutral-300 hover:text-[#D4C3A3] hover:bg-[#181818] transition-colors"
            >
              <MapPin className="w-4 h-4 text-[#D4C3A3]" />
              <span>{t.trackOrder}</span>
            </button>

            {/* Language Switch */}
            <button
              onClick={() => {
                setLanguage(language === 'ar' ? 'en' : 'ar');
                onClose();
              }}
              className="w-full flex items-center justify-between px-3 py-2.5 text-xs text-neutral-300 hover:text-[#D4C3A3] hover:bg-[#181818] transition-colors"
            >
              <div className="flex items-center gap-3">
                <Globe className="w-4 h-4 text-[#D4C3A3]" />
                <span>{language === 'ar' ? 'English Language' : 'التحويل للغة العربية'}</span>
              </div>
              <span className="font-mono text-[10px] text-neutral-400 font-bold bg-[#1A1A1A] px-2 py-0.5">
                {language === 'ar' ? 'EN' : 'عربي'}
              </span>
            </button>

            {/* Support Call */}
            <a
              href={`tel:${settings.supportPhone}`}
              className="w-full flex items-center gap-3 px-3 py-2.5 text-xs text-neutral-300 hover:text-[#D4C3A3] hover:bg-[#181818] transition-colors"
            >
              <Phone className="w-4 h-4 text-[#D4C3A3]" />
              <span>{language === 'ar' ? 'اتصل بخدمة العملاء' : 'Direct Phone Support'}</span>
            </a>
          </div>

          {/* Egyptian Trust Banner in Mobile Menu */}
          <div className="p-3 bg-[#161616] border border-[#242424] space-y-1.5 text-[11px] text-neutral-400">
            <div className="flex items-center gap-2 text-white font-bold">
              <ShieldCheck className="w-4 h-4 text-[#D4C3A3]" />
              <span>{language === 'ar' ? 'ضمان كايبر الرسمي' : 'KAYPER Official Guarantee'}</span>
            </div>
            <p className="text-[10px] leading-relaxed">
              {language === 'ar'
                ? '١٠٠٪ قطن مصري ٤٨٠ جم • استبدال مجاني خلال ١٤ يوماً • توصيل لكافة محافظات مصر.'
                : '100% Egyptian 480 GSM Cotton • 14-day free replacement • All 27 governorates.'}
            </p>
          </div>

        </div>

        {/* Drawer Footer with Admin link */}
        <div className="p-4 border-t border-[#212121] bg-[#141414]">
          <button
            onClick={() => {
              onClose();
              setIsAdminOpen(true);
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-[#1C1C1C] hover:bg-[#D4C3A3] text-neutral-200 hover:text-black border border-[#2E2E2E] hover:border-[#D4C3A3] transition-all text-xs font-bold uppercase"
            title="Admin Login"
          >
            <Lock className="w-3.5 h-3.5 text-[#D4C3A3]" />
            <span>{language === 'ar' ? '🔐 تسجيل دخول الأدمن (kayper2026)' : '🔐 Admin Portal (kayper2026)'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
