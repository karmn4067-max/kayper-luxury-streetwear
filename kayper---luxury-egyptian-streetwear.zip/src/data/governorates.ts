import { Governorate } from '../types';

export const INITIAL_GOVERNORATES: Governorate[] = [
  // Cairo & Giza
  { id: 'cairo', nameEn: 'Cairo', nameAr: 'القاهرة', zone: 'cairo_giza', shippingFee: 50, deliveryDays: '1-2' },
  { id: 'giza', nameEn: 'Giza', nameAr: 'الجيزة', zone: 'cairo_giza', shippingFee: 55, deliveryDays: '1-2' },
  
  // Alexandria
  { id: 'alexandria', nameEn: 'Alexandria', nameAr: 'الإسكندرية', zone: 'alexandria', shippingFee: 65, deliveryDays: '2-3' },

  // Nile Delta
  { id: 'qalyubia', nameEn: 'Qalyubia', nameAr: 'القليوبية', zone: 'delta', shippingFee: 60, deliveryDays: '2-3' },
  { id: 'sharqia', nameEn: 'Sharqia', nameAr: 'الشرقية', zone: 'delta', shippingFee: 65, deliveryDays: '2-3' },
  { id: 'dakahlia', nameEn: 'Dakahlia', nameAr: 'الدقهلية', zone: 'delta', shippingFee: 65, deliveryDays: '2-3' },
  { id: 'monufia', nameEn: 'Monufia', nameAr: 'المنوفية', zone: 'delta', shippingFee: 65, deliveryDays: '2-3' },
  { id: 'gharbia', nameEn: 'Gharbia', nameAr: 'الغربية', zone: 'delta', shippingFee: 65, deliveryDays: '2-3' },
  { id: 'beheira', nameEn: 'Beheira', nameAr: 'البحيرة', zone: 'delta', shippingFee: 70, deliveryDays: '2-3' },
  { id: 'kafr_el_sheikh', nameEn: 'Kafr El Sheikh', nameAr: 'كفر الشيخ', zone: 'delta', shippingFee: 70, deliveryDays: '2-4' },
  { id: 'damietta', nameEn: 'Damietta', nameAr: 'دمياط', zone: 'delta', shippingFee: 70, deliveryDays: '2-4' },

  // Suez Canal
  { id: 'port_said', nameEn: 'Port Said', nameAr: 'بورسعيد', zone: 'canal', shippingFee: 70, deliveryDays: '2-3' },
  { id: 'ismailia', nameEn: 'Ismailia', nameAr: 'الإسماعيلية', zone: 'canal', shippingFee: 70, deliveryDays: '2-3' },
  { id: 'suez', nameEn: 'Suez', nameAr: 'السويس', zone: 'canal', shippingFee: 70, deliveryDays: '2-3' },

  // Upper Egypt (الصعيد)
  { id: 'faiyum', nameEn: 'Faiyum', nameAr: 'الفيوم', zone: 'upper_egypt', shippingFee: 75, deliveryDays: '3-4' },
  { id: 'beni_suef', nameEn: 'Beni Suef', nameAr: 'بني سويف', zone: 'upper_egypt', shippingFee: 80, deliveryDays: '3-4' },
  { id: 'minya', nameEn: 'Minya', nameAr: 'المنيا', zone: 'upper_egypt', shippingFee: 85, deliveryDays: '3-5' },
  { id: 'asyut', nameEn: 'Asyut', nameAr: 'أسيوط', zone: 'upper_egypt', shippingFee: 90, deliveryDays: '3-5' },
  { id: 'sohag', nameEn: 'Sohag', nameAr: 'سوهاج', zone: 'upper_egypt', shippingFee: 95, deliveryDays: '3-5' },
  { id: 'qena', nameEn: 'Qena', nameAr: 'قنا', zone: 'upper_egypt', shippingFee: 100, deliveryDays: '4-6' },
  { id: 'luxor', nameEn: 'Luxor', nameAr: 'الأقصر', zone: 'upper_egypt', shippingFee: 105, deliveryDays: '4-6' },
  { id: 'aswan', nameEn: 'Aswan', nameAr: 'أسوان', zone: 'upper_egypt', shippingFee: 110, deliveryDays: '4-6' },

  // Frontier & Red Sea & Sinai
  { id: 'red_sea', nameEn: 'Red Sea (Hurghada/Gouna)', nameAr: 'البحر الأحمر (الغردقة والجونة)', zone: 'red_sea_sinai', shippingFee: 110, deliveryDays: '3-5' },
  { id: 'south_sinai', nameEn: 'South Sinai (Sharm/Dahab)', nameAr: 'جنوب سيناء (شرم الشيخ ودهب)', zone: 'red_sea_sinai', shippingFee: 120, deliveryDays: '3-6' },
  { id: 'north_sinai', nameEn: 'North Sinai', nameAr: 'شمال سيناء', zone: 'red_sea_sinai', shippingFee: 120, deliveryDays: '4-7' },
  { id: 'matrouh', nameEn: 'Matrouh (North Coast)', nameAr: 'مطروح (الساحل الشمالي)', zone: 'red_sea_sinai', shippingFee: 100, deliveryDays: '3-5' },
  { id: 'new_valley', nameEn: 'New Valley', nameAr: 'الوادي الجديد', zone: 'upper_egypt', shippingFee: 125, deliveryDays: '4-7' }
];
