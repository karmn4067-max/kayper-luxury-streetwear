import { Product } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'kyp-001',
    sku: 'KYP-HD-01',
    slug: 'anubis-heavyweight-hoodie-obsidian',
    nameEn: 'Anubis Heavyweight Oversized Hoodie',
    nameAr: 'هودي أنوبيس أوفرسايز الثقيل',
    category: 'hoodies',
    price: 1850,
    compareAtPrice: 2200,
    images: [
      '/src/assets/images/hoodie_anubis_black_1794002159476.jpg',
      '/src/assets/images/hero_cairo_streetwear_1794002158802.jpg'
    ],
    colors: [
      { nameEn: 'Obsidian Black', nameAr: 'أسود بركاني', hex: '#0D0D0D' },
      { nameEn: 'Washed Charcoal', nameAr: 'رمادي فحمي مغسول', hex: '#262626' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    inventory: {
      S: 12,
      M: 8,
      L: 3, // Scarcity indicator!
      XL: 6,
      XXL: 2
    },
    descriptionEn: 'Engineered in Cairo from 480 GSM ultra-heavyweight Egyptian organic combed cotton. Features micro-embroidered champagne gold insignia, seamless drop-shoulder architecture, and a double-layered structured hood that holds its sculptural silhouette.',
    descriptionAr: 'مُصمم ومُحاك في القاهرة من القطن المصري العضوي الممشط فائق الثقل عيار 480 جم. يتميز بتطريز دقيق بلون الذهب الشامبين، وقصة أكتاف منسدلة هندسية، وقلنسوة مزدوجة الطبقات تحافظ على قوامها العصري الفاخر.',
    fabricEn: '100% Egyptian Combed Cotton (480 GSM French Terry)',
    fabricAr: '١٠٠٪ قطن مصري ممشط (٤٨٠ جم فرينش تيري فائق النعومة)',
    detailsEn: [
      'Sculptural double-wall lined hood with concealed eyelets',
      'Matte champagne-gold tipped drawstrings',
      'Deep kangaroo utility pocket with reinforced bar-tack stitching',
      'Pre-shrunk vintage wash to eliminate shrinkage',
      'Custom engraved KAYPER metal hem plaque'
    ],
    detailsAr: [
      'قلنسوة مزدوجة مبطنة بتصميم نحتي وأربطة معدنية مدفونة',
      'أربطة مطلية بنهايات ذهبية شامبين غير لامعة',
      'جيب كنغر عميق مع خياطة دعم مقواة عند الزوايا',
      'معالجة غسيل عتيق مقاوم للانكماش بنسبة ١٠٠٪',
      'شارة معدنية محفورة يدوياً بشعار كايبر الفاخر'
    ],
    isFeatured: true,
    isBestSeller: true,
    isNew: true,
    createdAt: '2026-10-15T12:00:00Z'
  },
  {
    id: 'kyp-002',
    sku: 'KYP-TS-01',
    slug: 'cairo-archive-heavy-tee-charcoal',
    nameEn: 'Cairo Archive Boxy T-Shirt',
    nameAr: 'تيشيرت أرشيف القاهرة بوكسي فيت',
    category: 'tshirts',
    price: 950,
    compareAtPrice: 1200,
    images: [
      '/src/assets/images/tshirt_cairo_heavyweight_1794002159953.jpg',
      '/src/assets/images/hero_cairo_streetwear_1794002158802.jpg'
    ],
    colors: [
      { nameEn: 'Washed Charcoal', nameAr: 'رمادي فحمي كلاسيكي', hex: '#232323' },
      { nameEn: 'Desert Dune', nameAr: 'بيج صحراوي', hex: '#C2B69D' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    inventory: {
      S: 15,
      M: 10,
      L: 4,
      XL: 9,
      XXL: 5
    },
    descriptionEn: 'The definitive luxury heavyweight tee. Cut in a boxy relaxed drape from 300 GSM Egyptian long-staple cotton, featuring cracked-patina bronze vintage screenprint celebrating underground architectural Cairo.',
    descriptionAr: 'التيشيرت الفاخر الأيقوني بقصة بوكسي واسعة من القطن المصري طويل التيلة عيار 300 جم. يحمل طباعة أرشيفية فنية بلمسات برونزية عتيقة تجسد روح معمار شوارع القاهرة.',
    fabricEn: '100% Giza Long-Staple Cotton (300 GSM Single Jersey)',
    fabricAr: '١٠٠٪ قطن جيزة طويل التيلة (٣٠٠ جم جيرسي سميك)',
    detailsEn: [
      'Sturdy 3.2cm ribbed mock-neck collar that never sags',
      'Boxy drop-shoulder cut inspired by 90s streetwear archives',
      'Distressed antique bronze graphic printing',
      'Silicone-enzyme washed for silk-like tactile drape'
    ],
    detailsAr: [
      'ياقة مضلعة عريضة مقواة بسماكة 3.2 سم لا تتمدد مع الغسيل',
      'قصة بوكسي بأكتاف عريضة مستوحاة من أرشيف أزياء التسعينات',
      'طباعة برونزية عتيقة مقاومة للتشقق والحرارة',
      'معالج بالإنزيمات الحريرية لمنح القماش انسيابية فخمة'
    ],
    isFeatured: true,
    isBestSeller: true,
    isNew: false,
    createdAt: '2026-10-20T10:00:00Z'
  },
  {
    id: 'kyp-003',
    sku: 'KYP-CG-01',
    slug: 'tactical-cargo-pants-desert-sand',
    nameEn: 'Nomad Tactical Cargo Trousers',
    nameAr: 'بنطال نوماد كارجو التكتيكي - رمال الصحراء',
    category: 'cargos',
    price: 1950,
    compareAtPrice: 2400,
    images: [
      '/src/assets/images/cargo_pants_desert_sand_1794002160256.jpg',
      '/src/assets/images/hero_cairo_streetwear_1794002158802.jpg'
    ],
    colors: [
      { nameEn: 'Desert Sand', nameAr: 'رمال الصحراء', hex: '#D2C1A1' },
      { nameEn: 'Stealth Black', nameAr: 'أسود داكن', hex: '#111111' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    inventory: {
      S: 8,
      M: 5,
      L: 2, // Scarcity!
      XL: 7,
      XXL: 3
    },
    descriptionEn: 'High-utility luxury cargo trousers engineered with waterproof ripstop cotton blend, 8 tactical modular gusseted pockets, integrated heavy-duty nylon webbing belt, and zip-cinch adjustable ankle cuffs.',
    descriptionAr: 'بنطال كارجو فاخر فائق العملية مصمم من مزيج قطني مقاوم للتمزق، مزود بـ 8 جيوب تكتيكية واسعة وحزام نايلون مدمج بمشبك مغناطيسي وسحابات سفلية لتضييق وتعديل مقاس الكاحل.',
    fabricEn: '65% Egyptian Cotton, 35% Military Ripstop Nylon (340 GSM)',
    fabricAr: '٦٥٪ قطن مصري فاخر، ٣٥٪ نايلون ريبستوب متين (٣٤٠ جم)',
    detailsEn: [
      'Integrated quick-release Fidlock-style webbing belt',
      'Water-repellent nanotech Teflon surface coating',
      '8 ergonomic pockets with waterproof matte YKK zip tracks',
      'Articulated knee darts for unrestricted urban movement',
      'Adjustable snap-cuff ankles for high-top sneaker stacking'
    ],
    detailsAr: [
      'حزام مدمج عالي المتانة بمشبك سريع الفتح والإغلاق',
      'معالجة نانوية مقاومة لقطرات الماء والأتربة',
      '٨ جيوب موزعة هندسياً مع سحابات YKK سوداء غير لامعة',
      'تصميم مريح للركبة لحرية الحركة والمرونة طوال اليوم',
      'أزرار كبس سفلية عند الكاحل للتنسيق المثالي مع الأحذية الرياضية'
    ],
    isFeatured: true,
    isBestSeller: true,
    isNew: true,
    createdAt: '2026-10-25T14:30:00Z'
  },
  {
    id: 'kyp-004',
    sku: 'KYP-JK-01',
    slug: 'obsidian-satin-bomber-jacket',
    nameEn: 'Obsidian Flight Satin Bomber',
    nameAr: 'جاكيت بومبر أوبسيديان ساتان الفاخر',
    category: 'jackets',
    price: 2750,
    compareAtPrice: 3200,
    images: [
      '/src/assets/images/jacket_bomber_obsidian_1794002161449.jpg',
      '/src/assets/images/hero_cairo_streetwear_1794002158802.jpg'
    ],
    colors: [
      { nameEn: 'Obsidian Black', nameAr: 'أسود أوبسيديان', hex: '#0B0B0C' },
      { nameEn: 'Dark Olive', nameAr: 'زيتي داكن', hex: '#282C24' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    inventory: {
      S: 6,
      M: 7,
      L: 3,
      XL: 4,
      XXL: 1
    },
    descriptionEn: 'The crown jewel of Cairo outerwear. Crafted from high-density heavy flight nylon with a deep lustrous satin finish, featuring brushed champagne-gold two-way metal hardware, quilted thermal insulated lining, and an internal utility chest holster.',
    descriptionAr: 'قطعة الأزياء الشتوية الأكثر تميزاً في القاهرة. مصنع من نايلون الطيران الكثيف بلمعة ساتان غنية فاخرة، مع سحابات معدنية ذهبية شامبين ثنائية الاتجاه، وبطانة حرارية مبطنة بتطريز هندسي وجيب داخلي سري.',
    fabricEn: 'Heavyweight Flight Satin Nylon with Diamond-Quilted Thermore Eco-Down',
    fabricAr: 'نايلون ساتان عسكري ثقيل مع بطانة حرارية عازلة مطرزة بالألماس',
    detailsEn: [
      'Two-way solid brass champagne-gold front zipper',
      'Ribbed wool-blend collar, waistband and wrist cuffs',
      'Signature left-sleeve cigarette/utility zip pocket',
      'Internal magnetic storm flap and passport pocket',
      'Tailored oversized volume with structured shoulder pads'
    ],
    detailsAr: [
      'سحاب أمامي ثنائي الاتجاه من النحاس المطلي بالذهب الشامبين',
      'ياقة وأساور منسوجة من الصوف المقاوم للتنسل والتمدد',
      'جيب سحاب تكتيكي على الكم الأيسر مع حامل أقلام',
      'جيب داخلي آمن للهاتف وجواز السفر مع إغلاق مغناطيسي',
      'قصة بومبر مريحة وممتلئة تعكس أحدث صيحات الموضة العالمية'
    ],
    isFeatured: true,
    isBestSeller: false,
    isNew: true,
    createdAt: '2026-10-30T16:00:00Z'
  },
  {
    id: 'kyp-005',
    sku: 'KYP-HD-02',
    slug: 'sandstone-hieroglyph-hoodie',
    nameEn: 'Sandstone Hieroglyph Boxy Hoodie',
    nameAr: 'هودي الحجر الرملي الهيروغليفي الحديث',
    category: 'hoodies',
    price: 1800,
    compareAtPrice: 2100,
    images: [
      '/src/assets/images/hero_cairo_streetwear_1794002158802.jpg',
      '/src/assets/images/hoodie_anubis_black_1794002159476.jpg'
    ],
    colors: [
      { nameEn: 'Sandstone Gold', nameAr: 'ذهب رملي', hex: '#D4C3A3' },
      { nameEn: 'Pitch Black', nameAr: 'أسود دامس', hex: '#000000' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    inventory: {
      S: 9,
      M: 11,
      L: 5,
      XL: 6,
      XXL: 3
    },
    descriptionEn: 'A tribute to the monumental stone monoliths of Giza. Featuring tone-on-tone 3D puff-printed contemporary hieroglyphic cartouche down the spinal seam, finished with raw cut rolled hems and heavy ribbing.',
    descriptionAr: 'تحية فنية لصخور الجيزة الخالدة. يتميز بطباعة بارزة ثلاثية الأبعاد لخرطوشة هيروغليفية عصرية بامتداد خط الظهر، مع تشطيبات متقنة وحواف مضلعة متينة.',
    fabricEn: '100% Egyptian Organic Terry Cotton (450 GSM)',
    fabricAr: '١٠٠٪ تيري قطن مصري عضوي فاخر (٤٥٠ جم)',
    detailsEn: [
      'High-density 3D puff print running along spinal column',
      'Drop shoulders with raw-edge reverse seam accents',
      'Deep thermal hand-warmer kangaroo pouch',
      'Custom silver-tone branded cord toggles'
    ],
    detailsAr: [
      'طباعة ثلاثية الأبعاد بارزة مقاومة للغسيل بطول الظهر',
      'أكتاف منسدلة مع درزات معكوسة مصممة بعناية',
      'جيب كنغر دافئ مبطن بالكامل',
      'مشابك أربطة معدنية مخصصة منقوشة بالليزر'
    ],
    isFeatured: false,
    isBestSeller: true,
    isNew: false,
    createdAt: '2026-09-12T09:00:00Z'
  },
  {
    id: 'kyp-006',
    sku: 'KYP-TS-02',
    slug: 'underground-cairo-heavy-tee-noir',
    nameEn: 'Underground Cairo Heavyweight Tee',
    nameAr: 'تيشيرت أندرجراوند كايرو - أسود فاحم',
    category: 'tshirts',
    price: 900,
    compareAtPrice: 1150,
    images: [
      '/src/assets/images/tshirt_cairo_heavyweight_1794002159953.jpg',
      '/src/assets/images/hoodie_anubis_black_1794002159476.jpg'
    ],
    colors: [
      { nameEn: 'Matte Black', nameAr: 'أسود مطفأ', hex: '#141414' },
      { nameEn: 'Off-White Ivory', nameAr: 'أوف وايت عاجي', hex: '#EAE1D1' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    inventory: {
      S: 18,
      M: 14,
      L: 7,
      XL: 8,
      XXL: 4
    },
    descriptionEn: 'Minimalist streetwear supremacy. Features the subtle KAYPER signature crest embroidered in matte gold thread on the left chest, with a heavyweight 320 GSM structure that holds an elevated drape.',
    descriptionAr: 'قمة البساطة والفخامة في أزياء الشارع. يحمل شعار كايبر الملكي مطرزاً بخيوط ذهبية ناعمة على الصدر الأيسر، مع نسيج ثقيل عيار 320 جم يمنحك مظهراً جذاباً ومستقيماً.',
    fabricEn: '100% Super-Combed Egyptian Cotton (320 GSM)',
    fabricAr: '١٠٠٪ قطن مصري سوبر ممشط (٣٢٠ جم)',
    detailsEn: [
      'Dense 1-inch collar ribbing with twin-needle collar stay',
      'Reinforced shoulder tape for shape retention',
      'Woven satin label at the hem',
      'Pigment dyed for rich color depth'
    ],
    detailsAr: [
      'ياقة سميكة محبوكة بخياطة مزدوجة تحافظ على استقامتها',
      'شريط كتف داخلي مقوى لمنع ترهل التيشيرت',
      'بطاقة ساتان فاخرة منسوجة عند الحافة السفلية',
      'مصبوغ بصبغات طبيعية عميقة تحافظ على اللون مع تكرار الغسيل'
    ],
    isFeatured: false,
    isBestSeller: true,
    isNew: false,
    createdAt: '2026-09-20T11:00:00Z'
  },
  {
    id: 'kyp-007',
    sku: 'KYP-CG-02',
    slug: 'stealth-combat-cargo-pants-noir',
    nameEn: 'Stealth Combat Cargo Joggers',
    nameAr: 'بنطال قتال ستيلث كارجو - أسود نوار',
    category: 'cargos',
    price: 1850,
    compareAtPrice: 2250,
    images: [
      '/src/assets/images/cargo_pants_desert_sand_1794002160256.jpg',
      '/src/assets/images/jacket_bomber_obsidian_1794002161449.jpg'
    ],
    colors: [
      { nameEn: 'Pitch Black', nameAr: 'أسود ليلي', hex: '#0E0E0E' },
      { nameEn: 'Gunmetal Grey', nameAr: 'رمادي حديدي', hex: '#2A2E32' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    inventory: {
      S: 7,
      M: 11,
      L: 3,
      XL: 5,
      XXL: 2
    },
    descriptionEn: 'Designed for the nocturnal city explorer. Features asymmetric dual-cargo storage, modular key clips, matte black D-rings, and tapered jogger cuffs with premium elastic ribbing.',
    descriptionAr: 'مُصمم لعشاق استكشاف شوارع المدينة ليلاً. يتميز بجيوب كارجو مزدوجة غير متماثلة وحلقات تعليق معدنية سوداء وأساور كاحل مطاطية مريحة.',
    fabricEn: 'Stretch Cotton Twill (97% Egyptian Cotton, 3% Spandex 320 GSM)',
    fabricAr: 'قطن تويل مرن (٩٧٪ قطن مصري، ٣٪ سباندكس ٣٢٠ جم)',
    detailsEn: [
      'Tactical matte black metal D-rings on front belt loops',
      'Concealed zippered passport security pocket',
      'High-recovery ribbed cuffs that hug the ankle',
      'Bar-tack reinforced strain points'
    ],
    detailsAr: [
      'حلقات معدنية D-Ring سوداء تكتيكية لتعليق المفاتيح والإكسسوارات',
      'جيب سري بسحاب مخفي لحفظ المحفظة والهاتف بأمان',
      'أساور كاحل مضلعة عالية الجودة تحافظ على إحكامها',
      'درزات تقوية عند كافة نقاط الضغط والجيوب'
    ],
    isFeatured: false,
    isBestSeller: false,
    isNew: true,
    createdAt: '2026-10-18T13:00:00Z'
  },
  {
    id: 'kyp-008',
    sku: 'KYP-AC-01',
    slug: 'gold-crest-heavyweight-beanie',
    nameEn: 'Gold Crest Heavyweight Ribbed Beanie',
    nameAr: 'طاقية بيني مضلعة بشعار كايبر الذهبي',
    category: 'accessories',
    price: 490,
    compareAtPrice: 650,
    images: [
      '/src/assets/images/hoodie_anubis_black_1794002159476.jpg',
      '/src/assets/images/hero_cairo_streetwear_1794002158802.jpg'
    ],
    colors: [
      { nameEn: 'Obsidian Black', nameAr: 'أسود بركاني', hex: '#0F0F0F' },
      { nameEn: 'Champagne Tan', nameAr: 'بيج شامبين', hex: '#D4C3A3' }
    ],
    sizes: ['M', 'L'],
    inventory: {
      S: 0,
      M: 25,
      L: 18,
      XL: 0,
      XXL: 0
    },
    descriptionEn: 'Chunky 7-gauge ribbed knit streetwear beanie crafted from ultra-soft Egyptian cotton-cashmere yarn. Embellished with an engraved champagne gold KAYPER metal bar at the turn-up cuff.',
    descriptionAr: 'طاقية بيني مضلعة ثقيلة ومحبوكة من غزل القطن المصري الفاخر مع لمسة كشمير ناعمة. مزينة بشريحة معدنية مذهبة محفورة بشعار كايبر على الثنية الأمامية.',
    fabricEn: '85% Egyptian Combed Cotton, 15% Cashmere Blend',
    fabricAr: '٨٥٪ قطن مصري ممشط، ١٥٪ كشمير فائق النعومة',
    detailsEn: [
      '7-gauge chunky fisherman rib construction',
      'Custom gold-plated metal plaque with anti-tarnish coating',
      'Snug comfortable shape retention'
    ],
    detailsAr: [
      'حبكة صيادي السمك الكلاسيكية السميكة',
      'لوحة معدنية مطلية بالذهب غير قابلة للتأكسد أو البهتان',
      'تصميم مريح يثبت على الرأس دون ضغط مزعج'
    ],
    isFeatured: false,
    isBestSeller: false,
    isNew: false,
    createdAt: '2026-09-05T15:00:00Z'
  }
];
