import { Coupon, StoreSettings, Order } from '../types';

export const INITIAL_COUPONS: Coupon[] = [
  {
    code: 'KAYPER10',
    type: 'percentage',
    value: 10,
    minOrderValue: 1000,
    expiresAt: '2027-12-31',
    isActive: true,
    usageCount: 42
  },
  {
    code: 'CAIRO200',
    type: 'fixed',
    value: 200,
    minOrderValue: 1800,
    expiresAt: '2027-12-31',
    isActive: true,
    usageCount: 19
  },
  {
    code: 'STREET15',
    type: 'percentage',
    value: 15,
    minOrderValue: 2500,
    expiresAt: '2027-06-30',
    isActive: true,
    usageCount: 8
  }
];

export const INITIAL_SETTINGS: StoreSettings = {
  brandNameEn: 'KAYPER',
  brandNameAr: 'كايبر',
  announcementEn: 'FAST SHIPPING ACROSS ALL 27 GOVERNORATES • CASH ON DELIVERY AVAILABLE • FREE 14-DAY EXCHANGES',
  announcementAr: 'شحن سريع لجميع محافظات مصر الـ 27 • الدفع عند الاستلام متاح • استبدال واسترجاع مجاني خلال 14 يوماً',
  freeShippingThreshold: 2500, // Free shipping if cart >= 2,500 EGP
  heroTitleEn: 'CAIRO UNDERGROUND LUXURY',
  heroTitleAr: 'فخامة الشارع القاهري',
  heroSubtitleEn: 'Heavyweight Egyptian cotton architectural silhouettes sculpted for the contemporary nocturnal vanguard.',
  heroSubtitleAr: 'أزياء شارع استثنائية منسوجة من أثقل أقطان مصر العضوية ومصممة بدقة معمارية لعشاق التميز.',
  heroImage: '/src/assets/images/hero_cairo_streetwear_1794002158802.jpg',
  instapayAccount: 'kayper@instapay',
  vodafoneCashWallet: '01098765432',
  supportPhone: '01023456789',
  adminPasswordHash: 'kayper2026'
};

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'KYP-9482',
    customerName: 'Youssef El-Shennawy',
    customerPhone: '01012345678',
    customerEmail: 'youssef@example.com',
    governorateId: 'cairo',
    governorateNameEn: 'Cairo',
    governorateNameAr: 'القاهرة',
    city: 'New Cairo (Tagamoa 5)',
    address: 'Building 42, South Choueifat, Villa 3',
    notes: 'Please call before arriving, building entrance B',
    items: [
      {
        productId: 'kyp-001',
        nameEn: 'Anubis Heavyweight Oversized Hoodie',
        nameAr: 'هودي أنوبيس أوفرسايز الثقيل',
        size: 'L',
        colorNameEn: 'Obsidian Black',
        colorNameAr: 'أسود بركاني',
        price: 1850,
        quantity: 1,
        image: '/src/assets/images/hoodie_anubis_black_1794002159476.jpg'
      },
      {
        productId: 'kyp-002',
        nameEn: 'Cairo Archive Boxy T-Shirt',
        nameAr: 'تيشيرت أرشيف القاهرة بوكسي فيت',
        size: 'L',
        colorNameEn: 'Washed Charcoal',
        colorNameAr: 'رمادي فحمي كلاسيكي',
        price: 950,
        quantity: 1,
        image: '/src/assets/images/tshirt_cairo_heavyweight_1794002159953.jpg'
      }
    ],
    subtotal: 2800,
    discount: 280,
    couponCode: 'KAYPER10',
    shippingFee: 0, // Free over threshold
    total: 2520,
    paymentMethod: 'instapay',
    paymentRef: 'INSTA-88392183',
    status: 'shipped',
    createdAt: '2026-11-04T16:20:00Z'
  },
  {
    id: 'KYP-8319',
    customerName: 'Karim Mansour',
    customerPhone: '01198765432',
    customerEmail: 'karim.m@example.com',
    governorateId: 'giza',
    governorateNameEn: 'Giza',
    governorateNameAr: 'الجيزة',
    city: 'Sheikh Zayed',
    address: 'Compound Beverly Hills, Gate 2',
    notes: 'Cash on delivery ready',
    items: [
      {
        productId: 'kyp-003',
        nameEn: 'Nomad Tactical Cargo Trousers',
        nameAr: 'بنطال نوماد كارجو التكتيكي - رمال الصحراء',
        size: 'M',
        colorNameEn: 'Desert Sand',
        colorNameAr: 'رمال الصحراء',
        price: 1950,
        quantity: 1,
        image: '/src/assets/images/cargo_pants_desert_sand_1794002160256.jpg'
      }
    ],
    subtotal: 1950,
    discount: 0,
    shippingFee: 55,
    total: 2005,
    paymentMethod: 'cod',
    status: 'processing',
    createdAt: '2026-11-05T11:15:00Z'
  },
  {
    id: 'KYP-7721',
    customerName: 'Nouran Mostafa',
    customerPhone: '01234567890',
    customerEmail: 'nouran.street@example.com',
    governorateId: 'alexandria',
    governorateNameEn: 'Alexandria',
    governorateNameAr: 'الإسكندرية',
    city: 'Smouha',
    address: 'Albert Al-Awwal St, Tower 14, Apt 8',
    notes: 'Vodafone Cash paid',
    items: [
      {
        productId: 'kyp-004',
        nameEn: 'Obsidian Flight Satin Bomber',
        nameAr: 'جاكيت بومبر أوبسيديان ساتان الفاخر',
        size: 'S',
        colorNameEn: 'Obsidian Black',
        colorNameAr: 'أسود أوبسيديان',
        price: 2750,
        quantity: 1,
        image: '/src/assets/images/jacket_bomber_obsidian_1794002161449.jpg'
      }
    ],
    subtotal: 2750,
    discount: 200,
    couponCode: 'CAIRO200',
    shippingFee: 0,
    total: 2550,
    paymentMethod: 'vodafone_cash',
    paymentRef: 'VF-7492019',
    status: 'delivered',
    createdAt: '2026-11-02T19:40:00Z'
  }
];
