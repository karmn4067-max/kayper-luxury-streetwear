export type Language = 'ar' | 'en';

export type Category = 'hoodies' | 'tshirts' | 'cargos' | 'jackets' | 'accessories';

export interface ProductColor {
  nameEn: string;
  nameAr: string;
  hex: string;
}

export type ProductSize = 'S' | 'M' | 'L' | 'XL' | 'XXL';

export interface Product {
  id: string;
  sku: string;
  slug: string;
  nameEn: string;
  nameAr: string;
  category: Category;
  price: number;
  compareAtPrice?: number;
  images: string[];
  colors: ProductColor[];
  sizes: ProductSize[];
  inventory: Record<ProductSize, number>;
  descriptionEn: string;
  descriptionAr: string;
  fabricEn: string;
  fabricAr: string;
  detailsEn: string[];
  detailsAr: string[];
  isFeatured?: boolean;
  isBestSeller?: boolean;
  isNew?: boolean;
  createdAt: string;
}

export interface CartItem {
  id: string; // unique item instance id: productId-size-color
  productId: string;
  product: Product;
  size: ProductSize;
  color: ProductColor;
  quantity: number;
  price: number;
}

export interface Governorate {
  id: string;
  nameEn: string;
  nameAr: string;
  zone: 'cairo_giza' | 'alexandria' | 'delta' | 'canal' | 'upper_egypt' | 'red_sea_sinai';
  shippingFee: number;
  deliveryDays: string;
}

export type PaymentMethod = 'cod' | 'instapay' | 'vodafone_cash';

export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface OrderItem {
  productId: string;
  nameEn: string;
  nameAr: string;
  size: ProductSize;
  colorNameEn: string;
  colorNameAr: string;
  price: number;
  quantity: number;
  image: string;
}

export interface Order {
  id: string; // e.g. KYP-9482
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  governorateId: string;
  governorateNameEn: string;
  governorateNameAr: string;
  city: string;
  address: string;
  notes?: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  couponCode?: string;
  shippingFee: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentRef?: string; // InstaPay reference or Vodafone Cash number
  status: OrderStatus;
  createdAt: string;
}

export interface Coupon {
  code: string;
  type: 'percentage' | 'fixed';
  value: number; // e.g., 10 for 10% or 150 for 150 EGP
  minOrderValue: number;
  expiresAt: string;
  isActive: boolean;
  usageCount: number;
}

export interface StoreSettings {
  brandNameEn: string;
  brandNameAr: string;
  announcementEn: string;
  announcementAr: string;
  freeShippingThreshold: number; // EGP
  heroTitleEn: string;
  heroTitleAr: string;
  heroSubtitleEn: string;
  heroSubtitleAr: string;
  heroImage: string;
  instapayAccount: string;
  vodafoneCashWallet: string;
  supportPhone: string;
  adminPasswordHash: string; // default hashed/stored
}
